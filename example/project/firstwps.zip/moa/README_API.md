<!--
 * @Description:
 * @Author: dnh
 * @Date: 2022-03-02 16:34:44
 * @LastEditTime: 2022-03-21 15:32:49
 * @LastEditors: dnh
 * @FilePath: \README_API.md
-->

```c++
/*
    接口描述文档说明：
    1.必填字段用一个或多个x表示
    2.一个x表示为布尔型
    3.xxx表示为数值型，超长的数值可以用字符串形式表示
    4."xxxxxx"表示为字符串型
    5.有具体的值，如0,false,"13858882421"等表示该字段有默认值，请求时如果与默认值相等，可以不传该字段
    6.数组型/kv对型数据，如果没有值，可以不传
    7.单独的对象（结构体），即不在数组或作为kv对的值出现时，一般必传
*/

[
  {
    "fieldId": 0,
    "fieldType": "",
    "fieldName": "title",
    "aliasName": "标题",
    "customName": "",
    "isFill": true,
    "property": "{\"disabledt\":true,\"type\":\"input\",\"max\":200,\"disabled\":false,\"options\":[],\"format\":\"\",\"inputType\":1,\"timeStamp\":\"\"}",
    "value": "",
    "extraValue": "",
    "isCard": false,
    "cardId": 0,
    "children": [],
    "refNoChildren": []
  },
  {
    "fieldId": 1647436240289,
    "fieldType": "",
    "fieldName": "inputControl",
    "aliasName": "输入框",
    "customName": "",
    "isFill": false,
    "property": "{\"disabledt\":true,\"type\":\"input\",\"max\":200,\"disabled\":false,\"options\":[],\"format\":\"\",\"inputType\":1,\"timeStamp\":1647436240289}",
    "value": "",
    "extraValue": "",
    "isCard": false,
    "cardId": 0,
    "children": [],
    "refNoChildren": []
  },
  {
    "fieldId": 0,
    "fieldType": "",
    "fieldName": "creatPerson",
    "aliasName": "起草人",
    "customName": "",
    "isFill": false,
    "property": "{\"disabledt\":false,\"type\":\"text\",\"max\":200,\"disabled\":false,\"options\":[],\"format\":\"\",\"inputType\":1,\"timeStamp\":\"\"}",
    "value": "",
    "extraValue": "",
    "isCard": false,
    "cardId": 0,
    "children": [],
    "refNoChildren": []
  },
  {
    "fieldId": 0,
    "fieldType": "",
    "fieldName": "mobile",
    "aliasName": "手机号码",
    "customName": "",
    "isFill": false,
    "property": "{\"disabledt\":false,\"type\":\"text\",\"max\":200,\"disabled\":false,\"options\":[],\"format\":\"\",\"inputType\":1,\"timeStamp\":\"\"}",
    "value": "",
    "extraValue": "",
    "isCard": false,
    "cardId": 0,
    "children": [],
    "refNoChildren": []
  },
  {
    "fieldId": 0,
    "fieldType": "radio",
    "fieldName": "officialType",
    "aliasName": "公文类型",
    "customName": "",
    "isFill": false,
    "property": "{\"disabledt\":true,\"type\":\"dropDown\",\"max\":0,\"disabled\":false,\"options\":[{\"text\":\"会议纪要\",\"value\":14},{\"text\":\"其他\",\"value\":15}],\"format\":\"\",\"inputType\":0,\"timeStamp\":1647436216390}",
    "value": "",
    "extraValue": "",
    "isCard": false,
    "cardId": 0,
    "children": [],
    "refNoChildren": []
  },
  {
    "fieldId": 0,
    "fieldType": "",
    "fieldName": "fileDepartment",
    "aliasName": "拟稿部门",
    "customName": "",
    "isFill": false,
    "property": "{\"disabledt\":false,\"type\":\"text\",\"max\":200,\"disabled\":false,\"options\":[],\"format\":\"\",\"inputType\":1,\"timeStamp\":\"\"}",
    "value": "",
    "extraValue": "",
    "isCard": false,
    "cardId": 0,
    "children": [],
    "refNoChildren": []
  },
  {
    "fieldId": 0,
    "fieldType": "radio",
    "fieldName": "useSeal",
    "aliasName": "是否用章",
    "customName": "",
    "isFill": false,
    "property": "{\"disabledt\":true,\"type\":\"dropDown\",\"max\":0,\"disabled\":false,\"options\":[{\"text\":\"是\",\"value\":1},{\"text\":\"否\",\"value\":2}],\"format\":\"\",\"inputType\":0,\"timeStamp\":1647436218024}",
    "value": "",
    "extraValue": "",
    "isCard": false,
    "cardId": 0,
    "children": [],
    "refNoChildren": []
  },
  {
    "fieldId": 0,
    "fieldType": "",
    "fieldName": "creatTime",
    "aliasName": "拟稿时间",
    "customName": "",
    "isFill": false,
    "property": "{\"disabledt\":false,\"type\":\"text\",\"max\":200,\"disabled\":false,\"options\":[],\"format\":\"\",\"inputType\":1,\"timeStamp\":\"\"}",
    "value": "",
    "extraValue": "",
    "isCard": false,
    "cardId": 0,
    "children": [],
    "refNoChildren": []
  },
  {
    "fieldId": 0,
    "fieldType": "radio",
    "fieldName": "outsideRefNo",
    "aliasName": "外部文号",
    "customName": "",
    "isFill": false,
    "property": "{\"disabledt\":true,\"type\":\"refno\",\"max\":0,\"disabled\":false,\"options\":[],\"format\":\"\",\"inputType\":0,\"timeStamp\":1647436221514}",
    "value": "",
    "extraValue": "",
    "isCard": false,
    "cardId": 0,
    "children": [],
    "refNoChildren": [
      {
        "fieldType": "radio",
        "aliasName": "外部文号代字",
        "fieldName": "outsideRefNo1"
      },
      {
        "fieldType": "radio",
        "aliasName": "外部文号年份",
        "fieldName": "outsideRefNo2"
      },
      {
        "fieldType": "number",
        "aliasName": "外部文号序号",
        "fieldName": "outsideRefNo3"
      }
    ]
  },
  {
    "fieldId": 0,
    "fieldType": "",
    "fieldName": "dispatchDate",
    "aliasName": "发文日期",
    "customName": "",
    "isFill": false,
    "property": "{\"disabledt\":true,\"type\":\"time\",\"max\":0,\"disabled\":false,\"options\":[],\"format\":\"YYYY/MM/DD HH:mm\",\"inputType\":0,\"timeStamp\":1647436233704}",
    "value": "",
    "extraValue": "",
    "isCard": false,
    "cardId": 0,
    "children": [],
    "refNoChildren": []
  },
  {
    "fieldId": 0,
    "fieldType": "",
    "fieldName": "dispatchCompany",
    "aliasName": "发文单位",
    "customName": "",
    "isFill": false,
    "property": "{\"disabledt\":true,\"type\":\"input\",\"max\":100,\"disabled\":false,\"options\":[],\"format\":\"\",\"inputType\":0,\"timeStamp\":1647436231985}",
    "value": "",
    "extraValue": "",
    "isCard": false,
    "cardId": 0,
    "children": [],
    "refNoChildren": []
  },
  {
    "fieldId": 0,
    "fieldType": "",
    "fieldName": "receiptCompany",
    "aliasName": "来文单位",
    "customName": "",
    "isFill": false,
    "property": "{\"disabledt\":true,\"type\":\"input\",\"max\":100,\"disabled\":false,\"options\":[],\"format\":\"\",\"inputType\":0,\"timeStamp\":1647436224426}",
    "value": "",
    "extraValue": "",
    "isCard": false,
    "cardId": 0,
    "children": [],
    "refNoChildren": []
  },
  {
    "fieldId": 0,
    "fieldType": "",
    "fieldName": "printer",
    "aliasName": "打印人",
    "customName": "",
    "isFill": false,
    "property": "{\"disabledt\":true,\"type\":\"input\",\"max\":100,\"disabled\":false,\"options\":[],\"format\":\"\",\"inputType\":0,\"timeStamp\":1647436227161}",
    "value": "",
    "extraValue": "",
    "isCard": false,
    "cardId": 0,
    "children": [],
    "refNoChildren": []
  },
  {
    "fieldId": 0,
    "fieldType": "",
    "fieldName": "reference",
    "aliasName": "参考信息",
    "customName": "",
    "isFill": false,
    "property": "{\"disabledt\":true,\"type\":\"sign\",\"max\":50,\"signType\":2,\"disabled\":false,\"options\":[],\"format\":\"\",\"inputType\":0,\"timeStamp\":1647436235526}",
    "value": "",
    "extraValue": "",
    "isCard": false,
    "cardId": 0,
    "children": [],
    "refNoChildren": []
  },
  {
    "fieldId": 0,
    "fieldType": "",
    "fieldName": "proofreader",
    "aliasName": "校对人",
    "customName": "",
    "isFill": false,
    "property": "{\"disabledt\":true,\"type\":\"input\",\"max\":100,\"disabled\":false,\"options\":[],\"format\":\"\",\"inputType\":0,\"timeStamp\":1647436230149}",
    "value": "",
    "extraValue": "",
    "isCard": false,
    "cardId": 0,
    "children": [],
    "refNoChildren": []
  },
  {
    "fieldId": 0,
    "fieldType": "",
    "fieldName": "impression",
    "aliasName": "印数",
    "customName": "",
    "isFill": false,
    "property": "{\"disabledt\":true,\"type\":\"input\",\"max\":50,\"disabled\":false,\"options\":[],\"format\":\"\",\"inputType\":0,\"timeStamp\":1647436228632}",
    "value": "",
    "extraValue": "",
    "isCard": false,
    "cardId": 0,
    "children": [],
    "refNoChildren": []
  },
  {
    "fieldId": 0,
    "fieldType": "",
    "fieldName": "issUer",
    "aliasName": "签发人",
    "customName": "",
    "isFill": false,
    "property": "{\"disabledt\":true,\"type\":\"input\",\"max\":100,\"disabled\":false,\"options\":[],\"format\":\"\",\"inputType\":1,\"timeStamp\":1647436225625}",
    "value": "",
    "extraValue": "",
    "isCard": false,
    "cardId": 0,
    "children": [],
    "refNoChildren": []
  },
  {
    "fieldId": 0,
    "fieldType": "",
    "fieldName": "receiptDate",
    "aliasName": "收文日期",
    "customName": "",
    "isFill": false,
    "property": "{\"disabledt\":true,\"type\":\"time\",\"max\":0,\"disabled\":false,\"options\":[],\"format\":\"YYYY/MM/DD HH:mm\",\"inputType\":0,\"timeStamp\":1647436222967}",
    "value": "",
    "extraValue": "",
    "isCard": false,
    "cardId": 0,
    "children": [],
    "refNoChildren": []
  },
  {
    "fieldId": 1647436210996,
    "fieldType": "",
    "fieldName": "inputControl",
    "aliasName": "输入框",
    "customName": "",
    "isFill": false,
    "property": "{\"disabledt\":true,\"type\":\"input\",\"max\":200,\"disabled\":false,\"options\":[],\"format\":\"\",\"inputType\":1,\"timeStamp\":1647436210996}",
    "value": "",
    "extraValue": "",
    "isCard": false,
    "cardId": 0,
    "children": [],
    "refNoChildren": []
  },
  {
    "fieldId": 0,
    "fieldType": "radio",
    "fieldName": "receiptRefNo",
    "aliasName": "来文文号",
    "customName": "",
    "isFill": false,
    "property": "{\"disabledt\":true,\"type\":\"refno\",\"max\":0,\"disabled\":false,\"options\":[],\"format\":\"\",\"inputType\":0,\"timeStamp\":1647436219812}",
    "value": "",
    "extraValue": "",
    "isCard": false,
    "cardId": 0,
    "children": [],
    "refNoChildren": [
      {
        "fieldType": "radio",
        "aliasName": "来文文号代字",
        "fieldName": "receiptRefNo1"
      },
      {
        "fieldType": "radio",
        "aliasName": "来文文号年份",
        "fieldName": "receiptRefNo2"
      },
      {
        "fieldType": "number",
        "aliasName": "来文文号序号",
        "fieldName": "receiptRefNo3"
      }
    ]
  },
  {
    "fieldId": 0,
    "fieldType": "radio",
    "fieldName": "refNo",
    "aliasName": "发文文号",
    "customName": "",
    "isFill": false,
    "property": "{\"disabledt\":true,\"type\":\"refno\",\"max\":0,\"disabled\":false,\"options\":[],\"format\":\"\",\"inputType\":0,\"timeStamp\":\"\"}",
    "value": "",
    "extraValue": "",
    "isCard": false,
    "cardId": 0,
    "children": [],
    "refNoChildren": [
      {
        "fieldType": "radio",
        "aliasName": "发文文号代字",
        "fieldName": "refNo1"
      },
      {
        "fieldType": "radio",
        "aliasName": "发文文号年份",
        "fieldName": "refNo2"
      },
      {
        "fieldType": "number",
        "aliasName": "发文文号序号",
        "fieldName": "refNo3"
      }
    ]
  },
  {
    "fieldId": 0,
    "fieldType": "",
    "fieldName": "themeWord",
    "aliasName": "主题词",
    "customName": "",
    "isFill": false,
    "property": "{\"disabledt\":true,\"type\":\"input\",\"max\":100,\"disabled\":false,\"options\":[],\"format\":\"\",\"inputType\":1,\"timeStamp\":1647436213237}",
    "value": "",
    "extraValue": "",
    "isCard": false,
    "cardId": 0,
    "children": [],
    "refNoChildren": []
  },
  {
    "fieldId": 0,
    "fieldType": "radio",
    "fieldName": "urgencyLevel",
    "aliasName": "紧急程度",
    "customName": "",
    "isFill": false,
    "property": "{\"disabledt\":false,\"type\":\"dropDown\",\"max\":0,\"disabled\":false,\"options\":[{\"text\":\"特急\",\"value\":1},{\"text\":\"紧急\",\"value\":2},{\"text\":\"常规\",\"value\":3}],\"format\":\"\",\"inputType\":0,\"timeStamp\":\"\"}",
    "value": "",
    "extraValue": "",
    "isCard": false,
    "cardId": 0,
    "children": [],
    "refNoChildren": []
  },
  {
    "fieldId": 0,
    "fieldType": "radio",
    "fieldName": "secretClass",
    "aliasName": "密级",
    "customName": "",
    "isFill": false,
    "property": "{\"disabledt\":false,\"type\":\"dropDown\",\"max\":0,\"disabled\":false,\"options\":[{\"text\":\"核心商密\",\"value\":1},{\"text\":\"普通商密\",\"value\":2},{\"text\":\"内部信息\",\"value\":3},{\"text\":\"一般\",\"value\":4}],\"format\":\"\",\"inputType\":0,\"timeStamp\":\"\"}",
    "value": "",
    "extraValue": "",
    "isCard": false,
    "cardId": 0,
    "children": [],
    "refNoChildren": []
  },
  {
    "fieldId": 0,
    "fieldType": "radio",
    "fieldName": "secrecyTerm",
    "aliasName": "保密期限",
    "customName": "保密期限",
    "isFill": true,
    "property": "{\"disabledt\":false,\"type\":\"dropDown\",\"max\":0,\"disabled\":false,\"options\":[{\"text\":\"12\",\"value\":1}],\"format\":\"\",\"inputType\":0,\"timeStamp\":\"\"}",
    "value": "",
    "extraValue": "",
    "isCard": false,
    "cardId": 0,
    "children": [],
    "refNoChildren": []
  },
  {
    "fieldId": 0,
    "fieldType": "",
    "fieldName": "bodyFile",
    "aliasName": "正文",
    "customName": "",
    "isFill": true,
    "property": "{\"disabledt\":true,\"type\":\"sign\",\"max\":50,\"signType\":1,\"disabled\":false,\"options\":[],\"format\":\"\",\"inputType\":0,\"timeStamp\":\"\"}",
    "value": "",
    "extraValue": "",
    "isCard": false,
    "cardId": 0,
    "children": [],
    "refNoChildren": []
  },
  {
    "fieldId": 0,
    "fieldType": "",
    "fieldName": "mainSend",
    "aliasName": "主送",
    "customName": "",
    "isFill": false,
    "property": "{\"disabledt\":true,\"type\":\"userOrdept\",\"max\":100,\"disabled\":false,\"options\":[],\"format\":\"\",\"inputType\":1,\"timeStamp\":\"\"}",
    "value": "",
    "extraValue": "",
    "isCard": false,
    "cardId": 0,
    "children": [],
    "refNoChildren": []
  },
  {
    "fieldId": 0,
    "fieldType": "",
    "fieldName": "copySend",
    "aliasName": "抄送",
    "customName": "",
    "isFill": false,
    "property": "{\"disabledt\":false,\"type\":\"userOrdept\",\"max\":100,\"disabled\":false,\"options\":[],\"format\":\"\",\"inputType\":1,\"timeStamp\":\"\"}",
    "value": "",
    "extraValue": "",
    "isCard": false,
    "cardId": 0,
    "children": [],
    "refNoChildren": []
  },
  {
    "fieldId": 0,
    "fieldType": "",
    "fieldName": "countersignDepartment",
    "aliasName": "会签部门",
    "customName": "",
    "isFill": false,
    "property": "{\"disabledt\":false,\"type\":\"userOrdept\",\"max\":100,\"disabled\":false,\"options\":[],\"format\":\"\",\"inputType\":1,\"timeStamp\":\"\"}",
    "value": "",
    "extraValue": "",
    "isCard": false,
    "cardId": 0,
    "children": [],
    "refNoChildren": []
  },
  {
    "fieldId": 0,
    "fieldType": "",
    "fieldName": "enclosure",
    "aliasName": "附件",
    "customName": "",
    "isFill": false,
    "property": "{\"disabledt\":false,\"type\":\"sign\",\"max\":50,\"signType\":2,\"disabled\":false,\"options\":[],\"format\":\"\",\"inputType\":0,\"timeStamp\":\"\"}",
    "value": "",
    "extraValue": "",
    "isCard": false,
    "cardId": 0,
    "children": [],
    "refNoChildren": []
  },
  {
    "fieldId": 0,
    "fieldType": "",
    "fieldName": "remarks",
    "aliasName": "备注",
    "customName": "",
    "isFill": false,
    "property": "{\"disabledt\":false,\"type\":\"input\",\"max\":200,\"disabled\":false,\"options\":[],\"format\":\"\",\"inputType\":1,\"timeStamp\":\"\"}",
    "value": "",
    "extraValue": "",
    "isCard": false,
    "cardId": 0,
    "children": [],
    "refNoChildren": []
  },
  {
    "fieldId": 0,
    "fieldType": "radio",
    "fieldName": "writing",
    "aliasName": "行文类型",
    "customName": "",
    "isFill": false,
    "property": "{\"disabledt\":true,\"type\":\"dropDown\",\"max\":0,\"disabled\":false,\"options\":[{\"text\":\"上行文\",\"value\":1},{\"text\":\"下行文\",\"value\":2},{\"text\":\"平行文\",\"value\":3}],\"format\":\"\",\"inputType\":0,\"timeStamp\":1647411279446}",
    "value": "",
    "extraValue": "",
    "isCard": false,
    "cardId": 0,
    "children": [],
    "refNoChildren": []
  }
]


enum ErrCode
{
    SRV_ERR = -11,
    NO_DATA = -12,
    NO_ALLOW = -13,
    INVALID_PARAM = -14,
}

enum DocumentStatus
{
    DOCUMENT_DOING = 1,
    DOCUMENT_DONE = 2,
    DOCUMENT_RECALL = 3,
    DOCUMENT_DEL = 10,
}

enum StepType
{
    STEP_WRITER = 1,
    STEP_AUDITOR = 2,
    STEP_SIGNER = 3,
}

enum OperType
{
    OPER_SIGN = 1,
    OPER_BACK = 2,
    OPER_RECALL = 3,
    OPER_CREATE = 4,
    OPER_SEAL = 5,
    OPER_SUBMIT = 6,
    OPER_TURN = 7,
    OPER_APPROVE = 9,
    OPER_DELFILE = 11,
    OPER_MODFILE = 12,
    OPER_RENAMEFILE = 13,
    OPER_RED = 14,
    OPER_PASS_READ = 15,
    OPER_RECREATE = 16,
    OPER_RESUBMIT = 17,
    OPER_UPLOAD = 18,
    OPER_URGE = 19,
    OPER_ASSIGN = 20,
    OPER_CANCEL_RECALL = 21,
    OPER_BACK_SUBMIT = 22,
}

enum DocumentRoleType
{
    ROLE_LWDJ = 1,    //来文登记
    ROLE_DWFW = 2,    //对外发文
    ROLE_GWCX = 3,    //公文查询
    ROLE_GWGD = 4,    //公文归档
    ROLE_DSGWCX = 5,    //地市公文查询
}

*公文接口创建公文
URI:/DocumentMoa/createDocument
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    info:
    {
        deptId:	xxx,
        deptName:	"xxxxxxxx",
        createUid:	"xxxxxxxx",
        createName:	"xxxxxxxx",
        createMobile:	"",
        templateID:	xxx,
        draftId:	0,
        fields: //可空
        [
            {
                fieldId:	xxx,
                fieldType:	"xxxxxxxx",
                fieldName:	"xxxxxxxx",
                aliasName:	"",
                customName:	"",
                isFill:	false,    //是否必填
                property:	"",    //字段属性,存储jason格式
                value:	"",
                extraValue:	"",
                isCard:	false,
                cardId:	0,
                children: //可空
                [
                    {
                        fieldId:	0,
                        fieldType:	"",
                        fieldName:	"",
                        aliasName:	"",
                        customName:	"",
                        isFill:	false,    //是否必填
                        property:	"",    //字段属性,存储jason格式
                        value:	"",
                        extraValue:	"",
                        isCard:	false,
                        cardId:	0
                    },
                    ...
                ],
                refNoChildren: //可空
                [
                    {
                        fieldType:	"",
                        fieldKey:	"",
                        fieldName:	""
                    },
                    ...
                ]
            },
            ...
        ]
    }
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        id:	xxx
    }
}

删除公文
URI:/DocumentMoa/delDocument
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    id:	xxx
}
RESPONSE DATA:
{
    retcode:	0
}

重新发起公文
URI:/DocumentMoa/reCreateDocument
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    id:	xxx,
    info:
    {
        templateID:	xxx,
        nextUsers:
        [
            {
                uid:	"xxxxxxxx",
                name:	"xxxxxxxx",
                isDoing:	false,
                operType:	0,
                operTime:	0,
                opinion:	"",
                chooseNextStepId:	0,
                chooseNextUsers: //可空
                [
                    {
                        uid:	"xxxxxxxx",
                        name:	"xxxxxxxx",
                        deptId:	-1,
                        deptName:	"",
                        orgId:	0,
                        orgName:	""
                    },
                    ...
                ],
                toTime:	0,
                isSendSms:	false,
                attachments:	"",
                isDef:	false,
                agentUid:	"",
                agentName:	"",
                isAgentDone:	false,
                orgId:	0,
                orgName:	"",
                deptId:	-1,
                deptName:	""
            },
            ...
        ],
        fields:
        [
            {
                fieldId:	xxx,
                fieldType:	"xxxxxxxx",
                fieldName:	"xxxxxxxx",
                aliasName:	"",
                customName:	"",
                isFill:	false,    //是否必填
                property:	"",    //字段属性,存储jason格式
                value:	"",
                extraValue:	"",
                isCard:	false,
                cardId:	0,
                children: //可空
                [
                    {
                        fieldId:	0,
                        fieldType:	"",
                        fieldName:	"",
                        aliasName:	"",
                        customName:	"",
                        isFill:	false,    //是否必填
                        property:	"",    //字段属性,存储jason格式
                        value:	"",
                        extraValue:	"",
                        isCard:	false,
                        cardId:	0
                    },
                    ...
                ],
                refNoChildren: //可空
                [
                    {
                        fieldType:	"",
                        fieldKey:	"",
                        fieldName:	""
                    },
                    ...
                ]
            },
            ...
        ],
        nextStepId:	0,
        opinion:	""
    }
}
RESPONSE DATA:
{
    retcode:	0
}

个人获取公文列表(admin handle)
URI:/DocumentMoa/getDocumentList
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    screen:
    {
        title:	"",
        beginTime:	0,
        endTime:	0,
        type:	0,
        tab:	1,    //0：全部 1: 待办理 2: 已办理 3：进行中 4：待查阅 5：已查阅 6：已撤销 7：我发起的
        templateIds: //可空
        [
            xxx,
            ...
        ],    //模板id
        createUids: //可空
        [
            "xxxxxxxx",
            ...
        ],    //创建人,公文查询新增筛选条件
        doneUids: //可空
        [
            "xxxxxxxx",
            ...
        ],    //经办人,公文查询新增筛选条件
        status: //可空
        [
            xxx,
            ...
        ],
        otherOrgId:	0,
        deptIds: //可空
        [
            xxx,
            ...
        ],    //部分id
        refNo1:	"",
        refNo2:	"",
        refNo3:	"",
        templateName:	""    //模板名字模糊搜索，给对外发文搜公司函特地加的
    },
    pageId:	xxx,
    pageCount:	xxx
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        allCount:	xxx,
        infos:
        [
            {
                id:	xxx,
                createUid:	"xxxxxxxx",
                createName:	"xxxxxxxx",
                createTime:	xxx,
                status:	xxx,
                type:	xxx,
                isFile:	false,
                endTime:	0,
                templateId:	0,
                templateName:	"",
                bizId:	"",
                fields: //可空
                [
                    {
                        fieldId:	xxx,
                        fieldType:	"xxxxxxxx",
                        fieldName:	"xxxxxxxx",
                        aliasName:	"",
                        customName:	"",
                        isFill:	false,    //是否必填
                        property:	"",    //字段属性,存储jason格式
                        value:	"",
                        extraValue:	"",
                        isCard:	false,
                        cardId:	0,
                        children: //可空
                        [
                            {
                                fieldId:	0,
                                fieldType:	"",
                                fieldName:	"",
                                aliasName:	"",
                                customName:	"",
                                isFill:	false,    //是否必填
                                property:	"",    //字段属性,存储jason格式
                                value:	"",
                                extraValue:	"",
                                isCard:	false,
                                cardId:	0
                            },
                            ...
                        ],
                        refNoChildren: //可空
                        [
                            {
                                fieldType:	"",
                                fieldKey:	"",
                                fieldName:	""
                            },
                            ...
                        ]
                    },
                    ...
                ]
            },
            ...
        ]
    }
}

管理员获取公司公文列表(admin handle)
URI:/DocumentMoa/getDocumentListByMgr
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    screen:
    {
        title:	"",
        beginTime:	0,
        endTime:	0,
        type:	0,
        tab:	1,    //0：全部 1: 待办理 2: 已办理 3：进行中 4：待查阅 5：已查阅 6：已撤销 7：我发起的
        templateIds: //可空
        [
            xxx,
            ...
        ],    //模板id
        createUids: //可空
        [
            "xxxxxxxx",
            ...
        ],    //创建人,公文查询新增筛选条件
        doneUids: //可空
        [
            "xxxxxxxx",
            ...
        ],    //经办人,公文查询新增筛选条件
        status: //可空
        [
            xxx,
            ...
        ],
        otherOrgId:	0,
        deptIds: //可空
        [
            xxx,
            ...
        ],    //部分id
        refNo1:	"",
        refNo2:	"",
        refNo3:	"",
        templateName:	""    //模板名字模糊搜索，给对外发文搜公司函特地加的
    },
    pageId:	xxx,
    pageCount:	xxx
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        allCount:	xxx,
        infos:
        [
            {
                id:	xxx,
                createUid:	"xxxxxxxx",
                createName:	"xxxxxxxx",
                createTime:	xxx,
                status:	xxx,
                type:	xxx,
                isFile:	false,
                endTime:	0,
                templateId:	0,
                templateName:	"",
                bizId:	"",
                fields: //可空
                [
                    {
                        fieldId:	xxx,
                        fieldType:	"xxxxxxxx",
                        fieldName:	"xxxxxxxx",
                        aliasName:	"",
                        customName:	"",
                        isFill:	false,    //是否必填
                        property:	"",    //字段属性,存储jason格式
                        value:	"",
                        extraValue:	"",
                        isCard:	false,
                        cardId:	0,
                        children: //可空
                        [
                            {
                                fieldId:	0,
                                fieldType:	"",
                                fieldName:	"",
                                aliasName:	"",
                                customName:	"",
                                isFill:	false,    //是否必填
                                property:	"",    //字段属性,存储jason格式
                                value:	"",
                                extraValue:	"",
                                isCard:	false,
                                cardId:	0
                            },
                            ...
                        ],
                        refNoChildren: //可空
                        [
                            {
                                fieldType:	"",
                                fieldKey:	"",
                                fieldName:	""
                            },
                            ...
                        ]
                    },
                    ...
                ]
            },
            ...
        ]
    }
}

获取公文详情
URI:/DocumentMoa/getDocumentDetail
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    id:	xxx
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        info:
        {
            orgId:	xxx,
            deptId:	0,
            deptName:	"",
            createUid:	"xxxxxxxx",
            createName:	"xxxxxxxx",
            createMobile:	"xxxxxxxx",
            createTime:	xxx,
            endTime:	xxx,
            type:	xxx,
            template_id:	xxx,
            status:	xxx,    //1:处理中 2:完成 3:撤回 10:删除
            title:	"xxxxxxxx",
            refNo:	"xxxxxxxx",
            urgencyLevel:	0,
            secret_class:	0,
            fileType:	0,
            biz_type:	0,
            biz_id:	"",
            isFile:	false,
            isSeal:	false,
            fields: //可空
            [
                {
                    fieldId:	xxx,
                    fieldType:	"xxxxxxxx",
                    fieldName:	"xxxxxxxx",
                    aliasName:	"",
                    customName:	"",
                    isFill:	false,    //是否必填
                    property:	"",    //字段属性,存储jason格式
                    value:	"",
                    extraValue:	"",
                    isCard:	false,
                    cardId:	0,
                    children: //可空
                    [
                        {
                            fieldId:	0,
                            fieldType:	"",
                            fieldName:	"",
                            aliasName:	"",
                            customName:	"",
                            isFill:	false,    //是否必填
                            property:	"",    //字段属性,存储jason格式
                            value:	"",
                            extraValue:	"",
                            isCard:	false,
                            cardId:	0
                        },
                        ...
                    ],
                    refNoChildren: //可空
                    [
                        {
                            fieldType:	"",
                            fieldKey:	"",
                            fieldName:	""
                        },
                        ...
                    ]
                },
                ...
            ],
            documentTemplate:
            {
                id:	xxx,
                name:	"xxxxxxxx",
                type:	xxx,
                childType:	xxx,
                fields:
                [
                    {
                        fieldId:	xxx,
                        fieldType:	"xxxxxxxx",
                        fieldName:	"xxxxxxxx",
                        aliasName:	"",
                        customName:	"",
                        isFill:	false,    //是否必填
                        property:	"",    //字段属性,存储jason格式
                        value:	"",
                        extraValue:	"",
                        isCard:	false,
                        cardId:	0,
                        children: //可空
                        [
                            {
                                fieldId:	0,
                                fieldType:	"",
                                fieldName:	"",
                                aliasName:	"",
                                customName:	"",
                                isFill:	false,    //是否必填
                                property:	"",    //字段属性,存储jason格式
                                value:	"",
                                extraValue:	"",
                                isCard:	false,
                                cardId:	0
                            },
                            ...
                        ],
                        refNoChildren: //可空
                        [
                            {
                                fieldType:	"",
                                fieldKey:	"",
                                fieldName:	""
                            },
                            ...
                        ]
                    },
                    ...
                ],
                redHead: //可空
                [
                    xxx,
                    ...
                ]
            },
            isCollect:	false
        }
    }
}

获取公文字段
URI:/DocumentMoa/getDocumentFields
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    id:	xxx
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        fields:
        [
            {
                fieldId:	xxx,
                fieldType:	"xxxxxxxx",
                fieldName:	"xxxxxxxx",
                aliasName:	"",
                customName:	"",
                isFill:	false,    //是否必填
                property:	"",    //字段属性,存储jason格式
                value:	"",
                extraValue:	"",
                isCard:	false,
                cardId:	0,
                children: //可空
                [
                    {
                        fieldId:	0,
                        fieldType:	"",
                        fieldName:	"",
                        aliasName:	"",
                        customName:	"",
                        isFill:	false,    //是否必填
                        property:	"",    //字段属性,存储jason格式
                        value:	"",
                        extraValue:	"",
                        isCard:	false,
                        cardId:	0
                    },
                    ...
                ],
                refNoChildren: //可空
                [
                    {
                        fieldType:	"",
                        fieldKey:	"",
                        fieldName:	""
                    },
                    ...
                ]
            },
            ...
        ]
    }
}

修改公文字段
URI:/DocumentMoa/modDocumentFields
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    id:	xxx,
    fields:
    [
        {
            fieldId:	xxx,
            fieldType:	"xxxxxxxx",
            fieldName:	"xxxxxxxx",
            aliasName:	"",
            customName:	"",
            isFill:	false,    //是否必填
            property:	"",    //字段属性,存储jason格式
            value:	"",
            extraValue:	"",
            isCard:	false,
            cardId:	0,
            children: //可空
            [
                {
                    fieldId:	0,
                    fieldType:	"",
                    fieldName:	"",
                    aliasName:	"",
                    customName:	"",
                    isFill:	false,    //是否必填
                    property:	"",    //字段属性,存储jason格式
                    value:	"",
                    extraValue:	"",
                    isCard:	false,
                    cardId:	0
                },
                ...
            ],
            refNoChildren: //可空
            [
                {
                    fieldType:	"",
                    fieldKey:	"",
                    fieldName:	""
                },
                ...
            ]
        },
        ...
    ]
}
RESPONSE DATA:
{
    retcode:	0
}

催一催,type 1:应用内，2:短信 3:语音
URI:/DocumentMoa/urgeDocument
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    id:	xxx,
    types: //可空
    [
        xxx,
        ...
    ]
}
RESPONSE DATA:
{
    retcode:	0
}

获取附件
URI:/DocumentMoa/getDocumentAttachments
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    id:	xxx
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        value:	"xxxxxxxx"
    }
}

获取一键分发的人员
URI:/DocumentMoa/getOneKeySenderUsers
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    id:	xxx
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        hostUsers:
        [
            {
                uid:	"xxxxxxxx",
                name:	"xxxxxxxx",
                operType:	0,
                operTime:	0,
                opinion:	"",
                orgId:	0,
                orgName:	"",
                deptId:	0,
                deptName:	""
            },
            ...
        ],
        coUsers:
        [
            {
                uid:	"xxxxxxxx",
                name:	"xxxxxxxx",
                operType:	0,
                operTime:	0,
                opinion:	"",
                orgId:	0,
                orgName:	"",
                deptId:	0,
                deptName:	""
            },
            ...
        ]
    }
}

暂时保留
URI:/DocumentMoa/getDocumentFlowListByUser
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        flows:
        [
            {
                id:	xxx,
                name:	"xxxxxxxx",
                type:	xxx,
                childType:	xxx,
                isCommon:	xxx
            },
            ...
        ],
        commonFlows:
        [
            {
                id:	xxx,
                name:	"xxxxxxxx",
                type:	xxx,
                childType:	xxx,
                isCommon:	xxx
            },
            ...
        ]
    }
}

URI:/DocumentMoa/getDocumentFlowByUser
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    flowId:	xxx
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        flow:
        {
            id:	xxx,
            name:	"xxxxxxxx",
            type:	xxx,
            childType:	xxx,
            fields:
            [
                {
                    fieldId:	xxx,
                    fieldType:	"xxxxxxxx",
                    fieldName:	"xxxxxxxx",
                    aliasName:	"",
                    customName:	"",
                    isFill:	false,    //是否必填
                    property:	"",    //字段属性,存储jason格式
                    value:	"",
                    extraValue:	"",
                    isCard:	false,
                    cardId:	0,
                    children: //可空
                    [
                        {
                            fieldId:	0,
                            fieldType:	"",
                            fieldName:	"",
                            aliasName:	"",
                            customName:	"",
                            isFill:	false,    //是否必填
                            property:	"",    //字段属性,存储jason格式
                            value:	"",
                            extraValue:	"",
                            isCard:	false,
                            cardId:	0
                        },
                        ...
                    ],
                    refNoChildren: //可空
                    [
                        {
                            fieldType:	"",
                            fieldKey:	"",
                            fieldName:	""
                        },
                        ...
                    ]
                },
                ...
            ],
            redHead: //可空
            [
                xxx,
                ...
            ]
        }
    }
}

*下载一键下载
URI:/DocumentMoa/downloadDocument
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    id:	xxx
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        url:	"xxxxxxxx"
    }
}

批量下载接口
URI:/DocumentMoa/downloadDocumentFiles
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    id:	xxx,
    fileUrls:
    {
        "xxxxxxxx":
        "xxxxxxxx",
        ...
    }
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        taskId:	xxx
    }
}

获取下载状态(admin handle)
URI:/DocumentMoa/getDownloadStatus
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    id:	xxx,
    taskId:	xxx
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        status:	xxx,
        url:	"xxxxxxxx"
    }
}

获取下载记录(admin handle)
URI:/DocumentMoa/getDownloadRecords
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    id:	xxx,
    pageId:	xxx,
    pageCount:	xxx
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        allCount:	xxx,
        records:
        [
            {
                name:	"xxxxxxxx",
                url:	"xxxxxxxx",
                status:	xxx,    //1:进行中 2:已完成 3:失败
                operTime:	xxx,
                id:	xxx
            },
            ...
        ]
    }
}

删除下载记录(admin handle)
URI:/DocumentMoa/delDownloadRecord
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    id:	xxx,
    taskId:	xxx
}
RESPONSE DATA:
{
    retcode:	0
}

自动生成文号 (admin handle)
URI:/DocumentMoa/genRefNo
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    id:	xxx,
    year:	xxx
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        refNo:	xxx
    }
}

URI:/DocumentMoa/checkRefNo
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    id:	xxx,
    year:	xxx,
    refNo:	xxx
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        isRep:	x
    }
}

获取文号历史记录(admin handle)
URI:/DocumentMoa/getRefNoList
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    ids:
    [
        xxx,
        ...
    ]
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        refNos:
        [
            {
                id:	xxx,
                name:	"xxxxxxxx"
            },
            ...
        ]
    }
}

对外发文接口
创建发文
URI:/DocumentMoa/createDocumentOut
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    create:
    {
        title:	"xxxxxxxx",
        refNo:	"xxxxxxxx",
        fromOrg:
        {
            orgId:	xxx,
            orgName:	"xxxxxxxx"
        },
        toOrgs:
        [
            {
                orgId:	xxx,
                orgName:	"xxxxxxxx"
            },
            ...
        ],
        files:	"xxxxxxxx",
        attachments:	"",
        urgencyLevel:	"",    //紧急程度
        secretClass:	""    //密级
    }
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        id:	xxx
    }
}

撤销发文
URI:/DocumentMoa/recallDocumentOut
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    id:	xxx
}
RESPONSE DATA:
{
    retcode:	0
}

获取发文详情
URI:/DocumentMoa/getDocumentOutDetail
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    id:	xxx
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        info:
        {
            title:	"xxxxxxxx",
            refNo:	"xxxxxxxx",
            status:	xxx,    //1：正常状态 2：撤回
            fromOrg:
            {
                orgId:	xxx,
                orgName:	"xxxxxxxx",
                sendTime:	0,
                sendUid:	"",
                recallTime:	0,
                recallUid:	"",
                sendName:	"",
                recallName:	"",
                urgeTime:	0
            },
            toOrgs:
            [
                {
                    orgId:	xxx,
                    orgName:	"xxxxxxxx",
                    signTime:	0,
                    signUid:	"",
                    signOpinion:	"",
                    backTime:	0,
                    backUid:	"",
                    backOpinion:	"",
                    signName:	"",
                    backName:	""
                },
                ...
            ],
            files:	"xxxxxxxx",
            attachments:	"",
            urgencyLevel:	"",
            secretClass:	""
        }
    }
}

获取来文详情
URI:/DocumentMoa/getDocumentOutToDetail
METHOD:POST
REQUEST PARAMETERS:
{
    fromOrgId:	xxx,
    orgId:	xxx,
    id:	xxx
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        info:
        {
            title:	"xxxxxxxx",
            refNo:	"xxxxxxxx",
            status:	xxx,    //1：正常状态 2：撤回
            fromOrg:
            {
                orgId:	xxx,
                orgName:	"xxxxxxxx",
                sendTime:	0,
                sendUid:	"",
                recallTime:	0,
                recallUid:	"",
                sendName:	"",
                recallName:	"",
                urgeTime:	0
            },
            toOrgs:
            [
                {
                    orgId:	xxx,
                    orgName:	"xxxxxxxx",
                    signTime:	0,
                    signUid:	"",
                    signOpinion:	"",
                    backTime:	0,
                    backUid:	"",
                    backOpinion:	"",
                    signName:	"",
                    backName:	""
                },
                ...
            ],
            files:	"xxxxxxxx",
            attachments:	"",
            urgencyLevel:	"",
            secretClass:	""
        }
    }
}

对外发文列表
URI:/DocumentMoa/getDocumentOutFromList
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    screen:
    {
        title:	"",
        beginTime:	0,
        endTime:	0,
        tab:	1    //1:待登记  2:已登记
    },
    pageId:	xxx,
    pageCount:	xxx
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        allCount:	xxx,
        infos:
        [
            {
                id:	xxx,
                title:	"xxxxxxxx",
                refNo:	"xxxxxxxx",
                status:	xxx,
                sendTime:	xxx,
                toOrgs:
                [
                    {
                        orgId:	xxx,
                        orgName:	"xxxxxxxx",
                        signTime:	0,
                        signUid:	"",
                        signOpinion:	"",
                        backTime:	0,
                        backUid:	"",
                        backOpinion:	"",
                        signName:	"",
                        backName:	""
                    },
                    ...
                ],
                sendName:	"xxxxxxxx",
                urgencyLevel:	"",
                secretClass:	""
            },
            ...
        ]
    }
}

来文管理列表
URI:/DocumentMoa/getDocumentOutToList
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    screen:
    {
        title:	"",
        beginTime:	0,
        endTime:	0,
        tab:	1    //1:待登记  2:已登记
    },
    pageId:	xxx,
    pageCount:	xxx
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        allCount:	xxx,
        infos:
        [
            {
                id:	xxx,
                title:	"xxxxxxxx",
                refNo:	"xxxxxxxx",
                status:	xxx,
                fromOrgId:	xxx,
                fromOrgName:	"xxxxxxxx",
                sendTime:	xxx,
                signTime:	xxx,
                backTime:	xxx,
                sendName:	"xxxxxxxx",
                signName:	"xxxxxxxx",
                backName:	"xxxxxxxx",
                urgencyLevel:	"",
                secretClass:	""
            },
            ...
        ]
    }
}

退回
URI:/DocumentMoa/backDocumentOut
METHOD:POST
REQUEST PARAMETERS:
{
    fromOrgId:	xxx,
    orgId:	xxx,
    id:	xxx,
    opinion:	"xxxxxxxx"
}
RESPONSE DATA:
{
    retcode:	0
}

签收
URI:/DocumentMoa/signDocumentOut
METHOD:POST
REQUEST PARAMETERS:
{
    fromOrgId:	xxx,
    orgId:	xxx,
    id:	xxx,
    opinion:	"xxxxxxxx"
}
RESPONSE DATA:
{
    retcode:	0
}

对外发文催一催
URI:/DocumentMoa/urgeDocumentOut
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    id:	xxx,
    types: //可空
    [
        xxx,
        ...
    ]
}
RESPONSE DATA:
{
    retcode:	0
}

doc转pdf
URI:/DocumentMoa/doc2pdf
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    fileName:	"xxxxxxxx",
    srcUrl:	"xxxxxxxx"
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        descUrl:	"xxxxxxxx"
    }
}

云盘url转存到文件系统
URI:/DocumentMoa/transformUrl
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    srcUrl:	"xxxxxxxx",
    isWps:	false
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        descUrl:	"xxxxxxxx"
    }
}

获取上一次签名记录(admin handle)
URI:/DocumentMoa/getUserLastSign
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        url:	"xxxxxxxx"
    }
}

报存签名记录(admin handle)
URI:/DocumentMoa/svUserSign
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    url:	"xxxxxxxx"
}
RESPONSE DATA:
{
    retcode:	0
}

获取公文数字接口,1:处理中的，2:收文登记 3:集团来文(admin handle)
URI:/DocumentMoa/getDocumentNum
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    types:
    [
        xxx,
        ...
    ]
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        nums:
        {
            xxx:
            xxx,
            ...
        }
    }
}

获取水印(admin handle)
URI:/DocumentMoa/getDocumentWatermark
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        watermark:
        {
            openWatermark:	false,
            type:	1,    //1:姓名和后四位  2:自定义
            customize:	""    //自定义内容
        }
    }
}

加水印(admin handle)
URI:/DocumentMoa/addWatermark
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    url:	"xxxxxxxx"
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        descUrl:	"xxxxxxxx"
    }
}

回收箱 get
URI:/DocumentMoa/getDocumentRecycle
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    id:	xxx
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        info:
        {
            orgId:	xxx,
            deptId:	0,
            deptName:	"",
            createUid:	"xxxxxxxx",
            createName:	"xxxxxxxx",
            createMobile:	"xxxxxxxx",
            createTime:	xxx,
            endTime:	xxx,
            type:	xxx,
            template_id:	xxx,
            status:	xxx,    //1:处理中 2:完成 3:撤回 10:删除
            title:	"xxxxxxxx",
            refNo:	"xxxxxxxx",
            urgencyLevel:	0,
            secret_class:	0,
            fileType:	0,
            biz_type:	0,
            biz_id:	"",
            isFile:	false,
            isSeal:	false,
            fields: //可空
            [
                {
                    fieldId:	xxx,
                    fieldType:	"xxxxxxxx",
                    fieldName:	"xxxxxxxx",
                    aliasName:	"",
                    customName:	"",
                    isFill:	false,    //是否必填
                    property:	"",    //字段属性,存储jason格式
                    value:	"",
                    extraValue:	"",
                    isCard:	false,
                    cardId:	0,
                    children: //可空
                    [
                        {
                            fieldId:	0,
                            fieldType:	"",
                            fieldName:	"",
                            aliasName:	"",
                            customName:	"",
                            isFill:	false,    //是否必填
                            property:	"",    //字段属性,存储jason格式
                            value:	"",
                            extraValue:	"",
                            isCard:	false,
                            cardId:	0
                        },
                        ...
                    ],
                    refNoChildren: //可空
                    [
                        {
                            fieldType:	"",
                            fieldKey:	"",
                            fieldName:	""
                        },
                        ...
                    ]
                },
                ...
            ],
            documentTemplate:
            {
                id:	xxx,
                name:	"xxxxxxxx",
                type:	xxx,
                childType:	xxx,
                fields:
                [
                    {
                        fieldId:	xxx,
                        fieldType:	"xxxxxxxx",
                        fieldName:	"xxxxxxxx",
                        aliasName:	"",
                        customName:	"",
                        isFill:	false,    //是否必填
                        property:	"",    //字段属性,存储jason格式
                        value:	"",
                        extraValue:	"",
                        isCard:	false,
                        cardId:	0,
                        children: //可空
                        [
                            {
                                fieldId:	0,
                                fieldType:	"",
                                fieldName:	"",
                                aliasName:	"",
                                customName:	"",
                                isFill:	false,    //是否必填
                                property:	"",    //字段属性,存储jason格式
                                value:	"",
                                extraValue:	"",
                                isCard:	false,
                                cardId:	0
                            },
                            ...
                        ],
                        refNoChildren: //可空
                        [
                            {
                                fieldType:	"",
                                fieldKey:	"",
                                fieldName:	""
                            },
                            ...
                        ]
                    },
                    ...
                ],
                redHead: //可空
                [
                    xxx,
                    ...
                ]
            },
            isCollect:	false
        }
    }
}

回收箱 get
URI:/DocumentMoa/getDocumentRecycleListByMgr
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        infos:
        [
            {
                id:	xxx,
                title:	"xxxxxxxx",
                refNo:	"xxxxxxxx",
                type:	xxx,
                delUid:	"xxxxxxxx",
                delName:	"xxxxxxxx",
                delTime:	xxx,
                createUid:	"xxxxxxxx",
                createName:	"xxxxxxxx",
                createTime:	xxx
            },
            ...
        ]
    }
}

回收箱 clear
URI:/DocumentMoa/clearDocumentRecycle
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx
}
RESPONSE DATA:
{
    retcode:	0
}

回收箱 del
URI:/DocumentMoa/delDocumentRecycle
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    id:	xxx
}
RESPONSE DATA:
{
    retcode:	0
}

草稿 save
URI:/DocumentMoa/saveDocumentDraft
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    info:
    {
        templateID:	xxx,
        fields:
        [
            {
                fieldId:	xxx,
                fieldType:	"xxxxxxxx",
                fieldName:	"xxxxxxxx",
                aliasName:	"",
                customName:	"",
                isFill:	false,    //是否必填
                property:	"",    //字段属性,存储jason格式
                value:	"",
                extraValue:	"",
                isCard:	false,
                cardId:	0,
                children: //可空
                [
                    {
                        fieldId:	0,
                        fieldType:	"",
                        fieldName:	"",
                        aliasName:	"",
                        customName:	"",
                        isFill:	false,    //是否必填
                        property:	"",    //字段属性,存储jason格式
                        value:	"",
                        extraValue:	"",
                        isCard:	false,
                        cardId:	0
                    },
                    ...
                ],
                refNoChildren: //可空
                [
                    {
                        fieldType:	"",
                        fieldKey:	"",
                        fieldName:	""
                    },
                    ...
                ]
            },
            ...
        ],
        type:	xxx,
        createTime:	0,
        id:	0
    }
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        id:	xxx
    }
}

草稿 mod
URI:/DocumentMoa/modDocumentDraft
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    id:	xxx,
    fields:
    [
        {
            fieldId:	xxx,
            fieldType:	"xxxxxxxx",
            fieldName:	"xxxxxxxx",
            aliasName:	"",
            customName:	"",
            isFill:	false,    //是否必填
            property:	"",    //字段属性,存储jason格式
            value:	"",
            extraValue:	"",
            isCard:	false,
            cardId:	0,
            children: //可空
            [
                {
                    fieldId:	0,
                    fieldType:	"",
                    fieldName:	"",
                    aliasName:	"",
                    customName:	"",
                    isFill:	false,    //是否必填
                    property:	"",    //字段属性,存储jason格式
                    value:	"",
                    extraValue:	"",
                    isCard:	false,
                    cardId:	0
                },
                ...
            ],
            refNoChildren: //可空
            [
                {
                    fieldType:	"",
                    fieldKey:	"",
                    fieldName:	""
                },
                ...
            ]
        },
        ...
    ]
}
RESPONSE DATA:
{
    retcode:	0
}

草稿 get
URI:/DocumentMoa/getDocumentDraftList
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    pageId:	xxx,
    pageCount:	xxx
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        allCount:	xxx,
        infos:
        [
            {
                templateID:	xxx,
                fields:
                [
                    {
                        fieldId:	xxx,
                        fieldType:	"xxxxxxxx",
                        fieldName:	"xxxxxxxx",
                        aliasName:	"",
                        customName:	"",
                        isFill:	false,    //是否必填
                        property:	"",    //字段属性,存储jason格式
                        value:	"",
                        extraValue:	"",
                        isCard:	false,
                        cardId:	0,
                        children: //可空
                        [
                            {
                                fieldId:	0,
                                fieldType:	"",
                                fieldName:	"",
                                aliasName:	"",
                                customName:	"",
                                isFill:	false,    //是否必填
                                property:	"",    //字段属性,存储jason格式
                                value:	"",
                                extraValue:	"",
                                isCard:	false,
                                cardId:	0
                            },
                            ...
                        ],
                        refNoChildren: //可空
                        [
                            {
                                fieldType:	"",
                                fieldKey:	"",
                                fieldName:	""
                            },
                            ...
                        ]
                    },
                    ...
                ],
                type:	xxx,
                createTime:	0,
                id:	0
            },
            ...
        ]
    }
}

草稿 del
URI:/DocumentMoa/delDocumentDraft
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    id:	xxx
}
RESPONSE DATA:
{
    retcode:	0
}

草稿 get
URI:/DocumentMoa/getDocumentDraftInfo
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    id:	xxx
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        info:
        {
            templateID:	xxx,
            fields:
            [
                {
                    fieldId:	xxx,
                    fieldType:	"xxxxxxxx",
                    fieldName:	"xxxxxxxx",
                    aliasName:	"",
                    customName:	"",
                    isFill:	false,    //是否必填
                    property:	"",    //字段属性,存储jason格式
                    value:	"",
                    extraValue:	"",
                    isCard:	false,
                    cardId:	0,
                    children: //可空
                    [
                        {
                            fieldId:	0,
                            fieldType:	"",
                            fieldName:	"",
                            aliasName:	"",
                            customName:	"",
                            isFill:	false,    //是否必填
                            property:	"",    //字段属性,存储jason格式
                            value:	"",
                            extraValue:	"",
                            isCard:	false,
                            cardId:	0
                        },
                        ...
                    ],
                    refNoChildren: //可空
                    [
                        {
                            fieldType:	"",
                            fieldKey:	"",
                            fieldName:	""
                        },
                        ...
                    ]
                },
                ...
            ],
            type:	xxx,
            createTime:	0,
            id:	0
        }
    }
}

收藏公文
URI:/DocumentMoa/collectDocument
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    id:	xxx
}
RESPONSE DATA:
{
    retcode:	0
}

取消收藏公文
URI:/DocumentMoa/unCollectDocument
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    id:	xxx
}
RESPONSE DATA:
{
    retcode:	0
}

获取收藏公文list
URI:/DocumentMoa/getCollectDocumentList
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    screen:
    {
        title:	"",
        beginTime:	0,
        endTime:	0,
        type:	0,
        tab:	1,    //0：全部 1: 待办理 2: 已办理 3：进行中 4：待查阅 5：已查阅 6：已撤销 7：我发起的
        templateIds: //可空
        [
            xxx,
            ...
        ],    //模板id
        createUids: //可空
        [
            "xxxxxxxx",
            ...
        ],    //创建人,公文查询新增筛选条件
        doneUids: //可空
        [
            "xxxxxxxx",
            ...
        ],    //经办人,公文查询新增筛选条件
        status: //可空
        [
            xxx,
            ...
        ],
        otherOrgId:	0,
        deptIds: //可空
        [
            xxx,
            ...
        ],    //部分id
        refNo1:	"",
        refNo2:	"",
        refNo3:	"",
        templateName:	""    //模板名字模糊搜索，给对外发文搜公司函特地加的
    },
    pageId:	xxx,
    pageNum:	xxx
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        allCount:	xxx,
        basics:
        [
            {
                id:	xxx,
                createUid:	"xxxxxxxx",
                createName:	"xxxxxxxx",
                createTime:	xxx,
                status:	xxx,
                type:	xxx,
                isFile:	false,
                endTime:	0,
                templateId:	0,
                templateName:	"",
                bizId:	"",
                fields: //可空
                [
                    {
                        fieldId:	xxx,
                        fieldType:	"xxxxxxxx",
                        fieldName:	"xxxxxxxx",
                        aliasName:	"",
                        customName:	"",
                        isFill:	false,    //是否必填
                        property:	"",    //字段属性,存储jason格式
                        value:	"",
                        extraValue:	"",
                        isCard:	false,
                        cardId:	0,
                        children: //可空
                        [
                            {
                                fieldId:	0,
                                fieldType:	"",
                                fieldName:	"",
                                aliasName:	"",
                                customName:	"",
                                isFill:	false,    //是否必填
                                property:	"",    //字段属性,存储jason格式
                                value:	"",
                                extraValue:	"",
                                isCard:	false,
                                cardId:	0
                            },
                            ...
                        ],
                        refNoChildren: //可空
                        [
                            {
                                fieldType:	"",
                                fieldKey:	"",
                                fieldName:	""
                            },
                            ...
                        ]
                    },
                    ...
                ]
            },
            ...
        ]
    }
}

差错公文接口
获取差错公文详情
URI:/DocumentMoa/setDocumentErrInfo
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    id:	xxx,
    errs:
    [
        {
            field:	"xxxxxxxx",
            subField:	"xxxxxxxx",
            errContent:	"xxxxxxxx",
            correctContent:	"xxxxxxxx",
            remark:	"xxxxxxxx"
        },
        ...
    ]
}
RESPONSE DATA:
{
    retcode:	0
}

URI:/DocumentMoa/getDocumentErrInfo
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    id:	xxx
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        isExist:	x,
        info:
        {
            documentId:	xxx,
            title:	"xxxxxxxx",
            refNo:	"xxxxxxxx",
            type:	xxx,
            deptName:	"xxxxxxxx",
            errs:
            [
                {
                    field:	"xxxxxxxx",
                    subField:	"xxxxxxxx",
                    errContent:	"xxxxxxxx",
                    correctContent:	"xxxxxxxx",
                    remark:	"xxxxxxxx"
                },
                ...
            ],
            createUid:	"xxxxxxxx",
            createName:	"xxxxxxxx",
            createTime:	xxx
        }
    }
}

URI:/DocumentMoa/delDocumentErrInfo
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    id:	xxx
}
RESPONSE DATA:
{
    retcode:	0
}

URI:/DocumentMoa/getDocumentErrList
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    screen:
    {
        title:	"",
        type:	0
    },
    pageId:	xxx,
    pageCount:	xxx
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        allCount:	xxx,
        infos:
        [
            {
                documentId:	xxx,
                title:	"xxxxxxxx",
                refNo:	"xxxxxxxx",
                type:	xxx,
                deptName:	"xxxxxxxx",
                errs:
                [
                    {
                        field:	"xxxxxxxx",
                        subField:	"xxxxxxxx",
                        errContent:	"xxxxxxxx",
                        correctContent:	"xxxxxxxx",
                        remark:	"xxxxxxxx"
                    },
                    ...
                ],
                createUid:	"xxxxxxxx",
                createName:	"xxxxxxxx",
                createTime:	xxx
            },
            ...
        ]
    }
}

URI:/DocumentMoa/exportDocumentErrList
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    ids:
    [
        xxx,
        ...
    ],
    isAll:	false
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        url:	"xxxxxxxx"
    }
}

URI:/DocumentMoa/getUserErrFields
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        errFields:
        [
            {
                value:	"xxxxxxxx",
                subFields:
                [
                    "xxxxxxxx",
                    ...
                ]
            },
            ...
        ]
    }
}

URI:/DocumentMoa/setUserErrFields
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    errFields:
    [
        {
            value:	"xxxxxxxx",
            subFields:
            [
                "xxxxxxxx",
                ...
            ]
        },
        ...
    ]
}
RESPONSE DATA:
{
    retcode:	0
}

URI:/DocumentMoa/addUserErrSubField
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    field:	"xxxxxxxx",
    subField:	"xxxxxxxx"
}
RESPONSE DATA:
{
    retcode:	0
}

moa公文需求
获取集团公司列表
URI:/DocumentMoa/getGroupOrgList
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        orgs:
        [
            {
                orgLevel:	"xxxxxxxx",
                orgCode:	"xxxxxxxx",
                shortOrgName:	"xxxxxxxx",
                updateTime:	"xxxxxxxx",
                orgStyle:	"xxxxxxxx",
                order:	"xxxxxxxx",
                allOrgName:	"xxxxxxxx",
                orgType:	"xxxxxxxx",
                permittedDocType:
                [
                    "xxxxxxxx",
                    ...
                ]
            },
            ...
        ]
    }
}

获取集团公文列表
URI:/DocumentMoa/getGroupDocumentList
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    screen:
    {
        title:	"",
        beginTime:	0,
        endTime:	0,
        tab:	1    //1:待登记  2:已登记
    },
    pageId:	xxx,
    pageCount:	xxx
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        allCount:	xxx,
        infos:
        [
            {
                id:	xxx,
                docInfo:
                {
                    docUid:	"xxxxxxxx",
                    serialNum:	"xxxxxxxx",
                    docStyle:	"xxxxxxxx",    //:UP-上行文 PARALLEL-平行文 DOWN-下行文 RETURN-退文处理单:/
                    docType:	"xxxxxxxx",    //应该对应的templateName
                    issuingUnit:	"xxxxxxxx",    //发文单位
                    receivingCompany:	"xxxxxxxx",    //收文公司
                    receivingCompanyCode:	"xxxxxxxx",    //收文公司唯一编码
                    receivingDepartment:	"xxxxxxxx",    //收文部门
                    receivingDepartmentCode:	"xxxxxxxx",    //收文部门唯一编码
                    docTitle:	"xxxxxxxx",    //标题
                    docNumber:	"xxxxxxxx",    //文号
                    docSecret:	"xxxxxxxx",    //密级
                    docUrgency:	"xxxxxxxx",    //文件缓急
                    docSubject:	"xxxxxxxx",    //主题词
                    receiveType:	"xxxxxxxx",    //接收类型标记空表示为省公司上行发文，1表示为服务公司上行发文，其他取值暂保留
                    createTime:	"xxxxxxxx",
                    testStatus:	"xxxxxxxx"
                },
                files:
                [
                    {
                        docUid:	"xxxxxxxx",
                        attachUid:	"xxxxxxxx",
                        attachType:	"xxxxxxxx",
                        attachName:	"xxxxxxxx",
                        attachBelong:	"xxxxxxxx",
                        filePath:	"xxxxxxxx"
                    },
                    ...
                ],
                status:	xxx,
                signUid:	"",
                signName:	"",
                signTime:	0
            },
            ...
        ]
    }
}

获取集团详情接口
URI:/DocumentMoa/getGroupDocumentInfo
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    id:	xxx
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        info:
        {
            id:	xxx,
            docInfo:
            {
                docUid:	"xxxxxxxx",
                serialNum:	"xxxxxxxx",
                docStyle:	"xxxxxxxx",    //:UP-上行文 PARALLEL-平行文 DOWN-下行文 RETURN-退文处理单:/
                docType:	"xxxxxxxx",    //应该对应的templateName
                issuingUnit:	"xxxxxxxx",    //发文单位
                receivingCompany:	"xxxxxxxx",    //收文公司
                receivingCompanyCode:	"xxxxxxxx",    //收文公司唯一编码
                receivingDepartment:	"xxxxxxxx",    //收文部门
                receivingDepartmentCode:	"xxxxxxxx",    //收文部门唯一编码
                docTitle:	"xxxxxxxx",    //标题
                docNumber:	"xxxxxxxx",    //文号
                docSecret:	"xxxxxxxx",    //密级
                docUrgency:	"xxxxxxxx",    //文件缓急
                docSubject:	"xxxxxxxx",    //主题词
                receiveType:	"xxxxxxxx",    //接收类型标记空表示为省公司上行发文，1表示为服务公司上行发文，其他取值暂保留
                createTime:	"xxxxxxxx",
                testStatus:	"xxxxxxxx"
            },
            files:
            [
                {
                    docUid:	"xxxxxxxx",
                    attachUid:	"xxxxxxxx",
                    attachType:	"xxxxxxxx",
                    attachName:	"xxxxxxxx",
                    attachBelong:	"xxxxxxxx",
                    filePath:	"xxxxxxxx"
                },
                ...
            ],
            status:	xxx,
            signUid:	"",
            signName:	"",
            signTime:	0
        }
    }
}

签收集团公文
URI:/DocumentMoa/signGroupDocument
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    id:	xxx
}
RESPONSE DATA:
{
    retcode:	0
}

给集团发送公文
URI:/DocumentMoa/sendGroupDocument
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    id:	xxx,
    orgs:
    [
        {
            orgLevel:	"xxxxxxxx",
            orgCode:	"xxxxxxxx",
            shortOrgName:	"xxxxxxxx",
            updateTime:	"xxxxxxxx",
            orgStyle:	"xxxxxxxx",
            order:	"xxxxxxxx",
            allOrgName:	"xxxxxxxx",
            orgType:	"xxxxxxxx",
            permittedDocType:
            [
                "xxxxxxxx",
                ...
            ]
        },
        ...
    ]
}
RESPONSE DATA:
{
    retcode:	0
}

获取公文列表(admin handle)
URI:/DocumentMoa/getDocumentListByOtherOrg
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    screen:
    {
        title:	"",
        beginTime:	0,
        endTime:	0,
        type:	0,
        tab:	1,    //0：全部 1: 待办理 2: 已办理 3：进行中 4：待查阅 5：已查阅 6：已撤销 7：我发起的
        templateIds: //可空
        [
            xxx,
            ...
        ],    //模板id
        createUids: //可空
        [
            "xxxxxxxx",
            ...
        ],    //创建人,公文查询新增筛选条件
        doneUids: //可空
        [
            "xxxxxxxx",
            ...
        ],    //经办人,公文查询新增筛选条件
        status: //可空
        [
            xxx,
            ...
        ],
        otherOrgId:	0,
        deptIds: //可空
        [
            xxx,
            ...
        ],    //部分id
        refNo1:	"",
        refNo2:	"",
        refNo3:	"",
        templateName:	""    //模板名字模糊搜索，给对外发文搜公司函特地加的
    },
    pageId:	xxx,
    pageCount:	xxx
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        allCount:	xxx,
        infos:
        [
            {
                id:	xxx,
                createUid:	"xxxxxxxx",
                createName:	"xxxxxxxx",
                createTime:	xxx,
                status:	xxx,
                type:	xxx,
                isFile:	false,
                endTime:	0,
                templateId:	0,
                templateName:	"",
                bizId:	"",
                fields: //可空
                [
                    {
                        fieldId:	xxx,
                        fieldType:	"xxxxxxxx",
                        fieldName:	"xxxxxxxx",
                        aliasName:	"",
                        customName:	"",
                        isFill:	false,    //是否必填
                        property:	"",    //字段属性,存储jason格式
                        value:	"",
                        extraValue:	"",
                        isCard:	false,
                        cardId:	0,
                        children: //可空
                        [
                            {
                                fieldId:	0,
                                fieldType:	"",
                                fieldName:	"",
                                aliasName:	"",
                                customName:	"",
                                isFill:	false,    //是否必填
                                property:	"",    //字段属性,存储jason格式
                                value:	"",
                                extraValue:	"",
                                isCard:	false,
                                cardId:	0
                            },
                            ...
                        ],
                        refNoChildren: //可空
                        [
                            {
                                fieldType:	"",
                                fieldKey:	"",
                                fieldName:	""
                            },
                            ...
                        ]
                    },
                    ...
                ]
            },
            ...
        ]
    }
}

获取密集清单(admin handle)
URI:/DocumentMoa/getItemClassify
METHOD:GET/POST
REQUEST PARAMETERS:
{
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        info:
        {
            itemType:
            [
                "xxxxxxxx",
                ...
            ],
            itemSubType:
            [
                "xxxxxxxx",
                ...
            ],
            deptName:
            [
                "xxxxxxxx",
                ...
            ]
        }
    }
}

URI:/DocumentMoa/getItemSecretList
METHOD:POST
REQUEST PARAMETERS:
{
    screen:
    {
        itemType:	"",
        itemSubType:	"",
        deptName:	"",
        itemInfo:	""
    },
    pageId:	xxx,
    pageCount:	xxx
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        allCount:	xxx,
        infos:
        [
            {
                itemType:	"xxxxxxxx",
                itemSubType:	"xxxxxxxx",
                itemInfo:	"xxxxxxxx",
                secretClass:	"xxxxxxxx",
                secretTime:	"xxxxxxxx",
                deptName:	"xxxxxxxx"
            },
            ...
        ]
    }
}

 获取组织可收文用户(admin handle)
URI:/DocumentMoa/getOrgSenders
METHOD:POST
REQUEST PARAMETERS:
{
    orgs:
    [
        {
            orgId:	xxx,
            orgName:	"xxxxxxxx"
        },
        ...
    ]
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        orgSenders:
        [
            {
                orgId:	xxx,
                orgName:	"xxxxxxxx",
                users:
                [
                    {
                        uid:	"xxxxxxxx",
                        name:	"xxxxxxxx",
                        deptId:	-1,
                        deptName:	"",
                        orgId:	0,
                        orgName:	""
                    },
                    ...
                ]
            },
            ...
        ]
    }
}
```

### 接口差异对比

```
//创建公文
URI:/DocumentMoa/createDocument 传入参数有变化

URI:/DocumentMoa/createAndSendDocument 已删除

//其他业务创建公文
URI:/DocumentMoa/createDocumentByBusiness 已删除

//获取其他业务创建的公文id
URI:/DocumentMoa/getDocumentIdByBusiness 已删除

//提交公文
URI:/DocumentMoa/submitDocument 已删除

//领导提交
URI:/DocumentMoa/submitDocumentByLeader 已删除

//仅仅提交
URI:/DocumentMoa/submitDocumentOnly 已删除

//重新提交
URI:/DocumentMoa/resubmitDocument 已删除

//代替提交
URI:/DocumentMoa/agentSubmitDocument 已删除

//转办
URI:/DocumentMoa/turnDocument 已删除

退回
URI:/DocumentMoa/backSubmitDocument 已删除

重新发起公文
URI:/DocumentMoa/reCreateDocument 无变化


URI:/DocumentMoa/reCreateAndSendDocument 已删除

获取字段
URI:/DocumentMoa/getDocumentFields 返回参数有修改

修改字段
URI:/DocumentMoa/modDocumentFields 传参有修改

处理正文
URI:/DocumentMoa/dealDocumentBodyFile 已删除

催一催,type 1:应用内，2:短信 3:语音
URI:/DocumentMoa/urgeDocument 无变化

删除公文
URI:/DocumentMoa/delDocument 无变化

撤回公文
URI:/DocumentMoa/recallDocument 已删除

获取公文详情
URI:/DocumentMoa/getDocumentDetail 返回参数有变化

个人获取公文列表
URI:/DocumentMoa/getDocumentList 无变化

管理员获取公司公文列表
URI:/DocumentMoa/getDocumentListByMgr 无变化

获取节点
URI:/DocumentMoa/getDocumentSteps 已删除

变更流程
URI:/DocumentMoa/modDocumentSteps 已删除

分送公文
URI:/DocumentMoa/sendDocument 已删除

已阅
URI:/DocumentMoa/submitDocumentBySendUser 已删除

URI:/DocumentMoa/getLeader 已删除

URI:/DocumentMoa/submitAndSendDocument 已删除

URI:/DocumentMoa/getDocumentAttachments 无变化

获取一键分发的人员
URI:/DocumentMoa/getOneKeySenderUsers 无变化

一键分发
URI:/DocumentMoa/sendDocumentOneKey 已删除

批量下载接口
URI:/DocumentMoa/downloadDocumentFiles 无变化

URI:/DocumentMoa/getDownloadStatus 无变化

URI:/DocumentMoa/getDownloadRecords 无变化

URI:/DocumentMoa/delDownloadRecord 无变化

自动生成文号
URI:/DocumentMoa/genRefNo 无变化

URI:/DocumentMoa/checkRefNo 无变化

获取文号历史记录
URI:/DocumentMoa/getRefNoList 无变化

获取文号历史记录
URI:/DocumentMoa/getHisDocumentListByRefNo 已删除


获取下一个节点的人
URI:/DocumentMoa/getNextStepUsers 已删除

获取下一个节点
URI:/DocumentMoa/getNextSteps 已删除

一键下载
URI:/DocumentMoa/downloadDocument 无变化

对外发文接口
创建发文
URI:/DocumentMoa/createDocumentOut 无变化

撤销发文
URI:/DocumentMoa/recallDocumentOut 无变化

获取发文详情
URI:/DocumentMoa/getDocumentOutDetail 无变化

获取来文详情
URI:/DocumentMoa/getDocumentOutToDetail 无变化

对外发文列表
URI:/DocumentMoa/getDocumentOutFromList 无变化

来文管理列表
URI:/DocumentMoa/getDocumentOutToList 无变化

退回
URI:/DocumentMoa/backDocumentOut 无变化

签收
URI:/DocumentMoa/signDocumentOut 无变化

对外发文催一催
URI:/DocumentMoa/urgeDocumentOut 无变化

doc转pdf
URI:/DocumentMoa/doc2pdf 无变化

云盘url转存到文件系统
URI:/DocumentMoa/transformUrl 无变化


获取公文数字接口,1:处理中的，2:收文登记 3:集团来文
URI:/DocumentMoa/getDocumentNum 无变化

客户端调用，做可见范围校验
URI:/DocumentMoa/getDocumentFlowListByUser  方便开发暂时保留, 应替换 DocumentMoaSetting/getTemplateList

URI:/DocumentMoa/getDocumentFlowByUser  方便开发暂时保留, 应替换 DocumentMoaSetting/getTemplate

业务获取公文模板
URI:/DocumentMoa/getDocumentFlowByType 已删除

URI:/DocumentMoa/getUserDocumentRole 替换 DocumentMoaSetting/getUserRoleInfo

URI:/DocumentMoa/getUserDocumentRoleInfo 替换 DocumentMoaSetting/getUserRoleInfo

URI:/DocumentMoa/getDocumentBodyFileList 替换 DocumentMoaSetting/getBodyFileList && DocumentMoaSetting/getRedHeadList

获取上一次签名记录
URI:/DocumentMoa/getUserLastSign 无变化

报存签名记录
URI:/DocumentMoa/svUserSign 无变化

拉取常用语
URI:/DocumentMoa/getDocumentUsefulExpression 已删除

获取水印
URI:/DocumentMoa/getDocumentWatermark 无变化

加水印
URI:/DocumentMoa/addWatermark 无变化

获取公文设置信息
URI:/DocumentMoa/getDocumentSetting 替换 DocumentMoaSetting/getOrgSetting

获取文号列表
URI:/DocumentMoa/getRefNoListByUser 无变化

回收箱
URI:/DocumentMoa/getDocumentRecycleListByMgr 无变化
URI:/DocumentMoa/clearDocumentRecycle 无变化
URI:/DocumentMoa/delDocumentRecycle 无变化
URI:/DocumentMoa/getDocumentRecycle 无变化


草稿
URI:/DocumentMoa/saveDocumentDraft 无变化
URI:/DocumentMoa/modDocumentDraft 无变化
URI:/DocumentMoa/getDocumentDraftList 无变化
URI:/DocumentMoa/delDocumentDraft 无变化
URI:/DocumentMoa/getDocumentDraftInfo 无变化



收藏公文
URI:/DocumentMoa/collectDocument 无变化
取消收藏公文
URI:/DocumentMoa/unCollectDocument 无变化

URI:/DocumentMoa/getCollectDocumentList 无变化

差错公文接口
获取差错公文详情
URI:/DocumentMoa/setDocumentErrInfo 无变化
URI:/DocumentMoa/getDocumentErrInfo 无变化
URI:/DocumentMoa/delDocumentErrInfo 无变化
URI:/DocumentMoa/getDocumentErrList 无变化


URI:/DocumentMoa/getUserErrFields 无变化
URI:/DocumentMoa/setUserErrFields 无变化
URI:/DocumentMoa/addUserErrSubField 无变化
URI:/DocumentMoa/exportDocumentErrList 无变化

moa公文需求
添加常用公文
URI:/DocumentMoa/addCommonFlow   替换  DocumentMoaSetting/addCommonTemplate

取消常用公文
URI:/DocumentMoa/cancelCommonFlow 替换  DocumentMoaSetting/cancelCommonTemplate


获取集团公司列表
URI:/DocumentMoa/getGroupOrgList 无变化

获取集团公文列表
URI:/DocumentMoa/getGroupDocumentList 无变化

获取集团详情接口
URI:/DocumentMoa/getGroupDocumentInfo 无变化

签收集团公文
URI:/DocumentMoa/signGroupDocument 无变化

给集团发送公文
URI:/DocumentMoa/sendGroupDocument 无变化

地市公文查询
URI:/DocumentMoa/getDocumentListByOtherOrg 无变化

获取密集清单
URI:/DocumentMoa/getItemClassify 无变化
URI:/DocumentMoa/getItemSecretList 无变化
获取组织可收文用户
URI:/DocumentMoa/getOrgSenders 无变化
```

#### 后台接口

```c++
/*
    接口描述文档说明：
    1.必填字段用一个或多个x表示
    2.一个x表示为布尔型
    3.xxx表示为数值型，超长的数值可以用字符串形式表示
    4."xxxxxx"表示为字符串型
    5.有具体的值，如0,false,"13858882421"等表示该字段有默认值，请求时如果与默认值相等，可以不传该字段
    6.数组型/kv对型数据，如果没有值，可以不传
    7.单独的对象（结构体），即不在数组或作为kv对的值出现时，一般必传
*/

enum ErrCode
{
    SRV_ERR = -11,
    NO_DATA = -12,
    NO_ALLOW = -13,
    INVALID_PARAM = -14,
}

enum DocumentStatus
{
    DOCUMENT_DOING = 1,
    DOCUMENT_DONE = 2,
    DOCUMENT_RECALL = 3,
    DOCUMENT_DEL = 10,
}

enum StepType
{
    STEP_WRITER = 1,
    STEP_AUDITOR = 2,
    STEP_SIGNER = 3,
}

enum OperType
{
    OPER_SIGN = 1,
    OPER_BACK = 2,
    OPER_RECALL = 3,
    OPER_CREATE = 4,
    OPER_SEAL = 5,
    OPER_SUBMIT = 6,
    OPER_TURN = 7,
    OPER_APPROVE = 9,
    OPER_DELFILE = 11,
    OPER_MODFILE = 12,
    OPER_RENAMEFILE = 13,
    OPER_RED = 14,
    OPER_PASS_READ = 15,
    OPER_RECREATE = 16,
    OPER_RESUBMIT = 17,
    OPER_UPLOAD = 18,
    OPER_URGE = 19,
    OPER_ASSIGN = 20,
    OPER_CANCEL_RECALL = 21,
    OPER_BACK_SUBMIT = 22,
}

enum DocumentRoleType
{
    ROLE_LWDJ = 1,    //来文登记
    ROLE_DWFW = 2,    //对外发文
    ROLE_GWCX = 3,    //公文查询
    ROLE_GWGD = 4,    //公文归档
    ROLE_DSGWCX = 5,    //地市公文查询
}

后台公文
添加模板
URI:/DocumentMoaSetting/addTemplateSetting
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    docTemplate:
    {
        name:	"xxxxxxxx",
        type:	xxx,
        childType:	0
    }
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        id:	xxx
    }
}

修改模板
URI:/DocumentMoaSetting/modTemplateSetting
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    docTemplate:
    {
        id:	xxx,
        name:	"",
        type:	0,
        childType:	0,
        sortOrder:	0,
        modelKey:	"",
        fields: //可空
        [
            {
                fieldId:	xxx,
                fieldType:	"xxxxxxxx",
                fieldName:	"xxxxxxxx",
                aliasName:	"",
                customName:	"",
                isFill:	false,    //是否必填
                property:	"",    //字段属性,存储jason格式
                value:	"",
                extraValue:	"",
                isCard:	false,
                cardId:	0,
                children: //可空
                [
                    {
                        fieldId:	0,
                        fieldType:	"",
                        fieldName:	"",
                        aliasName:	"",
                        customName:	"",
                        isFill:	false,    //是否必填
                        property:	"",    //字段属性,存储jason格式
                        value:	"",
                        extraValue:	"",
                        isCard:	false,
                        cardId:	0
                    },
                    ...
                ],
                refNoChildren: //可空
                [
                    {
                        fieldType:	"",
                        fieldKey:	"",
                        fieldName:	""
                    },
                    ...
                ]
            },
            ...
        ],
        redHead: //可空
        [
            xxx,
            ...
        ],
        limit:
        {
            allowDepts: //可空
            [
                {
                    id:	xxx,
                    name:	"xxxxxxxx"
                },
                ...
            ],
            users: //可空
            [
                {
                    uid:	"xxxxxxxx",
                    name:	"xxxxxxxx",
                    deptId:	-1,
                    deptName:	"",
                    orgId:	0,
                    orgName:	""
                },
                ...
            ]
        }
    }
}
RESPONSE DATA:
{
    retcode:	0
}

获取模板
URI:/DocumentMoaSetting/getTemplateSetting
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    id:	xxx
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        docTemplate:
        {
            id:	0,
            name:	"",
            type:	0,
            childType:	0,
            sortOrder:	0,
            modelKey:	"",    //传空
            formModelKey:	"",    //传空
            redHead: //可空
            [
                xxx,
                ...
            ],
            fields: //可空
            [
                {
                    fieldId:	xxx,
                    fieldType:	"xxxxxxxx",
                    fieldName:	"xxxxxxxx",
                    aliasName:	"",
                    customName:	"",
                    isFill:	false,    //是否必填
                    property:	"",    //字段属性,存储jason格式
                    value:	"",
                    extraValue:	"",
                    isCard:	false,
                    cardId:	0,
                    children: //可空
                    [
                        {
                            fieldId:	0,
                            fieldType:	"",
                            fieldName:	"",
                            aliasName:	"",
                            customName:	"",
                            isFill:	false,    //是否必填
                            property:	"",    //字段属性,存储jason格式
                            value:	"",
                            extraValue:	"",
                            isCard:	false,
                            cardId:	0
                        },
                        ...
                    ],
                    refNoChildren: //可空
                    [
                        {
                            fieldType:	"",
                            fieldKey:	"",
                            fieldName:	""
                        },
                        ...
                    ]
                },
                ...
            ],
            limit:
            {
                allowDepts: //可空
                [
                    {
                        id:	xxx,
                        name:	"xxxxxxxx"
                    },
                    ...
                ],
                users: //可空
                [
                    {
                        uid:	"xxxxxxxx",
                        name:	"xxxxxxxx",
                        deptId:	-1,
                        deptName:	"",
                        orgId:	0,
                        orgName:	""
                    },
                    ...
                ]
            }
        }
    }
}

删除模板
URI:/DocumentMoaSetting/delTemplateSetting
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    id:	xxx
}
RESPONSE DATA:
{
    retcode:	0
}

获取模板列表
URI:/DocumentMoaSetting/getTemplateSettingList
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    pageId:	xxx,
    pageCount:	xxx
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        allCount:	xxx,
        docTemplates:
        [
            {
                id:	xxx,
                name:	"xxxxxxxx",
                type:	xxx,
                childType:	0,
                modelKey:	"",
                limit:
                {
                    allowDepts: //可空
                    [
                        {
                            id:	xxx,
                            name:	"xxxxxxxx"
                        },
                        ...
                    ],
                    users: //可空
                    [
                        {
                            uid:	"xxxxxxxx",
                            name:	"xxxxxxxx",
                            deptId:	-1,
                            deptName:	"",
                            orgId:	0,
                            orgName:	""
                        },
                        ...
                    ]
                },
                redHead: //可空
                [
                    xxx,
                    ...
                ],
                fields: //可空
                [
                    {
                        fieldId:	xxx,
                        fieldType:	"xxxxxxxx",
                        fieldName:	"xxxxxxxx",
                        aliasName:	"",
                        customName:	"",
                        isFill:	false,    //是否必填
                        property:	"",    //字段属性,存储jason格式
                        value:	"",
                        extraValue:	"",
                        isCard:	false,
                        cardId:	0,
                        children: //可空
                        [
                            {
                                fieldId:	0,
                                fieldType:	"",
                                fieldName:	"",
                                aliasName:	"",
                                customName:	"",
                                isFill:	false,    //是否必填
                                property:	"",    //字段属性,存储jason格式
                                value:	"",
                                extraValue:	"",
                                isCard:	false,
                                cardId:	0
                            },
                            ...
                        ],
                        refNoChildren: //可空
                        [
                            {
                                fieldType:	"",
                                fieldKey:	"",
                                fieldName:	""
                            },
                            ...
                        ]
                    },
                    ...
                ]
            },
            ...
        ]
    }
}

模板排序
URI:/DocumentMoaSetting/sortTemplateSetting
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    ids:
    [
        xxx,
        ...
    ]
}
RESPONSE DATA:
{
    retcode:	0
}

后台公文-设置可见范围
URI:/DocumentMoaSetting/setTemplateSettingVisible
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    id:	xxx,
    limit:
    {
        allowDepts: //可空
        [
            {
                id:	xxx,
                name:	"xxxxxxxx"
            },
            ...
        ],
        users: //可空
        [
            {
                uid:	"xxxxxxxx",
                name:	"xxxxxxxx",
                deptId:	-1,
                deptName:	"",
                orgId:	0,
                orgName:	""
            },
            ...
        ]
    }
}
RESPONSE DATA:
{
    retcode:	0
}

后台公文-设置红头模板
URI:/DocumentMoaSetting/setTemplateSettingRedHead
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    id:	xxx,
    redHead:
    [
        xxx,
        ...
    ]
}
RESPONSE DATA:
{
    retcode:	0
}

客户端调用
获取模板列表-客户端调用
URI:/DocumentMoaSetting/getTemplateList
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    uid:	"xxxxxxxx"
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        docTemplates:
        [
            {
                id:	xxx,
                name:	"xxxxxxxx",
                type:	xxx,
                childType:	xxx,
                isCommon:	xxx
            },
            ...
        ],
        commonTemplates:
        [
            {
                id:	xxx,
                name:	"xxxxxxxx",
                type:	xxx,
                childType:	xxx,
                isCommon:	xxx
            },
            ...
        ]
    }
}

获取模id-inner
URI:/DocumentMoaSetting/searchTemplate
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    name:	"xxxxxxxx"
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        ids:
        [
            xxx,
            ...
        ]
    }
}

获取模板-客户端调用
URI:/DocumentMoaSetting/getTemplate
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    uid:	"xxxxxxxx",
    id:	xxx
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        docTemplate:
        {
            id:	xxx,
            name:	"xxxxxxxx",
            type:	xxx,
            childType:	xxx,
            fields:
            [
                {
                    fieldId:	xxx,
                    fieldType:	"xxxxxxxx",
                    fieldName:	"xxxxxxxx",
                    aliasName:	"",
                    customName:	"",
                    isFill:	false,    //是否必填
                    property:	"",    //字段属性,存储jason格式
                    value:	"",
                    extraValue:	"",
                    isCard:	false,
                    cardId:	0,
                    children: //可空
                    [
                        {
                            fieldId:	0,
                            fieldType:	"",
                            fieldName:	"",
                            aliasName:	"",
                            customName:	"",
                            isFill:	false,    //是否必填
                            property:	"",    //字段属性,存储jason格式
                            value:	"",
                            extraValue:	"",
                            isCard:	false,
                            cardId:	0
                        },
                        ...
                    ],
                    refNoChildren: //可空
                    [
                        {
                            fieldType:	"",
                            fieldKey:	"",
                            fieldName:	""
                        },
                        ...
                    ]
                },
                ...
            ],
            redHead: //可空
            [
                xxx,
                ...
            ]
        }
    }
}

设置-正文模板配置
添加正文模板
URI:/DocumentMoaSetting/addBodyFile
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    file:
    {
        url:	"xxxxxxxx",
        name:	"xxxxxxxx",
        childType:	0,
        fileSize:	0
    }
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        id:	xxx
    }
}

删除正文模板
URI:/DocumentMoaSetting/delBodyFile
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    id:	xxx
}
RESPONSE DATA:
{
    retcode:	0
}

获取正文模板
URI:/DocumentMoaSetting/getBodyFileList
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        files:
        [
            {
                id:	xxx,
                file:
                {
                    url:	"xxxxxxxx",
                    name:	"xxxxxxxx",
                    childType:	0,
                    fileSize:	0
                }
            },
            ...
        ]
    }
}

设置-红头模板管理
添加红头模板
URI:/DocumentMoaSetting/addRedHead
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    file:
    {
        url:	"xxxxxxxx",
        name:	"xxxxxxxx",
        childType:	0,
        fileSize:	0
    }
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        id:	xxx
    }
}

/删除红头模板
URI:/DocumentMoaSetting/delRedHead
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    id:	xxx
}
RESPONSE DATA:
{
    retcode:	0
}

获取红头模板
URI:/DocumentMoaSetting/getRedHeadList
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    type:	xxx
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        files:
        [
            {
                id:	xxx,
                file:
                {
                    url:	"xxxxxxxx",
                    name:	"xxxxxxxx",
                    childType:	0,
                    fileSize:	0
                }
            },
            ...
        ]
    }
}

获取红头模板
URI:/DocumentMoaSetting/getRedHeads
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    ids:
    [
        xxx,
        ...
    ]
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        files:
        [
            {
                id:	xxx,
                file:
                {
                    url:	"xxxxxxxx",
                    name:	"xxxxxxxx",
                    childType:	0,
                    fileSize:	0
                }
            },
            ...
        ]
    }
}

设置-权限管理
添加权限
URI:/DocumentMoaSetting/addRoleInfo
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    info:
    {
        user:
        {
            uid:	"xxxxxxxx",
            name:	"xxxxxxxx",
            deptId:	-1,
            deptName:	"",
            orgId:	0,
            orgName:	""
        },
        roles:
        [
            xxx,
            ...
        ],
        limitDepts:
        {
            allowDepts: //可空
            [
                {
                    id:	xxx,
                    name:	"xxxxxxxx"
                },
                ...
            ],
            users: //可空
            [
                {
                    uid:	"xxxxxxxx",
                    name:	"xxxxxxxx",
                    deptId:	-1,
                    deptName:	"",
                    orgId:	0,
                    orgName:	""
                },
                ...
            ]
        },
        id:	0
    }
}
RESPONSE DATA:
{
    retcode:	0
}

修改权限
URI:/DocumentMoaSetting/modRoleInfo
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    info:
    {
        user:
        {
            uid:	"xxxxxxxx",
            name:	"xxxxxxxx",
            deptId:	-1,
            deptName:	"",
            orgId:	0,
            orgName:	""
        },
        roles:
        [
            xxx,
            ...
        ],
        limitDepts:
        {
            allowDepts: //可空
            [
                {
                    id:	xxx,
                    name:	"xxxxxxxx"
                },
                ...
            ],
            users: //可空
            [
                {
                    uid:	"xxxxxxxx",
                    name:	"xxxxxxxx",
                    deptId:	-1,
                    deptName:	"",
                    orgId:	0,
                    orgName:	""
                },
                ...
            ]
        },
        id:	0
    }
}
RESPONSE DATA:
{
    retcode:	0
}

获取权限
URI:/DocumentMoaSetting/getRoleList
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        infos:
        [
            {
                user:
                {
                    uid:	"xxxxxxxx",
                    name:	"xxxxxxxx",
                    deptId:	-1,
                    deptName:	"",
                    orgId:	0,
                    orgName:	""
                },
                roles:
                [
                    xxx,
                    ...
                ],
                limitDepts:
                {
                    allowDepts: //可空
                    [
                        {
                            id:	xxx,
                            name:	"xxxxxxxx"
                        },
                        ...
                    ],
                    users: //可空
                    [
                        {
                            uid:	"xxxxxxxx",
                            name:	"xxxxxxxx",
                            deptId:	-1,
                            deptName:	"",
                            orgId:	0,
                            orgName:	""
                        },
                        ...
                    ]
                },
                id:	0
            },
            ...
        ]
    }
}

删除权限
URI:/DocumentMoaSetting/delRoleInfo
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    uid:	"xxxxxxxx"
}
RESPONSE DATA:
{
    retcode:	0
}

获取权限
URI:/DocumentMoaSetting/getUserRoleInfo
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    uid:	"xxxxxxxx"
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        info:
        {
            user:
            {
                uid:	"xxxxxxxx",
                name:	"xxxxxxxx",
                deptId:	-1,
                deptName:	"",
                orgId:	0,
                orgName:	""
            },
            roles:
            [
                xxx,
                ...
            ],
            limitDepts:
            {
                allowDepts: //可空
                [
                    {
                        id:	xxx,
                        name:	"xxxxxxxx"
                    },
                    ...
                ],
                users: //可空
                [
                    {
                        uid:	"xxxxxxxx",
                        name:	"xxxxxxxx",
                        deptId:	-1,
                        deptName:	"",
                        orgId:	0,
                        orgName:	""
                    },
                    ...
                ]
            },
            id:	0
        }
    }
}

获取权限
URI:/DocumentMoaSetting/getRoleUsers
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    role:	xxx
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        users:
        [
            {
                uid:	"xxxxxxxx",
                name:	"xxxxxxxx",
                deptId:	-1,
                deptName:	"",
                orgId:	0,
                orgName:	""
            },
            ...
        ]
    }
}

设置-公共基础配置
URI:/DocumentMoaSetting/getOrgSetting
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        setting:
        {
            remind:
            {
                isOpen:	false,
                remindSec:	0    //单位秒
            },
            watermark:
            {
                openWatermark:	false,
                type:	1,    //1:姓名和后四位  2:自定义
                customize:	""    //自定义内容
            },
            fileLimit:	0    //附件规则限制，0：不限制
        }
    }
}

URI:/DocumentMoaSetting/svOrgSetting
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    setting:
    {
        remind:
        {
            isOpen:	false,
            remindSec:	0    //单位秒
        },
        watermark:
        {
            openWatermark:	false,
            type:	1,    //1:姓名和后四位  2:自定义
            customize:	""    //自定义内容
        },
        fileLimit:	0    //附件规则限制，0：不限制
    }
}
RESPONSE DATA:
{
    retcode:	0
}

设置-文号管理
获取文号配置list
URI:/DocumentMoaSetting/getRefNoSettingList
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        refNos:
        [
            {
                name:	"xxxxxxxx",
                limit:
                {
                    allowDepts: //可空
                    [
                        {
                            id:	xxx,
                            name:	"xxxxxxxx"
                        },
                        ...
                    ],
                    users: //可空
                    [
                        {
                            uid:	"xxxxxxxx",
                            name:	"xxxxxxxx",
                            deptId:	-1,
                            deptName:	"",
                            orgId:	0,
                            orgName:	""
                        },
                        ...
                    ]
                },
                allowTemplates: //可空
                [
                    {
                        id:	xxx,
                        name:	"xxxxxxxx",
                        type:	xxx,
                        childType:	xxx,
                        isCommon:	xxx
                    },
                    ...
                ],
                id:	0,
                usedRecords: //可空
                {
                    xxx:
                    {
                        usedNos:
                        {
                            xxx:
                            xxx,
                            ...
                        },
                        curNo:	1
                    },
                    ...
                }
            },
            ...
        ]
    }
}

添加文号配置
URI:/DocumentMoaSetting/addRefNoSetting
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    refNo:
    {
        name:	"xxxxxxxx",
        limit:
        {
            allowDepts: //可空
            [
                {
                    id:	xxx,
                    name:	"xxxxxxxx"
                },
                ...
            ],
            users: //可空
            [
                {
                    uid:	"xxxxxxxx",
                    name:	"xxxxxxxx",
                    deptId:	-1,
                    deptName:	"",
                    orgId:	0,
                    orgName:	""
                },
                ...
            ]
        },
        allowTemplates: //可空
        [
            {
                id:	xxx,
                name:	"xxxxxxxx",
                type:	xxx,
                childType:	xxx,
                isCommon:	xxx
            },
            ...
        ],
        id:	0,
        usedRecords: //可空
        {
            xxx:
            {
                usedNos:
                {
                    xxx:
                    xxx,
                    ...
                },
                curNo:	1
            },
            ...
        }
    }
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        id:	xxx
    }
}

修改文号配置
URI:/DocumentMoaSetting/modRefNoSetting
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    refNo:
    {
        name:	"xxxxxxxx",
        limit:
        {
            allowDepts: //可空
            [
                {
                    id:	xxx,
                    name:	"xxxxxxxx"
                },
                ...
            ],
            users: //可空
            [
                {
                    uid:	"xxxxxxxx",
                    name:	"xxxxxxxx",
                    deptId:	-1,
                    deptName:	"",
                    orgId:	0,
                    orgName:	""
                },
                ...
            ]
        },
        allowTemplates: //可空
        [
            {
                id:	xxx,
                name:	"xxxxxxxx",
                type:	xxx,
                childType:	xxx,
                isCommon:	xxx
            },
            ...
        ],
        id:	0,
        usedRecords: //可空
        {
            xxx:
            {
                usedNos:
                {
                    xxx:
                    xxx,
                    ...
                },
                curNo:	1
            },
            ...
        }
    }
}
RESPONSE DATA:
{
    retcode:	0
}

删除文号配置
URI:/DocumentMoaSetting/delRefNoSetting
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    id:	xxx
}
RESPONSE DATA:
{
    retcode:	0
}

URI:/DocumentMoaSetting/getRefNoListByUser
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    deptId:	xxx,
    templateId:	xxx
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        refNos:
        [
            {
                id:	xxx,
                name:	"xxxxxxxx"
            },
            ...
        ]
    }
}

URI:/DocumentMoaSetting/calRefNo
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    id:	xxx,
    year:	xxx
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        refNo:	xxx
    }
}

检查文号是否可用
URI:/DocumentMoaSetting/checkRefNo
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    id:	xxx,
    year:	xxx,
    refNo:	xxx
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        isRep:	x
    }
}

使用文号
URI:/DocumentMoaSetting/useRefNo
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    id:	xxx,
    year:	xxx,
    refNo:	xxx,
    documentId:	xxx
}
RESPONSE DATA:
{
    retcode:	0
}

取消文号
URI:/DocumentMoaSetting/cancelRefNo
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    id:	xxx,
    year:	xxx,
    refNo:	xxx
}
RESPONSE DATA:
{
    retcode:	0
}

设置常用模板
添加常用公文
URI:/DocumentMoaSetting/addCommonTemplate
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    uid:	"xxxxxxxx",
    id:	xxx
}
RESPONSE DATA:
{
    retcode:	0
}

取消常用公文
URI:/DocumentMoaSetting/cancelCommonTemplate
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    uid:	"xxxxxxxx",
    id:	xxx
}
RESPONSE DATA:
{
    retcode:	0
}


水印
URI:/DocumentMoa/saveWatermarkRecord
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    info:
    {
        id:	0, // 创建不穿
        orgId:	0,
        uid:	"",
        name:	"",
        deptId:	0,
        deptName:	"",
        createTime:	0,
        title:	"",
        comment:	"",
        originFile:	"",
        finalFile:	"",
        watermark:
        {
            openWatermark:	false,
            type:	1,    //1:姓名和后四位  2:自定义
            customize:	""    //自定义内容
        }
    }
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        id:	xxx
    }
}

URI:/DocumentMoa/modWatermarkRecord
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    id:	xxx,
    info:
    {
        id:	0,
        orgId:	0,
        uid:	"",
        name:	"",
        deptId:	0,
        deptName:	"",
        createTime:	0,
        title:	"",
        comment:	"",
        originFile:	"",
        finalFile:	"",
        watermark:
        {
            openWatermark:	false,
            type:	1,    //1:姓名和后四位  2:自定义
            customize:	""    //自定义内容
        }
    }
}
RESPONSE DATA:
{
    retcode:	0
}

URI:/DocumentMoa/getWatermarkRecordList
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    screen:
    {
        title:	"",
        beginTime:	0,
        endTime:	0
    },
    pageId:	xxx,
    pageCount:	xxx
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        allCount:	xxx,
        infos:
        [
            {
                id:	0,
                title:	"",
                uid:	"",
                createTime:	0
            },
            ...
        ]
    }
}

URI:/DocumentMoa/getWatermarkRecord
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    id:	xxx
}
RESPONSE DATA:
{
    retcode:	0,
    data:
    {
        info:
        {
            id:	0,
            orgId:	0,
            uid:	"",
            name:	"",
            deptId:	0,
            deptName:	"",
            createTime:	0,
            title:	"",
            comment:	"",
            originFile:	"",
            finalFile:	"",
            watermark:
            {
                openWatermark:	false,
                type:	1,    //1:姓名和后四位  2:自定义
                customize:	""    //自定义内容
            }
        }
    }
}

URI:/DocumentMoa/delWatermarkRecord
METHOD:POST
REQUEST PARAMETERS:
{
    orgId:	xxx,
    id:	xxx
}
RESPONSE DATA:
{
    retcode:	0
}
```
