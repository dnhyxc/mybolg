/* eslint-disable react/react-in-jsx-scope */
import moment from 'moment'
import { Tooltip } from 'antd'
import { v1 as uuidv1 } from 'uuid'

export const formatDate = (date, format = 'YYYY/MM/DD HH:mm:ss') => {
  if (!date) return date

  return moment(date).format(format)
}

/**
 *  获取 对应字段
 *
 * @export
 * @param {object[]} [fields=[]]
 * @param {string} [fieldName='']
 * @returns
 */
export function getField(fields = [], fieldName = '') {
  let currentField = {}
  let currentFieldIndex = -1
  if (fields.length === 0 || !fieldName) {
    return [currentField, currentFieldIndex]
  }

  currentFieldIndex = fields.findIndex(item => {
    return item.fieldName === fieldName
  })

  if (currentFieldIndex !== -1) {
    currentField = fields[currentFieldIndex]
  }

  return [currentField, currentFieldIndex]
}

export function getFieldChild(fields = [], fieldName = '') {
  let currentField = {}
  fields.forEach(x => {
    if (x.fieldName === fieldName) {
      currentField = x
    }
    if (x.children && x.children.length > 0) {
      x.children.forEach(y => {
        if (y.fieldName === fieldName) {
          currentField = y
        }
      })
    }
  })
  return currentField
}

export const safeJsonParse = (str, defaultValue) => {
  let result = defaultValue
  if (!str) return result
  try {
    result = JSON.parse(str)
  } catch (error) {
    console.error(error)
  }
  return result
}

// 根据文号数组返回文号字符串
export const getSerialNumStr = (serialArr, defaultValue = '-') =>
  serialArr[0] || serialArr[1] || serialArr[2]
    ? `${serialArr[0] || ''}〔${serialArr[1] || ''}〕${serialArr[2] || ''}号`
    : defaultValue

export const getSerialNumStrFromStr = (serialStr, defaultValue = '-') => {
  if (!serialStr) {
    return defaultValue
  }

  if (!/^\[[\S\s]*]$/g.test(serialStr)) {
    return serialStr || defaultValue
  }

  let refNo = ['', '', '']
  try {
    refNo = JSON.parse(serialStr)
  } catch (e) {
    console.error(`JSON.parse refNo ERROR ${serialStr}`)
    return defaultValue
  }
  return getSerialNumStr(refNo, defaultValue)
}

export function getReduxReducerObject(actionName, reducerCallback) {
  return {
    [`${actionName}_PENDING`]: reducerCallback.pending,
    [`${actionName}_FULFILLED`]: reducerCallback.fulfilled,
    [`${actionName}_REJECTED`]: reducerCallback.rejected,
  }
}

export const getYearList = () => {
  const yearList = []
  const nowYear = new Date().getFullYear()
  for (let i = nowYear - 5; i < nowYear + 50; i++) {
    yearList.push({
      text: i,
      value: i,
    })
  }
  return yearList
}
/**
 * 阻止默认事件
 *
 * @export
 * @param {Event} e
 */
export function stopPropagation(e) {
  e.stopPropagation()
  e.nativeEvent.stopImmediatePropagation()
}

/**
 * 补充数字前置
 *
 * @export
 * @param {number} num
 * @param {number} [length=2]
 * @returns {string}
 */
export function completeNumByLen(num, length = 2) {
  return `${num}`.length < length
    ? (new Array(length + 1).join('0') + num).slice(-length)
    : `${num}`
}
/**
 * 下载文件
 *
 * @export
 * @param {string} [url=''] 文件URL
 * @param {string} [fileName=''] 文件名
 * @param {boolean} [isDirectly=false] 是否直接下载
 */
export function downloadFile(url = '', fileName = '', isDirectly = false) {
  const el = document.createElement('iframe')
  el.style = 'position:fixed;height:0;width:0;'

  if (/\/fcscloud/.test(url) || isDirectly) {
    el.src = url
  } else {
    el.src = `${url}&filename=${encodeURIComponent(fileName)}`
  }
  document.body.appendChild(el)

  setTimeout(() => {
    document.body.removeChild(el)
  }, 2000)
}

// /**
//  * 截取文本
//  * @param {*} text
//  * @param {*} clipLength
//  */
export function tooltipText(text = '', clipLength = 10) {
  if (typeof text !== 'string') {
    return text
  }
  if (text.length <= clipLength) {
    return text
    // eslint-disable-next-line no-else-return
  } else {
    return (
      <Tooltip title={text}>
        <span>{`${text.substring(0, clipLength)}...`}</span>
      </Tooltip>
    )
  }
}

export const getSearchParam = name => {
  const search = `?${window.location.href.split('?')[1]}`
  const pattern = new RegExp(`[?&]${name}=([^&]+)`, 'g')
  const matcher = pattern.exec(search)
  let items = null
  if (matcher != null) {
    try {
      items = decodeURIComponent(decodeURIComponent(matcher[1]))
    } catch (e) {
      try {
        items = decodeURIComponent(matcher[1])
      } catch (e) {
        items = matcher[1]
      }
    }
  }
  return items
}

// 兼容ie11
export const isArray = arr => {
  if (Object.prototype.toString.call(arr) === '[object Array]') {
    return true
  }
  return false
}

export const indexOf = (arr, current) => {
  if (arr.indexOf(current) !== -1) {
    return true
  }
  return false
}

export const hasValue = obj => {
  if (Object.values(obj).length) {
    return true
  }
  return false
}

// 集团来文表单字段回填
export const groupFieldsManage = (fields, detail, onSetBodyFileList) => {
  fields.forEach(field => {
    if (field.fieldName === 'rowCard') {
      groupFieldsManage(field.children, detail)
    }

    const writing = {
      UP: 1,
      DOWN: 2,
      PARALLEL: 3,
      RETURN: '',
    }

    switch (field.fieldName) {
      case 'title':
        field.value = detail.docInfo.docTitle
        break
      case 'writing':
        field.value = writing[detail.docInfo.docStyle]
        break
      case 'secretClass':
        if (detail.docInfo.docSecret === '无（密级）') {
          field.value = ''
        }
        break
      case 'secrecyTerm':
        break
      case 'useSeal':
        break
      // return <div>{fieldName}</div>
      case 'urgencyLevel':
        break
      case 'officialType':
        break
      case 'fileDepartment': // 拟稿部门
        break
      case 'remarks':
        break
      case 'impression':
        break
      case 'themeWord': // 主题词
        field.value = detail.docInfo.docSubject || '主题词写死测试'
        break
      case 'proofreader':
        break
      case 'printer':
        break
      case 'issUer':
        break
      case 'dispatchCompany': // 发文单位
        field.value = detail.docInfo.issuingUnit
        break
      case 'receiptCompany':
        break
      case 'refNo': // 问号
        field.value = ['信技通', 2021, 185]
        // field.value = detail.docInfo.docNumber
        break
      case 'outsideRefNo':
        break
      case 'receiptRefNo':
        break

      case 'bodyFile':
        if (detail.files.length) {
          const bodyFiles = detail.files.filter(i => i.attachType === 'content')
          const pdfFile = bodyFiles.filter(i => /\.pdf$/.test(i.attachName))
          const docFile = bodyFiles.filter(i => !/\.pdf$/.test(i.attachName))
          const fillFile = { key: uuidv1(), mimeType: '', size: 0 }
          if (pdfFile.length) {
            fillFile.downloadUrl = pdfFile[0].filePath
            fillFile.noMarksPdfUrl = pdfFile[0].filePath
            fillFile.url = pdfFile.filePath
          }
          if (docFile.length) {
            fillFile.type = 'docx'
            fillFile.name = docFile[0].attachName
            fillFile.originalUrl = docFile[0].filePath
            fillFile.url = docFile[0].filePath
          } else if (pdfFile.length) {
            fillFile.type = 'pdf'
            fillFile.name = pdfFile[0].attachName
            fillFile.originalUrl = pdfFile[0].filePath
            fillFile.url = pdfFile[0].filePath
          }
          const bodyFile = JSON.stringify(fillFile.type ? [fillFile] : [])
          field.value = bodyFile
          onSetBodyFileList(bodyFile)
        }
        break
      case 'mobile':
        break
      case 'creatPerson':
        break
      case 'countersignDepartment':
        break
      case 'creatTime':
        break
      case 'dispatchDate':
        break
      case 'receiptDate':
        break
      case 'enclosure': // 附件
        if (detail.files.length) {
          const attachments = detail.files.filter(i => i.attachType === 'attach')
          // const pdfFile = attachments.filter(i => /\.pdf$/.test(i.attachName))
          const enclosure = {}
          enclosure.file = {}
          enclosure.fileList = attachments.map(i => ({
            name: i.attachName,
            size: '',
            status: 'done',
            type: '',
            uid: i.attachUid,
            response: {
              code: 200,
              fileUrl: i.filePath,
            },
          }))
          field.value = JSON.stringify(enclosure)
        }
        break
      case 'reference':
        break
      case 'mainSend':
        break
      case 'copySend':
        break
      default:
        return ''
    }
  })
}
// 正文主送抄送展示使用
export const handleChangeStr = (list = []) => {
  let str = ''
  if (!list.length) return str
  str = list.reduce((pre, cur, i) => {
    const isEnd = !list[i + 1]
    let isDiffType
    let isFirst
    if (cur.type === -1 || cur.type === 3) {
      pre += isEnd ? `${cur.name}` :`${cur.name}，`
    }
    if (cur.type === 1) {
      isDiffType = !list[i + 1] || list[i + 1].type !== 1
      pre += isDiffType ? isEnd ? `${cur.name.split('公司')[0]}市公司`: `${cur.name.split('公司')[0]}市公司，` : `${cur.name.split('公司')[0]}、`
    }
    if (cur.type === 2) {
      isFirst = !list[i - 1] || list[i - 1].type !== 2
      isDiffType = !list[i + 1] || list[i + 1].type !== 3
      pre += isFirst ? `区公司${cur.name}、` : isDiffType ? `${cur.name}、` :  `${cur.name}，`
    }
    return pre
  }, '')
  return str
}
