/*
 * @Description: 处理表单字段公共方法
 * @Author: dnh
 * @Date: 2022-03-18 23:17:17
 * @LastEditTime: 2022-03-26 22:03:39
 * @LastEditors: dnh
 * @FilePath: \src\utils\manageFieldValue.js
 */

import { handleChangeStr, formatDate } from 'ROOT/utils'


// 表单值回填
export const createFormValue = (formDataSource, keys, values) => {
  formDataSource.forEach(field => {
    const newField = { ...field }
    if (field.fieldName === 'rowCard') {
      createFormValue(field.children, keys, values)
    }

    if (keys.indexOf(newField.fieldName) !== -1) {
      field.value = values[field.fieldName]
    }
  })

  return formDataSource
}

// 处理表单values
export const getFieldsValue = (fields, values) => {
  const keys = Object.keys(values) || []
  const res = createFormValue(fields, keys, values)
  return res
}

// 将field中的儿子取出来
export const getWpsFieldValue = data => {
  const tempData = []
  data.forEach(field => {
    if (field.fieldName === 'rowCard') {
      tempData.push(...field.children)
    }
  })
  const res = data.concat(tempData)
  return res
}

// parse field value
export const parseFieldValue = field => {
  let parseField
  if (field.value && typeof field.value === 'string') {
    parseField = JSON.parse(field.value) || {}
  } else {
    parseField = field.value
  }
  return parseField
}

// 创建表单值回填
export const getFileObjValue = (fields, deptId, fullDepartment, eventTimeList = []) => {

  console.log(eventTimeList, 'eventTimeList')

  const copyValues = {
    title: '', // 标题
    copySend: '', // 抄送
    mainSend: '', // 主送
    fileDepartment: '', // 拟稿部门
    outsideRefNo: '', // 发文问好
    refNo: '', // 文号
    urgencyLevel: '', // 紧急程度
    secretClass: '', // 密级
    enclosure: '', // 附件
    issUer: '', // 签发人
    creatPerson: '', // 起草人
    signingUnit: '', // 落款单位
    signatureUnit: '', // 署名单位
    issueDate: '', // 签发日期
    printDate: '',
  }

  if (eventTimeList && eventTimeList.length) {
    const issueDate = eventTimeList.filter(i => i.eventType === 'qf')
    const printDate = eventTimeList.filter(i => i.eventType === 'yf')
    console.log(issueDate, 'issueDate')
    console.log(printDate, 'printDate')

    if (issueDate && issueDate.length) {
      const lastIssueDate = issueDate[issueDate.length - 1].gmtEnd

      if (lastIssueDate) {
        copyValues.issueDate = formatDate(lastIssueDate, 'YYYY/MM/DD')
      }
    }

    if (printDate && printDate.length) {
      const lastPrintDate = printDate[printDate.length - 1].gmtEnd

      if (lastPrintDate) {
        copyValues.printDate = formatDate(lastPrintDate, 'YYYY/MM/DD')
      }
    }

  }


  fields.forEach(field => {
    if (field.fieldName === 'title') {
      copyValues.title = field.value
    }
    if (field.fieldName === 'issUer') {
      copyValues.issUer = field.value
    }

    if (field.fieldName === 'creatPerson') {
      copyValues.creatPerson = field.value
    }

    if (field.fieldName === 'copySend') {
      const res = parseFieldValue(field) && parseFieldValue(field).length ? handleChangeStr(parseFieldValue(field)) : ''
      copyValues.copySend = res
      // copyValues.copySend = parseFieldValue(field).length
      //   ? parseFieldValue(field)
      //     .map(i => i.name)
      //     .join('、')
      //   : ''
    }

    if (field.fieldName === 'mainSend') {
      const res = parseFieldValue(field) && parseFieldValue(field).length ? handleChangeStr(parseFieldValue(field)) : ''
      copyValues.mainSend = res
      // copyValues.mainSend = parseFieldValue(field).length
      //   ? parseFieldValue(field)
      //     .map(i => i.name)
      //     .join('、')
      //   : ''
    }

    if (field.fieldName === 'fileDepartment') {
      copyValues.fileDepartment = JSON.stringify({
        id: deptId,
        name: field.value,
      })
    }

    if (field.fieldName === 'outsideRefNo') {
      copyValues.outsideRefNo = `${parseFieldValue(field).join('')}号`
    }

    if (field.fieldName === 'refNo') {
      copyValues.refNo = `${parseFieldValue(field).join('')}号`
    }

    if (field.fieldName === 'urgencyLevel') {
      const { options } = JSON.parse(field.property) || {}
      const res = options.filter(i => i.value === field.value)
      if (res.length) {
        copyValues.urgencyLevel = res[0].text
      } else {
        copyValues.urgencyLevel = ''
      }
    }

    if (field.fieldName === 'secretClass') {
      const secretClassValue = {
        1: '核心商密',
        2: '普通商密',
        3: '内部信息',
      }
      copyValues.secretClass = Number(field.value) !== 4 ? secretClassValue[field.value] : ''
    }

    if (field.fieldName === 'enclosure') {
      const { fileList } = parseFieldValue(field)

      console.log(fileList, 'enclosure>>>>>>>>>>>>>>>>>')

      copyValues.enclosure =
        fileList && fileList.length
          ? fileList.map(i => ({
            downloadUrl: i.url || i.response.fileUrl,
            key: i.uid,
            mimeType: i.type,
            name: i.name,
            size: i.size,
            // type: 'png',
            url: i.url || i.response.fileUrl,
          }))
          : []
    }

    // 落款单位
    if (field.fieldName === 'signingUnit') {
      const property = JSON.parse(field.property) || {}
      if (property && property.options && property.options.length) {
        // const fullName1 = fullDepartment && fullDepartment.replace(/\//, '')
        // const fullName2 = fullDepartment && fullDepartment.split('/')

        // if (property.options[0] && property.options[0].text && fullName1) {
        //   if (property.options[0].text.indexOf('&') !== -1) {
        //     console.log(property.options[0].text, 'property.options[0].text')
        //     const res = property.options[0].text.replace(/&{3}/g, fullName1)
        //     copyValues.signingUnit = res
        //   }

        //   if (property.options[0].text.indexOf('$') !== -1) {
        //     console.log(property.options[0].text, 'property.options[0].text')
        //     const res = property.options[0].text.replace(/\${3}/g, fullName2[0])
        //     copyValues.signingUnit = res
        //   }
        // }
        const property = JSON.parse(field.property) || {}
        if (property && property.options && property.options.length) {
          // const fullName1 = fullDepartment && fullDepartment.replace(/\//, '')
          const fullName = fullDepartment && fullDepartment.split('/')

          if (property.options[0] && property.options[0].text && fullName) {
            const res = property.options[0].text.replace(/\${3}/g, fullName[0]).replace(/&{3}/g, fullName[1])
            copyValues.signingUnit = res
          }
        }
      }
    }

    // 署名单位
    if (field.fieldName === 'signatureUnit') {
      const property = JSON.parse(field.property) || {}
      if (property && property.options && property.options.length) {
        // const fullName1 = fullDepartment && fullDepartment.replace(/\//, '')
        const fullName = fullDepartment && fullDepartment.split('/')

        if (property.options[0] && property.options[0].text && fullName) {
          const res = property.options[0].text.replace(/\${3}/g, fullName[0]).replace(/&{3}/g, fullName[1])
          copyValues.signingUnit = res
        }
      }
    }
  })

  console.log(copyValues, 'copyValues')

  return copyValues
}