import EE from 'eventemitter3'

/**
 * 生成全局统一的事件
 */
const Events = new EE()

export default Events
