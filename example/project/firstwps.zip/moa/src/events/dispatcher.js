import Events from './index'
import { EVENTS } from 'ROOT/constant'
import messageFilter, { messageHandler } from 'ROOT/utils/IMUtil/messageFilter'

export const EventsDispatcher = (data) => {
  let msg

  data.forEach((o) => {
    if (!o.data) return

    msg = messageFilter(o.data)

    msg && messageHandler(msg)
  })
}

