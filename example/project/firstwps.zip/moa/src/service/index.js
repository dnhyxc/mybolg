import { request, globalStore } from '@xm/util'
import { message } from 'antd'
import api from './api'

const errCodeMsg = {
  101: '密级字段不能为空',
  102: '行文类型不能为空',
  103: '紧急程度不能为空',
  104: '发文文号不能为空',
  201: '该文号已被使用',
  301: '暂无该权限',
  302: '接收单位未设置收文登记员，无法发送',
  310: '已发送，请勿重复发送',
  401: '文件内容与文件后缀不符',
}
const ERR_FUNC = err => {
  message.error(errCodeMsg[err.retcode] || '系统错误，请重新刷新页面')
  throw new Error(err)
}
const paramAddOrgId = (param = {}) => {
  const { orgId } = param
  param.orgId = orgId || globalStore.get('orgId')
  return param
}
export default {
  getDocumentList(param) {
    return request
      .post(api.GET_DOCUMENT_LIST, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  getDocumentListByMgr(param) {
    return request
      .post(api.GET_DOCUMENT_LIST_BY_MGR, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  getUserDocumentRoleInfo(param) {
    return request
      .post(api.GET_USER_DOCUMENT_ROLE_INFO, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  getDocumentFlowListByUser(param) {
    return request
      .post(api.GET_DOCUMENT_FLOW_LIST_BY_USER, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  urgeDocument(param) {
    return request
      .post(api.URGE_DOCUMENT, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  getDocumentListByOtherOrg(param) {
    return request
      .post(api.GET_DOCUMENT_LIST_BY_OTHER_ORG, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  getListOrg() {
    return request
      .get(api.GET_LIST_ORG)
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  getDocumentErrList(param) {
    return request
      .post(api.GET_DOCUMENT_ERR_LIST, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  getUserErrFields(param) {
    return request
      .post(api.GET_USER_ERR_FIEIDS, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  getDocumentErrInfo(param) {
    return request
      .post(api.GET_DOCUMENT_ERR_INFO, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  setDocumentErrInfo(param) {
    return request
      .post(api.SET_DOCUMENT_ERR_INFO, paramAddOrgId(param))
      .then(json => json)
      .catch(ERR_FUNC)
  },
  exportDocumentErrList(param) {
    return request
      .post(api.EXPORT_DOCUMENT_ERR_LIST, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  setUserErrFields(param) {
    return request
      .post(api.SET_USER_ERR_FIELDS, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  getDocumentOutFromList(param) {
    return request
      .post(api.GET_DOCUMENT_OUT_FROM_LIST, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  urgeDocumentOut(param) {
    return request
      .post(api.URGE_DOCUMENT_OUT, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  recallDocumentOut(param) {
    return request
      .post(api.RECALL_DOCUMENT_OUT, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  getDocumentOutToList(param) {
    return request
      .post(api.GET_DOCUMENT_OUT_TO_LIST, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  getDocumentFlowFormList(param) {
    // 获取表单返回的数据
    return request
      .post(api.GET_DOCUMENT_FLOW_BY_USER, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  getItemSecretList(param) {
    // 获取密集清单列表
    return request
      .post(api.GET_ITEM_SECRET_LIST, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },

  getItemClassify(param) {
    // 获取密集清单列表
    return request
      .post(api.GET_ITEM_CLASSIFY, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  getOneKeySenderUsers(param) {
    // 获取一键分发（主送，抄送人员）
    return request
      .post(api.GET_ONE_KEY_SENDER_USERS, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  getActionList(param) {
    // 获取节点
    return request
      .post(api.GET_ACTION_LIST, param)
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  complate(param) {
    // 一键分发确认
    return request
      .post(api.COMPLETE, param)
      .then(json => json)
      .catch(ERR_FUNC)
  },

  uploadDoc(param) {
    // 获取段落
    return request
      .post(api.UPLOAD_DOM, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  genRefNo(param) {
    // 自动编号获取
    return request
      .post(api.GET_REF_NO, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  getRefNoListByUser(param) {
    // 发文机关代字列表
    return request
      .post(api.GET_REF_NO_LIST_BY_USER, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  getHisDocumentListByRefNo(param) {
    // 发文机关代字历史
    return request
      .post(api.GET_HIS_DOCUMENT_LIST_BY_REF_NO, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },

  getTemplate(param) {
    // 获取表单数据
    return request
      .post(api.GET_TEMPLATE, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },

  previewById(param) {
    // 获取拼接完成的html
    return request
      .get(`${api.PREVIEW_BY_ID}?${param}`)
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  getTemplateList(param) {
    // 查询所有公文模版
    return request
      .post(api.GET_TEMPLATE_LIST, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  addCommonFlow(param) {
    // 添加收藏
    return request
      .post(api.ADD_COMMON_FLOW, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  cancelCommonFlow(param) {
    // 取消收藏
    return request
      .post(api.CANCEL_COMMON_FLOW, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  downloadDocument(param) {
    // 一键下载
    return request
      .post(api.DOWNLOAD_DOCUMENT, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  getGroupDocumentList(param) {
    return request
      .post(api.GET_GROUP_DOCUMENT_LIST, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  getCollectDocumentList(param) {
    return request
      .post(api.GET_COLLECT_DOCUMENT_LIST, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  collectDocument(param) {
    return request
      .post(api.COLLECT_DOCUMENT, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  unCollectDocument(param) {
    return request
      .post(api.UN_COLLECT_DOCUMENT, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  getGroupOrgList(param) {
    return request
      .post(api.GET_GROUP_ORG_LIST, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  sendGroupDocument(param) {
    return request
      .post(api.SEND_GROUP_DOCUMENT, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  createDocument(param) {
    return request
      .post(api.CREATE_DOCUMENT, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  modDocumentFields(param) {
    return request
      .post(api.MOD_DOCUMENT_FIELDS, paramAddOrgId(param))
      .then(json => json)
      .catch(ERR_FUNC)
  },
  getOrgDeptPath(param) {
    return request
      .get(api.GET_ORG_DEPT_PATH, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  getUserInfoAndDept(param) {
    return request
      .post(api.GET_USER_INFO_AND_DEPT, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  // 获取公文详情
  getDocumentDetail(param) {
    return request
      .post(api.GET_DOCUMENT_DETAIL, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  // 获取发文详情
  getDocumentOutDetail(param) {
    return request
      .post(api.GET_DOCUMENT_OUT_DETAIL, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  // 获取来文详情
  getDocumentOutToDetail(param) {
    return request
      .post(api.GET_DOCUMENT_OUT_TO_DETAIL, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  // 获取集团来文详情
  getGroupDocumentInfo(param) {
    return request
      .post(api.GET_GROUP_DOCUMENT_INFO, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  // 获取流程定义key
  getAppDetailList(param) {
    return request
      .post(api.GET_APP_DETAIL_LIST, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  getOrgFilters(param) {
    return request
      .post(api.GET_ORG_FILTERS, param)
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  createDocumentOut(param) {
    return request
      .post(api.CREATE_DOCUMENT_OUT, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  backDocumentOut(param) {
    return request
      .post(api.BACK_DOCUMENT_OUT, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  signDocumentOut(param) {
    return request
      .post(api.SIGN_DOCUMENT_OUT, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  signGroupDocument(param) {
    return request
      .post(api.SIGN_GROUP_DOCUMENT, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  getDocumentOutToListByDocumentId(param) {
    return request
      .post(api.GET_DOCUMENT_OUT_TO_LIST_BY_DOCUMENT_ID, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  getGroupSendListByDocumentId(param) {
    return request
      .post(api.GET_GROUP_SEND_LIST_BY_DOCUMENT_ID, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  getOrgGroup(param) {
    return request
      .get(api.GET_ORG_GROUP, param)
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  saveDocumentDraft(param) {
    return request
      .post(api.SAVE_DOCUMENT_DRAFT, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  // 创建水印
  saveWatermarkRecord(param) {
    return request
      .post(api.SAVE_WATERMARK_RECORD, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  // 修改水印
  modWatermarkRecord(param) {
    return request
      .post(api.MOD_WATERMARK_RECORD, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  // 删除水印
  delWatermarkRecord(param) {
    return request
      .post(api.DEL_WATERMARK_RECORD, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  // 获取水印详情
  getWatermarkRecord(param) {
    return request
      .post(api.GET_WATERMARK_RECORD, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  getOrgSetting(param) {
    return request
      .post(api.GET_ORG_SETTING, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  getWatermarkRecordList(param) {
    return request
      .post(api.GET_WATER_MARK_RECORD_LIST, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  sortSendUserList(param) {
    return request
      .post(api.SORT_SEND_USER_LIST, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  processFinish(param) {
    return request
      .post(api.PROCESS_FINISH, param)
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  batchGetOrgDepts(param) {
    return request
      .post(api.GET_ORG_DEPTS, param)
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  getDocumentDraftInfo(param) {
    return request
      .post(api.GET_DOCUMENT_DRAFT_INFO, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  getDeptRoot(param) {
    return request
      .get(api.GET_DEPT_ROOT, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
}
