/*
 * @Description: 正文相关接口
 * @Author: dnh
 * @Date: 2022-02-28 11:01:14
 * @LastEditTime: 2022-03-09 16:43:38
 * @LastEditors: dnh
 * @FilePath: \src\service\api\official.js
 */
export default {
  // doc to pdf
  DOC_2_PDF: '/access/DocumentMoa/doc2pdf',
  // 是否开启水印，水印信息
  GET_DOCUMENT_WATERMARK: '/access/DocumentMoa/getDocumentWatermark',
  // 添加水印
  ADD_WATERMARK: '/access/DocumentMoa/addWatermark',
  // 获取红头模板
  GET_RED_HEAD_LIST: '/access/DocumentMoaSetting/getRedHeadList',
  // 获取正文模板
  GET_BODYFILE_LIST: '/access/DocumentMoaSetting/getBodyFileList',
  // 获取拆分的段落
  WORD_DOCUMENT_SPLIT: '/baas-moa-document-split/web/wordDocumentSplit/upload',
}