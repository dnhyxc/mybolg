/*
 * @Description: 正文相关接口
 * @Author: dnh
 * @Date: 2022-02-28 10:51:09
 * @LastEditTime: 2022-03-09 16:15:55
 * @LastEditors: dnh
 * @FilePath: \src\service\official.js
 */
import { request, globalStore } from '@xm/util'
import { message } from 'antd'
import api from './api/official'

const ERR_FUNC = err => {
  message.error((err.data && err.data.errMsg) || '系统错误，请重新刷新页面')
  throw new Error(err)
}
const paramAddOrgId = (param = {}) => {
  param.orgId = globalStore.get('orgId')
  return param
}
export default {
  getDocumentList(param) {
    return request
      .post(api.GET_DOCUMENT_LIST, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  getDocumentWatermark(param) {
    return request
      .post(api.GET_DOCUMENT_WATERMARK, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  // 添加水印
  addWatermark(param, attachment) {
    if (attachment) {
      return request
      .post(api.ADD_WATERMARK, paramAddOrgId(param))
      .then(json => json.data)
    }
    return request
      .post(api.ADD_WATERMARK, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  // doctopdf
  doc2pdf(param) {
    return request
      .post(api.DOC_2_PDF, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  // 获取红头模板
  getRedHeadList(param) {
    return request
      .post(api.GET_RED_HEAD_LIST, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
  // 获取正文模板
  getBodyFileList() {
    return request
      .post(api.GET_BODYFILE_LIST, paramAddOrgId())
      .then(json => json.data)
      .catch(ERR_FUNC)
  },

  // 上传word获取段落
  wordDocumentSplit(param) {
    // 获取段落
    return request
      .post(api.WORD_DOCUMENT_SPLIT, paramAddOrgId(param))
      .then(json => json.data)
      .catch(ERR_FUNC)
  },
}
