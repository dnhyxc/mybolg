import React from 'react'
import { Route, Switch, Redirect } from 'react-router-dom'
import Loadable from 'react-loadable'
import _ from 'lodash'
import { Spin } from 'antd'
import { RootPath } from '@xm/util'
import { routersArr } from 'ROOT/router/config'
import App from 'ROOT/layout/index'

const { Context, Consumer } = RootPath

const R = ({ children, path, component }) => {
  return (
    <Route
      // exact={!(children && children.length)}
      path={`${path}`}
      component={Loadable({
        loader: () => {
          return import(`ROOT/views/${component}`).catch(console.log)
        },
        loading: () => (
          <Spin>
            <div style={{ height: 600 }} />
          </Spin>
        ),
      })}
    />
  )
}

const Router = ({ getPath }) => {
  return (
    <Switch>
      <App>
        {routersArr.map(route =>
          route.children && route.children.length ? (
            route.children.map(child => (
              <R key={child.path} {...child} path={child.path} />
            ))
          ) : (
            <R key={route.path} {...route} path={route.path} />
          ),
        )}

        <Route
          exact
          path=''
          component={() => <Redirect to={routersArr[0].path} />}
        />
      </App>
    </Switch>
  )
}

export default _.flowRight([Consumer(Context)])(Router)
