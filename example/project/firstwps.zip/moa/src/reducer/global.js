import { createAction, handleActions } from 'redux-actions'

import api from 'ROOT/service'

const GET_MY_SELF = 'GET_MY_SELF'
const SET_BASE_INFO = 'SET_BASE_INFO'
const SET_COLLAPSED = 'SET_COLLAPSED'
const ON_FORM_VALUE_CHANGE = 'ON_FORM_VALUE_CHANGE'
const SET_FIELDS = 'SET_FIELDS'

export const setBaseInfo = createAction(SET_BASE_INFO)
export const setCollapsed = createAction(SET_COLLAPSED)
export const onFormValueChange = createAction(ON_FORM_VALUE_CHANGE)
export const setDetailFields = createAction(SET_FIELDS)
export const getMySelf = createAction(GET_MY_SELF, (param) => api.getMySelf(param))

export default handleActions(
	{
		[ON_FORM_VALUE_CHANGE]: (state, action) => {
			const { payload } = action

			return {
				...state,
				isFormValueChange: payload,
			}
		},
		[SET_FIELDS]: (state, action) => {
			const { payload } = action

			return {
				...state,
				detailFields: payload,
			}
		},
		[SET_COLLAPSED]: (state, action) => {
			const { payload } = action

			return {
				...state,
				collapsed: payload.collapsed,
			}
		},
		[SET_BASE_INFO]: (state, action) => {
			const { payload } = action

			return {
				...state,
				baseInfo: payload,
			}
		},
		[`${GET_MY_SELF}_PENDING`]: (state) => {
			const { getMySelf } = state

			return {
				...state,
				getMySelf: {
					...getMySelf,
					loading: true,
				},
			}
		},
		[`${GET_MY_SELF}_FULFILLED`]: (state, action) => {
			const { getMySelf } = state
			const { payload: data = {} } = action

			return {
				...state,
				getMySelf: {
					...getMySelf,
					data,
					loading: false,
				},
			}
		},
		[`${GET_MY_SELF}_REJECTED`]: (state) => {
			const { getMySelf } = state

			return {
				...state,
				getMySelf: {
					...getMySelf,
					loading: false,
				},
			}
		},
	},
	{
		baseInfo: {}, // 基本信息，例如：用户信息，企业信息等
		getMySelf: {
			loading: true,
			data: {},
		},
		collapsed: false,
		isFormValueChange: false,
		detailFields: [],
	},
)
