import { combineReducers } from 'redux'
import globalInfo from './global'

export default combineReducers({
  globalInfo,
})
