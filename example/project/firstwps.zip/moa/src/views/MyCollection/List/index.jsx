import React, { useState, useEffect } from 'react'
import { Table, Badge, message, Modal } from 'antd'
import PageHeader from 'ROOT/components/PageHeader'
import PageContent from 'ROOT/components/PageContent'
import TableTitle from 'ROOT/components/TableTitle'
import CurTransactor from 'ROOT/components/CurTransactor'
import service from 'ROOT/service'
import { getFieldChild, getSerialNumStrFromStr, formatDate } from 'ROOT/utils'
import { OFFICIAL_TYPE_TEXT, FIELD_TYPE, DOC_STATUS_COLOR, DOC_STATUS_TXT } from 'ROOT/constant'
import HeaderSearch from '../Components/HeaderSearch'
import styles from './index.scss'

const List = props => {
  const [list, setList] = useState([])
  const [loading, setLoading] = useState(false)
  const [params, setParams] = useState({
    pageId: 1,
    pageNum: 10,
    screen: {
      title: '',
      beginTime: 0,
      endTime: 0,
      type: 0,
      childType: 0,
      status: [],
    },
  })
  const columns = [
    {
      title: '公文标题',
      fixed: 'left',
      width: 300,
      key: 'title',
      render: x => {
        const titleField = getFieldChild(x.fields, FIELD_TYPE.TITLE) // 标题
        const urgencyLevelField = getFieldChild(x.fields, FIELD_TYPE.URGENCY_LEVEL) // 紧急程度
        return <TableTitle title={titleField} level={urgencyLevelField} />
      },
    },
    {
      title: '发文文号',
      key: 'refNo',
      render: x => {
        const refNoField = getFieldChild(x.fields, FIELD_TYPE.REF_NO) // 文号
        return getSerialNumStrFromStr(refNoField.value)
      },
    },
    {
      title: '公文类型',
      width: 150,
      key: 'type',
      render: x => OFFICIAL_TYPE_TEXT[x.type],
    },
    {
      title: '创建人',
      width: 150,
      key: 'createName',
      dataIndex: 'createName',
    },
    {
      title: '创建时间',
      width: 200,
      key: 'createTime',
      dataIndex: 'createTime',
      render: x => formatDate(x, 'YYYY/MM/DD HH:mm'),
    },
    {
      title: '状态',
      width: 200,
      key: 'status',
      dataIndex: 'status',
      render: text => {
        return <Badge color={DOC_STATUS_COLOR[text]} text={DOC_STATUS_TXT[text]} />
      },
    },
    {
      title: '当前办理人',
      width: 200,
      key: 'waitOperator',
      dataIndex: 'waitOperator',
      render: x => <CurTransactor users={x || []} />,
    },
    {
      title: '操作',
      width: 150,
      render: (text, record) => (
        <a style={{ color: '#4F84D2' }} onClick={e => handleCancelCollection(e, record.id)}>
          取消收藏
        </a>
      ),
    },
  ]
  const handleCancelCollection = (e, id) => {
    e.stopPropagation()
    Modal.confirm({
      title: '确认取消收藏？',
      okText: '确认',
      cancelText: '取消',
      onOk: () =>
        service
          .unCollectDocument({
            id,
          })
          .then(() => {
            message.success('已取消收藏')
            getData()
          }),
    })
  }
  const [allCount, setallCount] = useState(0)

  const handleSearchChange = data => {
    setParams({ ...params, pageId: 1, screen: data })
  }

  const getData = () => {
    setLoading(true)
    service
      .getCollectDocumentList({
        ...params,
      })
      .then(res => {
        const { allCount, basics } = res
        setLoading(false)
        setList(basics)
        setallCount(allCount)
      })
      .finally(() => {
        setLoading(false)
      })
  }

  const pageChange = page => {
    setParams({ ...params, pageId: page })
  }
  const onShowSizeChange = (current, pageSize) => {
    setParams({ ...params, pageNum: pageSize })
  }
  const clickJump = id => {
    const { history, match } = props
    history.push(`${match.path}/detail/${id}`)
  }
  useEffect(() => {
    getData()
  }, [params])
  return (
    <div className={styles['my-warp']}>
      <PageHeader title="我的收藏" />
      <PageContent>
        <HeaderSearch onSearchChange={handleSearchChange} />
        <Table
          loading={loading}
          columns={columns}
          dataSource={list}
          rowKey={x => x.id}
          fixed
          scroll={{
            x: 1500,
            scrollToFirstRowOnChange: true,
          }}
          pagination={
            !allCount
              ? false
              : {
                  total: allCount,
                  current: params.pageId,
                  pageSize: params.pageNum,
                  onChange: pageChange,
                  showSizeChanger: true,
                  showQuickJumper: true,
                  onShowSizeChange,
                  showTotal: total =>
                    `共${total}条记录  第${params.pageId}/${Math.ceil(total / params.pageNum)}页`,
                }
          }
          onRow={record => {
            return {
              onClick: () => {
                clickJump(record.id)
              },
            }
          }}
        />
      </PageContent>
    </div>
  )
}

export default List
