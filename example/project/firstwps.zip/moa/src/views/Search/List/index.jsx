import React, { useState, useEffect } from 'react'
import { connect } from 'react-redux'
import { Table, Badge } from 'antd'
import PageHeader from 'ROOT/components/PageHeader'
import PageContent from 'ROOT/components/PageContent'
import TableTitle from 'ROOT/components/TableTitle'
import CurTransactor from 'ROOT/components/CurTransactor'
import service from 'ROOT/service'
import { getFieldChild, getSerialNumStrFromStr, formatDate } from 'ROOT/utils'
import { OFFICIAL_TYPE_TEXT, FIELD_TYPE, DOC_STATUS_TXT, DOC_STATUS_COLOR } from 'ROOT/constant'
import HeaderSearch from '../Components/HeaderSearch'

import styles from './index.scss'

const List = props => {
  const [list, setList] = useState([])
  const [loading, setLoading] = useState(false)
  const [allCount, setallCount] = useState(0)
  const [params, setParams] = useState({
    pageId: 1,
    pageCount: 10,
    screen: {
      beginTime: 0,
      createUids: [],
      endTime: 0,
      status: [],
      templateIds: '',
      title: '',
    },
  })

  const handleSearchChange = data => {
    setParams({ ...params, pageId: 1, screen: data })
  }

  const getData = () => {
    setLoading(true)
    service
      .getDocumentListByMgr({
        ...params,
      })
      .then(res => {
        const { allCount, infos } = res
        setLoading(false)
        setList(infos)
        setallCount(allCount)
      })
      .finally(() => {
        setLoading(false)
      })
  }

  const pageChange = page => {
    setParams({ ...params, pageId: page })
  }

  const onShowSizeChange = (current, pageSize) => {
    setParams({ ...params, pageCount: pageSize })
  }
  const clickJump = id => {
    const { history, match } = props
    history.push(`${match.path}/detail/${id}`)
  }

  const columns = [
    {
      title: '公文标题',
      fixed: 'left',
      width: 300,
      key: 'title',
      render: x => {
        const titleField = getFieldChild(x.fields, FIELD_TYPE.TITLE) // 标题
        const urgencyLevelField = getFieldChild(x.fields, FIELD_TYPE.URGENCY_LEVEL) // 紧急程度
        return <TableTitle title={titleField} level={urgencyLevelField} />
      },
    },
    {
      title: '发文文号',
      key: 'refNo',
      render: x => {
        const refNoField = getFieldChild(x.fields, FIELD_TYPE.REF_NO) // 文号
        return getSerialNumStrFromStr(refNoField.value)
      },
    },
    {
      title: '公文类型',
      key: 'type',
      width: 150,
      render: x => OFFICIAL_TYPE_TEXT[x.type],
    },
    {
      title: '发起人',
      width: 150,
      key: 'createName',
      dataIndex: 'createName',
    },
    {
      title: '创建时间',
      width: 200,
      key: 'createTime',
      dataIndex: 'createTime',
      render: x => formatDate(x, 'YYYY/MM/DD HH:mm'),
    },
    {
      title: '当前办理人',
      width: 200,
      key: 'waitOperator',
      dataIndex: 'waitOperator',
      render: x => <CurTransactor users={x || []} />,
    },
    {
      title: '状态',
      width: 200,
      key: 'status',
      dataIndex: 'status',
      render: text => {
        return <Badge color={DOC_STATUS_COLOR[text]} text={DOC_STATUS_TXT[text]} />
      },
    },
  ]

  useEffect(() => {
    getData()
  }, [params])
  return (
    <div className={styles['search-warp']}>
      <PageHeader title="公文查询" />
      <PageContent>
        <HeaderSearch onSearchChange={handleSearchChange} />
        <Table
          loading={loading}
          columns={columns}
          dataSource={list}
          rowKey={x => x.id}
          fixed
          scroll={{
            x: 1500,
            scrollToFirstRowOnChange: true,
          }}
          pagination={
            !allCount
              ? false
              : {
                  total: allCount,
                  current: params.pageId,
                  pageSize: params.pageCount,
                  onChange: pageChange,
                  showSizeChanger: true,
                  showQuickJumper: true,
                  onShowSizeChange,
                  showTotal: total =>
                    `共${total}条记录  第${params.pageId}/${Math.ceil(total / params.pageCount)}页`,
                }
          }
          onRow={record => {
            return {
              onClick: () => {
                clickJump(record.id)
              },
            }
          }}
        />
      </PageContent>
    </div>
  )
}

export default connect(state => ({
  orgId: state.globalInfo.baseInfo.orgId,
}))(List)
