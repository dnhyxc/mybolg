/*
 * @Description: 
 * @Author: dnh
 * @Date: 2022-02-23 18:58:27
 * @LastEditTime: 2022-03-09 18:22:53
 * @LastEditors: dnh
 * @FilePath: \src\views\Search\ListDetail\index.jsx
 */
import React from 'react'
import OfficialContent from 'ROOT/components/OfficialContent'

const ListDetail = props => {
  return <OfficialContent {...props} />
}

export default ListDetail
