import React, { useState, useReducer, useEffect } from 'react'
import { formatDate } from 'ROOT/utils'
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import { Form, Button } from 'antd'
import { OFFICIAL_STATE_SEARCH , OFFICIAL_TYPE_SEARCH_CASCADER } from 'ROOT/constant'
import SearchTerm from 'ROOT/components/SearchTerm'

import styles from './index.scss'

const initialState = {
  docTitle: '',
  docType: [],
  docTimer: [],
  docState: JSON.stringify([]),
  beginTime: 0,
  endTime: 0,
}
const createAction = (type, payload) => {
  return {
    type,
    payload,
  }
}
const reducer = function reducer(state, action) {
  switch (action.type) {
    case 'docTitle':
      return { ...state, docTitle: action.payload }
    case 'docType':
      return { ...state, docType: action.payload }
    case 'docTimer':
      return { ...state, docTimer: action.payload }
    case 'docCreater':
      return { ...state, docCreater: action.payload }
    case 'docState':
      return { ...state, docState: action.payload }
    case 'reset':
      return { ...initialState }
    default:
      return state
  }
}
const HeaderSearch = props => {
  const { onSearchChange } = props
  const [formData, dispatch] = useReducer(reducer, initialState)

  const handleFormItemValueChange = (type, value) => {
    dispatch(createAction(type, value))
  }

  const handleReset = () => {
    dispatch(createAction('reset', ''))
    onSearchChange({
      title: '',
      beginTime: 0,
      endTime: 0,
      type: 0,
      childType: 0,
      status: [],
    })
  }
  const handleSearch = () => {
    onSearchChange({
      title: formData.docTitle,
      beginTime: formData.docTimer[0]
        ? new Date(`${formatDate(formData.docTimer[0], 'YYYY-MM-DD')} 00:00:00`).getTime()
        : 0,
      endTime: formData.docTimer[1]
        ? new Date(`${formatDate(formData.docTimer[1], 'YYYY-MM-DD')} 23:59:59`).getTime()
        : 0,
      type: formData.docType[0] || 0,
      childType: formData.docType[1] || 0,
      status: JSON.parse(formData.docState),
    })
  }
  return (
    <div className={styles.search}>
      <Form layout="inline">
        <SearchTerm
          type="input"
          label="公文标题:"
          placeholder="请输入标题"
          value={formData.docTitle}
          onChange={value => {
            handleFormItemValueChange('docTitle', value)
          }}
        />
        <SearchTerm
          type="cascader"
          label="公文类型:"
          options={OFFICIAL_TYPE_SEARCH_CASCADER}
          placeholder="请选择公文类型"
          value={formData.docType}
          onChange={value => {
            handleFormItemValueChange('docType', value)
          }}
        />
        <SearchTerm
          type="select"
          label="公文状态:"
          options={[{ label: '全部', value: JSON.stringify([]) }, ...OFFICIAL_STATE_SEARCH]}
          placeholder="请选择公文状态"
          value={formData.docState}
          onChange={value => {
            handleFormItemValueChange('docState', value)
          }}
        />
        <SearchTerm
          type="datePicker"
          label="创建时间:"
          placeholder={['开始时间', '结束时间']}
          value={formData.docTimer}
          onChange={value => {
            handleFormItemValueChange('docTimer', value)
          }}
        />
        {/* <SearchTerm
          type="selectUser"
          label="选择人员"
          range={1}
          title="请选择人员"
          placeholder="请选择人员"
          value={formData.docCreater}
          onChange={value => {
            handleFormItemValueChange('docCreater', value)
          }}
        /> */}

        <SearchTerm>
          <Button className={styles.reset} onClick={handleReset}>
            重置
          </Button>
          <Button type="primary" onClick={handleSearch}>
            查询
          </Button>
        </SearchTerm>
      </Form>
    </div>
  )
}

export default connect(
  state => ({
    orgId: state.globalInfo.baseInfo.orgId,
  }),
  dispatch => ({
    actions: bindActionCreators({}, dispatch),
  }),
)(HeaderSearch)
