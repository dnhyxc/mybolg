import React, { useState, useEffect } from 'react'
import { connect } from 'react-redux'
import { Table, Badge, Menu, Dropdown } from 'antd'
import HeaderSearch from 'ROOT/views/CitySearch/Components/HeaderSearch'
import PageHeader from 'ROOT/components/PageHeader'
import PageContent from 'ROOT/components/PageContent'
import TableTitle from 'ROOT/components/TableTitle'
import CurTransactor from 'ROOT/components/CurTransactor'
import service from 'ROOT/service'
import { getFieldChild, getSerialNumStrFromStr, formatDate } from 'ROOT/utils'
import { OFFICIAL_TYPE_TEXT, FIELD_TYPE, DOC_STATUS_COLOR, DOC_STATUS_TXT } from 'ROOT/constant'
import ClassNames from 'classnames'
import styles from './index.scss'

const List = props => {
  const [list, setList] = useState([])
  const [listOrg, setListOrg] = useState([])
  const [loading, setLoading] = useState(false)
  const [allCount, setallCount] = useState(0)
  const [orgCityId, setOrgCityId] = useState(localStorage.getItem('orgCityId') || '')
  const [isShowTips, setIsShowTips] = useState(!localStorage.getItem('orgCityId'))
  const [params, setParams] = useState({
    pageId: 1,
    pageCount: 10,
    screen: {
      beginTime: 0,
      endTime: 0,
      otherOrgId: orgCityId,
      status: [],
      title: '',
      type: 0,
    },
  })

  const handleSearchChange = data => {
    setParams({ ...params, pageId: 1, screen: { ...data, otherOrgId: orgCityId } })
  }

  const getData = () => {
    setLoading(true)
    service
      .getDocumentListByOtherOrg({
        ...params,
      })
      .then(res => {
        const { allCount, infos } = res
        setLoading(false)
        setList(infos)
        setallCount(allCount)
      })
      .finally(() => {
        setLoading(false)
      })
  }

  const getCityListByUser = () => {
    service.getListOrg().then(res => setListOrg(res))
  }
  const pageChange = page => {
    setParams({ ...params, pageId: page })
  }

  const onShowSizeChange = (current, pageSize) => {
    setParams({ ...params, pageCount: pageSize })
  }
  const clickJump = id => {
    const { history, match } = props
    history.push(`${match.path}/detail/${id}`)
  }

  const columns = [
    {
      title: '公文标题',
      fixed: 'left',
      width: 300,
      key: 'title',
      render: x => {
        const titleField = getFieldChild(x.fields, FIELD_TYPE.TITLE) // 标题
        const urgencyLevelField = getFieldChild(x.fields, FIELD_TYPE.URGENCY_LEVEL) // 紧急程度
        return <TableTitle title={titleField} level={urgencyLevelField} />
      },
    },
    {
      title: '发文文号',
      key: 'refNo',
      render: x => {
        const refNoField = getFieldChild(x.fields, FIELD_TYPE.REF_NO) // 文号
        return getSerialNumStrFromStr(refNoField.value)
      },
    },
    {
      title: '公文类型',
      key: 'type',
      width: 150,
      render: x => OFFICIAL_TYPE_TEXT[x.type],
    },
    {
      title: '发起人',
      width: 150,
      key: 'createName',
      dataIndex: 'createName',
    },
    {
      title: '创建时间',
      width: 200,
      key: 'createTime',
      dataIndex: 'createTime',
      render: x => formatDate(x, 'YYYY/MM/DD HH:mm'),
    },
    {
      title: '当前办理人',
      width: 200,
      key: 'waitOperator',
      dataIndex: 'waitOperator',
      render: x => <CurTransactor users={x || []} />,
    },
    {
      title: '状态',
      width: 200,
      key: 'status',
      dataIndex: 'status',
      render: text => {
        return <Badge color={DOC_STATUS_COLOR[text]} text={DOC_STATUS_TXT[text]} />
      },
    },
  ]

  const handleFristClose = e => {
    e.stopPropagation()
    setIsShowTips(false)
  }

  const selectPropChange = key => {
    setParams({
      pageId: 1,
      pageCount: 10,
      screen: {
        ...params.screen,
        otherOrgId: key,
      },
    })
    setOrgCityId(key)
    setIsShowTips(false)
    localStorage.setItem('orgCityId', key)
  }
  const renderCitySelect = () => {
    let currentCity = null
    const menu = (
      <Menu selectedKeys={[orgCityId]} onClick={({ key }) => selectPropChange(key)}>
        {listOrg.map(item => {
          if (item.id || item.orgId === Number(orgCityId)) {
            currentCity = item
          }
          return <Menu.Item key={item.id || item.orgId}>{item.name}</Menu.Item>
        })}
      </Menu>
    )

    return (
      <Dropdown
        className={styles['drop-down']}
        overlay={menu}
        overlayClassName={styles['city-selector-overlay']}
        trigger={['click']}
      >
        <div className={ClassNames(styles['city-selector'], 'c_link')}>
          <span className={styles['city-selector-text']}>
            {currentCity ? currentCity.name : '请选择地市公司'}
          </span>
          <i className={ClassNames('iconfont icon-arrow', styles['city-selector-icon'])} />
          {isShowTips && (
            <div className={ClassNames('c_brand', styles['first-tags'])}>
              点击可切换地市公司
              <span
                className={ClassNames('iconfont icon-shanchu1', styles.close)}
                onClick={handleFristClose}
              />
              <div className={ClassNames('c_brand', styles.sjx)} />
            </div>
          )}
        </div>
      </Dropdown>
    )
  }

  useEffect(() => {
    getData()
  }, [params])

  useEffect(() => {
    getCityListByUser()
  }, [])
  return (
    <div className={styles['my-warp']}>
      <PageHeader title="地市公文查询">{renderCitySelect()}</PageHeader>
      <PageContent>
        <HeaderSearch onSearchChange={handleSearchChange} />
        <Table
          loading={loading}
          columns={columns}
          dataSource={list}
          rowKey={x => x.id}
          fixed
          scroll={{
            x: 1500,
            scrollToFirstRowOnChange: true,
          }}
          pagination={
            !allCount
              ? false
              : {
                  total: allCount,
                  current: params.pageId,
                  pageSize: params.pageCount,
                  onChange: pageChange,
                  showSizeChanger: true,
                  showQuickJumper: true,
                  onShowSizeChange,
                  showTotal: total =>
                    `共${total}条记录  第${params.pageId}/${Math.ceil(total / params.pageCount)}页`,
                }
          }
          onRow={record => {
            return {
              onClick: () => {
                clickJump(record.id)
              },
            }
          }}
        />
      </PageContent>
    </div>
  )
}

export default connect(state => ({
  orgId: state.globalInfo.baseInfo.orgId,
}))(List)
