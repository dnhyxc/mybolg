import React, { useState, useEffect, useRef } from 'react'
import { globalStore } from '@xm/util'
import XmiconReact from '@xm/icons-guangxicmcc-moa/dist/react'
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import { onFormValueChange } from 'ROOT/reducer/global'
import { Form, message, Row, Col, Spin, Modal } from 'antd'
import service from 'ROOT/service'
import {
  getField,
  downloadFile,
  getSearchParam,
  isArray,
  indexOf,
  hasValue,
  groupFieldsManage,
} from 'ROOT/utils'
import { FIELD_TYPE } from 'ROOT/constant'
import ClassifiedModal from 'ROOT/components/ClassifiedModal'
import PageHeader from 'ROOT/components/PageHeader'
import PageContent from 'ROOT/components/PageContent'
import RenderPdf from 'ROOT/components/RenderPdf'
import { Buttons } from 'ROOT/components/OfficialContent/Buttons'
import FileRender from 'ROOT/components/FileRender'
// import { mockFields } from 'ROOT/mock'

import styles from './index.scss'

const formItemLayout = {
  labelCol: {
    xs: { span: 20 },
    sm: { span: 2 },
  },
  wrapperCol: {
    xs: { span: 24 },
    sm: { span: 22 },
  },
}

const List = ({ history, isFormValueChange, ...props }) => {
  const [formDataSource, setFormDataSource] = useState([])
  const [docTemplate, setDocTemplate] = useState({})
  const [redheadTemplates, setRedheadTemplates] = useState([])
  const [errFields, setErrFields] = useState([])
  const [refNoDataSource, setRefNoDataSource] = useState([])
  const [isShowClassified, setIsShowClassified] = useState(false)
  const [bodyFileUploadUrl, setBodyFileUploadUrl] = useState('')
  const [bodyFileList, setBodyFileList] = useState([])
  const [access, setAccess] = useState({}) // 字段权限（只读｜可写｜隐藏）
  const [deptData, setdeptData] = useState({})
  const [previewIndex, setPreviewIndex] = useState(0)
  const [outOrOutToDetail, setOutOrOutToDetail] = useState({})
  const [groupDocumentDetail, setGroupDocumentDetail] = useState({})
  const [backToTop, setBackToTop] = useState(false)
  const [documentId, setDocumentId] = useState('')
  const [loading, setLoading] = useState(false)
  const [formType, setFormType] = useState(1)
  const [fileLimit, setFileLimit] = useState(0)
  const [secretClassStatus, setSecretClassStatus] = useState(4)
  const [fullDepartment, setFullDepartment] = useState('')
  const [draftProkey, setDraftProkey] = useState('')
  const [draftTemplateId, setDraftTemplateId] = useState('')
  const [draftType, setDraftType] = useState(1)
  const [contentWidth, setContentWidth] = useState(0)

  const {
    setFields,
    setFieldsValue,
    getFieldValue,
    validateFieldsAndScroll,
    getFieldsValue: formGetFieldsValue,
  } = props.form

  const diffRef = useRef(null)
  const btnsRef = useRef(null)
  const contentRef = useRef(null)
  const renderPdfRef = useRef(null)

  const orgId = globalStore.get('orgId')
  const uid = globalStore.get('uid')
  const name = globalStore.get('name')
  const mobile = globalStore.get('mobile')
  const deptList = globalStore.get('deptList')
  const id = getSearchParam('id') || null // 需要获取模板字段的id
  const fromOrgId = getSearchParam('fromOrgId') || null
  const proKey = getSearchParam('proKey') || null
  const checkId = getSearchParam('checkId') || null // 需要获取详情的模板id
  const isRegister = getSearchParam('isRegister') || null // 需要获取详情的模板id
  const isGroup = getSearchParam('isGroup') || null // 需要获取详情的模板id
  const fromDraft = getSearchParam('fromDraft') || null // 需要获取详情的模板id

  useEffect(() => {
    if (deptData.value && formDataSource.length) {
      if (props.collapsed) {
        btnsRef.current.children[0].children[0].classList.add('full')
      } else {
        btnsRef.current && btnsRef.current.children[0].children[0].classList.remove('full')
      }
    }
  }, [deptData.value, formDataSource.length, props.collapsed])

  useEffect(() => {
    if (!fromDraft) {
      getTemplate()
    }
    getDept()
    getOrgSettingMethods()
  }, [fromDraft])

  useEffect(() => {
    if (fromOrgId) {
      getDocumentOutToDetail()
    }
  }, [fromOrgId, checkId])

  useEffect(() => {
    if (isGroup) {
      getGroupDocumentInfo()
    }
  }, [isGroup])

  // 监听content滚动事件
  useEffect(() => {
    if (!renderPdfRef.current || !bodyFileUploadUrl || !contentRef.current) return

    setContentWidth(contentRef.current.offsetWidth)

    contentRef.current.addEventListener('scroll', () => {
      const { scrollTop, clientHeight, scrollHeight } = contentRef.current
      const { offsetTop } = renderPdfRef.current
      if (scrollTop + clientHeight === scrollHeight) {
        setBackToTop(true)
      }
      if (scrollTop > offsetTop) {
        setBackToTop(true)
      }
      if (scrollTop < offsetTop && scrollTop + clientHeight !== scrollHeight) {
        setBackToTop(false)
      }
    })
    return () => {
      contentRef.current.removeEventListener('scroll', () => {}, false)
    }
  }, [bodyFileUploadUrl])

  useEffect(() => {
    if (fromDraft) {
      getDocumentDraftInfo()
    }
  }, [fromDraft])

  const getTemplateList = templateID => {
    service.getTemplateList({ uid }).then(res => {
      const { docTemplates } = res
      const docTemplate = docTemplates.filter(x => x.id === templateID)
      if (docTemplate.length === 0) {
        return message.error('请配置收文模板')
      }
      setDraftType(docTemplate[0].type)
      jumpCreate(docTemplate[0])
    })
  }

  const jumpCreate = item => {
    service.getAppDetailList({ uid }).then(res => {
      let data = null
      // 递归查找流程定义key
      const getModelKey = details => {
        details.forEach(detail => {
          if (detail.children.length > 0) {
            getModelKey(detail.children)
          }
          if (detail.extra) {
            const extra = JSON.parse(detail.extra)
            if (extra.procFormKey === item.formModelKey) {
              data = detail
            }
          }
        })
      }

      if (res.details.length > 0) {
        const { details } = res
        getModelKey(details)
        if (data) {
          setDraftProkey(data.detailKey)
        }
      }
    })
  }

  // 获取草稿详情
  const getDocumentDraftInfo = () => {
    service
      .getDocumentDraftInfo({
        id,
      })
      .then(res => {
        getTemplateList(res.info.templateID)
        setFormDataSource(res.info.fields)
        setDraftTemplateId(res.info.templateID)
        const bodyFile = res.info.fields.filter(i => i.fieldName === 'bodyFile')
        const bodyFileField = getFileListFromProps(bodyFile[0].value)
        setBodyFileList(bodyFileField)
        setBodyFileUploadUrl(bodyFileField && bodyFileField[0] && bodyFileField[0].originalUrl)
      })
  }

  // 滚动到正文
  const onScrollToBodyFileOrTop = () => {
    if (!contentRef.current || !renderPdfRef.current) return
    const { scrollTop, clientHeight, scrollHeight } = contentRef.current
    const { offsetTop } = renderPdfRef.current
    if (scrollTop + clientHeight === scrollHeight) {
      contentRef.current.scrollTop = 0
    }
    if (scrollTop > offsetTop) {
      contentRef.current.scrollTop = 0
    }
    if (scrollTop < offsetTop && scrollTop + clientHeight !== scrollHeight) {
      contentRef.current.scrollTop = renderPdfRef.current.offsetTop
    }
  }

  // 获取模板
  const getTemplate = () => {
    setLoading(true)
    const params = {
      uid: globalStore.get('uid'),
      orgId: globalStore.get('orgId'),
      id,
    }
    service
      .getTemplate({
        ...params,
      })
      .then(res => {
        setFormType(res.docTemplate.type)
        setFormDataSource(res.docTemplate.fields)
        setDocTemplate(res.docTemplate)
        setRedheadTemplates(res.docTemplate.redHeadFile)
        setLoading(false)
      })
  }

  // 获取来文详情
  const getDocumentOutToDetail = async () => {
    setLoading(true)
    const res = await service.getDocumentOutToDetail({
      fromOrgId,
      orgId,
      id: checkId,
    })
    setLoading(false)
    setOutOrOutToDetail(res.info)
  }

  // 获取上传文件限制
  const getOrgSettingMethods = async () => {
    const {
      setting: { fileLimit },
    } = await service.getOrgSetting({ orgId })
    setFileLimit(fileLimit)
  }

  // 签收
  const onSign = () => {
    service.signDocumentOut({
      fromOrgId,
      orgId,
      id: checkId,
      opinion: '',
      documentId,
    })
  }

  // 签收集团来文
  const onSignGroup = () => {
    service.signGroupDocument({
      id: checkId,
    })
  }

  useEffect(() => {
    if (!documentId) return
    window.addEventListener('process', e => {
      switch (e.detail.type) {
        case 'started': // 启动后
          if (fromOrgId) {
            onSign()
          }
          if (isGroup) {
            onSignGroup()
          }
          history.push('/mydocument')
          break
        case 'approved': // 审批后
          break
        case 'added': // 加签后
          break
        case 'stoped': // 终止后
          break
        case 'rejected': // 退回后
          break
        case 'forworded': // 转交后
          break
        case 'cced': // 抄送后
        default:
      }
    })
    return () => {
      window.removeEventListener('process', () => {}, false)
    }
  }, [documentId])

  // 收文登记转发文字段回填
  useEffect(() => {
    if (docTemplate && docTemplate.fields && outOrOutToDetail && outOrOutToDetail.fields) {
      fieldsManage(formDataSource, outOrOutToDetail.fields)
    }
  }, [docTemplate, outOrOutToDetail])

  // 递归处理容器中的节点
  const detailFieldManage = (field, detail) => {
    // field:模板的field，data：详情的field
    detail.forEach(item => {
      if (item.fieldName === 'rowCard') {
        detailFieldManage(field, item.children)
      }
      if (item.fieldName === field.fieldName) {
        field.value = item.value
      }
    })
  }

  // 处理收文模板字段
  const fieldsManage = (fields, detail) => {
    // fields:模板的fields，detail：详情的fields
    const newFields = fields.map(field => {
      if (field.fieldName === 'rowCard') {
        fieldsManage(field.children, detail)
      }
      detailFieldManage(field, detail)
      return field
    })

    setFormDataSource(newFields)
    // 设置正文value
    const bodyFile = newFields.filter(i => i.fieldName === 'bodyFile')
    if (bodyFile.length && bodyFile[0].value) {
      setBodyFileList(getFileListFromProps(bodyFile[0].value))
      setBodyFileUploadUrl(getFileListFromProps(bodyFile[0].value)[0].originalUrl)
      setFieldsValue({
        bodyFile: getFileListFromProps(bodyFile[0].value),
      })
    }
  }

  // 集团来文转发文字段回填
  useEffect(() => {
    if (docTemplate && hasValue(groupDocumentDetail)) {
      groupFieldsManage(formDataSource, groupDocumentDetail, onSetBodyFileList)
    }
  }, [docTemplate, groupDocumentDetail])

  // 集团来文字段回填时处理正文预览资源
  const onSetBodyFileList = bodyFile => {
    setBodyFileList(getFileListFromProps(bodyFile))
    setBodyFileUploadUrl(getFileListFromProps(bodyFile)[0].originalUrl)
  }

  // 获取正文fileList
  const getFileListFromProps = value => {
    try {
      return JSON.parse(value)
    } catch (error) {
      return []
    }
  }

  // 获取集团详情
  const getGroupDocumentInfo = async () => {
    const res = await service.getGroupDocumentInfo({
      orgId,
      id: checkId,
    })
    setGroupDocumentDetail(res.info)
  }

  // 获取拟稿部门及后续接口获取
  const getDept = async () => {
    const deptData =
      deptList && deptList.length > 0
        ? {
            value: deptList[0].id,
            label: deptList[0].name,
          }
        : {
            value: 0,
            label: 0,
          }
    getRefNoDataSource(deptData.value)
    console.log(deptData, 'deptData')
    setdeptData(deptData)
    service.getOrgDeptPath({ deptId: deptData.value }).then(res => {
      setFullDepartment(res)
      setFieldsValue({ fileDepartment: res })
    })
  }

  // 获取发文机关代字列表
  const getRefNoDataSource = deptId => {
    service
      .getRefNoListByUser({
        orgId,
        deptId: deptId || 0,
        templateId: id,
      })
      .then(res => {
        setRefNoDataSource(res.refNos)
      })
  }

  const handleCloseClassifiedModal = () => setIsShowClassified(false)
  const classifiedCallback = () => setIsShowClassified(true)

  // 密集清单确认
  const onChangeClassifiedValue = (value = []) => {
    const {
      secretClass = '', // 密级清单-密级
      secretTime = '', // 密级清单-保密期限
    } = value && value[0]
    let secretClassOptions = [] // 密级枚举
    let secrecyTermOptions = [] // 保密期限枚举

    // 当枚举列表没有当前value时，变换处理枚举
    const setFormat = (i, value, options, key) => {
      // 查找对应的枚举对象
      const obj = options.find(item => item.text === value)
      if (obj) {
        // 找到则直接赋值
        setFields({ [key]: { value: obj.value } })
        return i
      }
      // 找不到，则先判断是否有 -1 选项
      const obj1 = options.find(item => item.value === -1)
      if (obj1) {
        obj1.text = value
      }
      setFields({ [key]: { value: -1, text: value } })
      return {
        ...i,
        property: JSON.stringify({
          ...JSON.parse(i.property),
          // 有-1选项替换text值，没有则新增-1选项
          options: obj1 ? options : [{ value: -1, text: value }, ...options],
        }),
      }
    }

    const newData = JSON.parse(JSON.stringify(formDataSource))

    // 改变数据源
    const newFormDataSource = (newData || []).map(item => {
      // 先判断是否为分栏容器，分栏容器遍历children
      if (item.fieldName === 'rowCard') {
        // 判断是否为密级或保密期限，查找对应枚举值 setFormat
        const newChild = JSON.parse(JSON.stringify(item.children))
        const newItem = (newChild || []).map(i => {
          if (i.fieldName === 'secretClass') {
            // 密级
            secretClassOptions = JSON.parse(i.property).options
            return setFormat(i, secretClass, secretClassOptions, 'secretClass')
          }
          if (i.fieldName === 'secrecyTerm') {
            // 保密期限
            secrecyTermOptions = JSON.parse(i.property).options
            return setFormat(i, secretTime, secrecyTermOptions, 'secrecyTerm')
          }
          return i
        })
        return {
          ...item,
          children: newItem,
        }
      }
      // 不是分栏容器，直接判断是否为密级或保密期限，查找对应枚举值 setFormat
      if (item.fieldName === 'secretClass') {
        // 密级
        secretClassOptions = JSON.parse(item.property).options
        return setFormat(item, secretClass, secretClassOptions, 'secretClass')
      }
      if (item.fieldName === 'secrecyTerm') {
        // 保密期限
        secrecyTermOptions = JSON.parse(item.property).options
        return setFormat(item, secretTime, secrecyTermOptions, 'secrecyTerm')
      }
      return item
    })

    // 覆盖数据源
    setFormDataSource(newFormDataSource)
    handleCloseClassifiedModal()
  }

  // wps编辑正文回调
  const onWpsContentChange = async fileList => {
    setFieldsValue({
      bodyFile: fileList,
    })
    setBodyFileUploadUrl(fileList[0].originalUrl)
    setBodyFileList(fileList)
  }

  // 获取正文上传的文件
  const getUploadBodyFile = fileList => {
    setBodyFileUploadUrl(fileList.originalUrl)
    setBodyFileList([fileList])
    setFieldsValue({
      bodyFile: [fileList],
    })
  }

  const secretClassChange = value => {
    setSecretClassStatus(value)
  }

  // FileRender 所需参数
  const renderNeedData = {
    form: props.form,
    access,
    refNoDataSource,
    classifiedCallback,
    getUploadBodyFile,
    onWpsContentChange,
    docTemplate,
    id,
    secretClassStatus,
    secretClassChange,
    fileLimit,
    previewIndex,
    redheadTemplates, // 创建正文时自动套的红头模板
    formDataSource,
    type: 'ADD',
    deptId: deptData.value,
    deptName: deptData.label,
    fullDepartment,
  }

  // 底部buttons配置，onClick回调等
  const customButtons = [
    {
      key: 'ccgw', // 差错公文
      onClick: () => {
        let fields = JSON.parse(JSON.stringify(formDataSource))
        const setFieldsValue = (fields, fieldName) => {
          const formFields = getFieldValue(fieldName)
          const [newField, newFieldIndex] = getField(fields, fieldName)
          newField.value = typeof formFields === 'object' ? JSON.stringify(formFields) : formFields
          fields.splice(newFieldIndex, newField)
          return fields
        }
        fields = setFieldsValue(fields, FIELD_TYPE.TITLE)
        fields = setFieldsValue(
          fields,
          FIELD_TYPE.REF_NO || item.fieldName === FIELD_TYPE.RECEIPT_REF_NO,
        )
        setErrFields(fields)
        diffRef.current.wrappedInstance.open()
      },
      async: false,
    },
    {
      key: 'yjxz',
      onClick: () => {
        // 一键下载
        service
          .downloadDocument({
            orgId,
            id, // todo
          })
          .then(res => {
            const { url } = res
            downloadFile(url)
          })
      },
      async: false,
    },
    {
      key: 'scgw',
      onClick: () => {
        return new Promise(resolve => {
          service
            .collectDocument({
              orgId,
              id,
            })
            .then(() => {
              message.success('收藏成功')
              if (onRefreshCollect instanceof Function) {
                onRefreshCollect(!isCollect)
              }
            })
            .finally(() => {
              resolve()
            })
        })
        // return new Promise(resolve => {
        //   service
        //     .collectDocument({
        //       orgId,
        //       id: 307,
        //     })
        //     .then(() => {
        //       message.success('收藏成功!')
        //     })
        //     .finally(() => {
        //       resolve()
        //     })
        // })
      },
      async: true,
    },
  ]

  // 退回
  const onSendBack = () => {
    service
      .backDocumentOut({
        fromOrgId,
        id,
        opinion: '',
      })
      .then(() => {
        message.success('退回成功')
      })
  }
  // 保存并退出
  const onSaveAndOut = type => {
    validateFieldsAndScroll([FIELD_TYPE.TITLE], err => {
      if (!err) {
        const formValue = formGetFieldsValue()
        const res = getFieldsValue(formValue)
        service
          .saveDocumentDraft({
            info: {
              templateID: draftTemplateId || id,
              fields: res,
              type: docTemplate.type || draftType,
            },
          })
          .then(() => {
            message.success('保存成功')
            if (type === 'saveAndOut') {
              location.href = `${window._APP_CONFIG.apiHost}/portal/#/portal/pc-moa-my-drafts/drafts/-1`
            }
          })
      }
    })
  }

  // 传入流程引擎中的公文内部按钮
  const extraButtons =
    isRegister === '1'
      ? [
          {
            name: '退回公文',
            onClick: () => {
              onSendBack()
            },
          },
          {
            name: '保存并退出',
            onClick: () => {
              onSaveAndOut('saveAndOut')
            },
          },
          {
            name: '保存',
            onClick: () => {
              onSaveAndOut('save')
            },
          },
        ]
      : [
          {
            name: '保存并退出',
            onClick: () => {
              onSaveAndOut('saveAndOut')
            },
          },
          {
            name: '保存',
            onClick: () => {
              onSaveAndOut('save')
            },
          },
        ]
  // 初始化获取字段限制
  const buttonsMount = ({ access, editMode }) => {
    if (editMode.includes('web')) {
      setAccess(access)
    }
  }

  // 创建表单值回填
  const createFormValue = (formDataSource, keys, values) => {
    formDataSource.forEach(field => {
      const newField = { ...field }
      if (field.fieldName === 'rowCard') {
        createFormValue(field.children, keys, values)
      }

      if (keys.indexOf(newField.fieldName) !== -1) {
        field.value = values[field.fieldName]
      }

      if (
        (field.fieldName === 'refNo' ||
          field.fieldName === 'outsideRefNo' ||
          field.fieldName === 'receiptRefNo') &&
        isArray(field.value) &&
        field.value.length
      ) {
        const selectOption = refNoDataSource.filter(i => i.name === field.value[0])
        field.extraValue = selectOption && selectOption.length && JSON.stringify(selectOption[0])
      }
    })
  }

  // 处理表单values
  const getFieldsValue = values => {
    const fields = []
    const keys = Object.keys(values) || []
    createFormValue(formDataSource, keys, values, fields)
    return formDataSource
  }

  // 提交表单
  const onSubmit = async () => {
    let formFieldsValue = []
    validateFieldsAndScroll((err, values) => {
      if (!err) {
        const res = getFieldsValue(values)
        formFieldsValue = res
      }
    })

    if (formFieldsValue.length === 0) return

    const res = await service.createDocument({
      orgId,
      info: {
        deptId: deptData.value,
        deptName: deptData.label,
        createUid: uid,
        createName: name,
        createMobile: mobile,
        templateID: draftTemplateId || id,
        // draftId:	0,
        // 可空
        fields: formFieldsValue,
      },
    })
    setDocumentId(res.id)
    return res.id
  }

  const onSubmitOpen = async () => {
    console.log(isFormValueChange, 'isFormValueChange')

    return new Promise((resolve, reject) => {
      validateFieldsAndScroll((err, values) => {
        console.log(err, '!err>>>promise>>>>>>>>>>>>>>>>>')
        if (!err) {
          if (isFormValueChange && formType === 1 && values.bodyFile[0].type) {
            Modal.warning({
              title: '更新正文提醒',
              content: '当前除正文外有其他字段修改，请正文编辑后保存即可生效',
              okText: '确定',
            })
            reject()
          } else {
            const allFieldKeys = Object.keys(values) || []

            let refNo1 = ''
            let refNo2 = ''
            let refNo3 = ''

            if (allFieldKeys.length && allFieldKeys.indexOf('refNo') !== -1) {
              refNo1 = values.refNo[0]
              refNo2 = values.refNo[1]
              refNo3 = values.refNo[2]
            }

            resolve({
              _dept: { label: deptData.label, value: deptData.value },
              refNo1,
              refNo2,
              refNo3,
              ...values,
            })
          }
        } else {
          reject()
        }
      })
    })
  }

  // 获取点击正文列表索引
  const getPreviewIndex = index => {
    setPreviewIndex(index)
  }

  // 返回事件
  const goBack = () => {
    history.goBack()
  }

  return (
    <div className={styles['my-warp']}>
      <Spin spinning={loading}>
        <PageHeader
          title="我的公文"
          icon="totheleft_line"
          type="detail"
          iconColor="#262a30"
          onTitleClick=""
          onIconClick={goBack}
        />
        <PageContent ref={contentRef}>
          <Form {...formItemLayout} className={styles.createContent}>
            {formDataSource.map(item => {
              if (item.fieldName === 'rowCard') {
                let otherProps = {}
                let colSpan = 24
                if (item.children.length === 2) {
                  otherProps = { labelCol: { span: 4 }, wrapperCol: { span: 20 } }
                  colSpan = 12
                }
                if (item.children.length === 3) {
                  otherProps = { labelCol: { span: 6 }, wrapperCol: { span: 18 } }
                  colSpan = 8
                }

                return (
                  <Row gutter={24}>
                    {item.children.map((sub, index) => (
                      <Col span={colSpan} key={index}>
                        {FileRender(sub, renderNeedData, otherProps)}
                      </Col>
                    ))}
                  </Row>
                )
              }
              return FileRender(item, renderNeedData)
              // return !access[item.fieldName] || access[item.fieldName] === 'NONE'
              //   ? ''
              //   : FileRender(item, renderNeedData)
            })}
          </Form>
          {bodyFileUploadUrl && (
            <RenderPdf
              setFieldsValue={setFieldsValue}
              onWpsContentChange={onWpsContentChange}
              url={bodyFileUploadUrl}
              fileList={bodyFileList}
              fields={formDataSource}
              getPreviewIndex={getPreviewIndex}
              id={id}
              redheadTemplates={redheadTemplates}
              ref={renderPdfRef}
              access={access}
              isCreate
              form={props.form}
              type="ADD"
              formType={formType}
              contentWidth={contentWidth}
            />
          )}
          {deptData.value && formDataSource.length > 0 && (proKey || draftProkey) && (
            <div className={styles.buttonsWrap} ref={btnsRef}>
              <Buttons
                appId="b3b8415184344e7799733a0fd33d7221"
                procKey={proKey || draftProkey}
                // procKey="WF_DE20220302094411174152"
                customButtons={customButtons}
                onMount={buttonsMount}
                onSubmitOpen={onSubmitOpen}
                onSubmit={onSubmit}
                extraButtons={extraButtons}
              />
            </div>
          )}
          {bodyFileUploadUrl &&
            (!backToTop ? (
              <div className={styles.scrollBtn} onClick={onScrollToBodyFileOrTop}>
                <XmiconReact name="arrowis_down_line" size={16} />
                只看正文
              </div>
            ) : (
              <div className={styles.scrollBtn} onClick={onScrollToBodyFileOrTop}>
                <XmiconReact name="arrows_up_line" size={16} />
                回到顶部
              </div>
            ))}
        </PageContent>
        {isShowClassified && (
          <ClassifiedModal
            onChange={onChangeClassifiedValue}
            handleCloseModal={handleCloseClassifiedModal}
          />
        )}
      </Spin>
    </div>
  )
}

export default connect(
  state => ({
    orgId: state.globalInfo.baseInfo.orgId,
    collapsed: state.globalInfo.collapsed,
    isFormValueChange: state.globalInfo.isFormValueChange,
  }),
  dispatch => ({
    actions: bindActionCreators(
      {
        onFormValueChange,
      },
      dispatch,
    ),
  }),
)(
  Form.create({
    onValuesChange(props, changedValues) {
      const changeKey = Object.keys(changedValues) || []
      if (
        (indexOf(changeKey, 'mainSend') && isArray(changedValues.mainSend)) ||
        (indexOf(changeKey, 'copySend') && isArray(changedValues.copySend)) ||
        (indexOf(changeKey, 'title') && changedValues.title) ||
        (indexOf(changeKey, 'urgencyLevel') && changedValues.urgencyLevel) ||
        (indexOf(changeKey, 'secretClass') && changedValues.secretClass) ||
        (indexOf(changeKey, 'secrecyTerm') && changedValues.secrecyTerm) ||
        indexOf(changeKey, 'enclosure')
      ) {
        props.actions.onFormValueChange(true)
      }
      // if (indexOf(changeKey, 'bodyFile')) {
      //   props.actions.onFormValueChange(false)
      // }
    },
    onFieldsChange(props, changedValues) {
      const changeKey = Object.keys(changedValues) || []

      if (changeKey.length && changeKey.indexOf('refNo') !== -1) {
        props.actions.onFormValueChange(true)
      }
      // if (indexOf(changeKey, 'bodyFile')) {
      //   props.actions.onFormValueChange(false)
      // }
    },
  })(List),
)
