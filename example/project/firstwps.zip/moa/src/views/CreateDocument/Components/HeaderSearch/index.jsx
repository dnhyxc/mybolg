import React, { useState, useReducer, useEffect } from 'react'
import ClassNames from 'classnames'
import moment from 'moment'
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import { Form, Button } from 'antd'
import SearchTerm from 'ROOT/components/SearchTerm'

import styles from './index.scss'

const initialState = {
  docTitle: '',
  docType: '',
  refNo: ['', undefined, ''],
  docTimer: [],
  docCreater: [],
  docDept: [],
  docState: undefined,
}
const createAction = (type, payload) => {
  return {
    type,
    payload,
  }
}
const reducer = function reducer(state, action) {
  switch (action.type) {
    case 'docTitle':
      return { ...state, docTitle: action.payload }
    case 'docType':
      return { ...state, docType: action.payload }
    case 'refNo':
      return { ...state, refNo: action.payload }
    case 'docTimer':
      return { ...state, docTimer: action.payload }
    case 'docCreater':
      return { ...state, docCreater: action.payload }
    case 'docDept':
      return { ...state, docCreater: action.payload }
    case 'docState':
      return { ...state, docState: action.payload }
    case 'reset':
      return { ...initialState }
    default:
      return state
  }
}
const HeaderSearch = props => {
  const { onSearchChange } = props
  const [formData, dispatch] = useReducer(reducer, initialState)

  const handleFormItemValueChange = (type, value) => {
    dispatch(createAction(type, value))
  }
  const options = [
    {
      value: 'zhejiang',
      label: 'Zhejiang',
      children: [
        {
          value: 'hangzhou',
          label: 'Hangzhou',
          children: [
            {
              value: 'xihu',
              label: 'West Lake',
            },
          ],
        },
      ],
    },
    {
      value: 'jiangsu',
      label: 'Jiangsu',
      children: [
        {
          value: 'nanjing',
          label: 'Nanjing',
          children: [
            {
              value: 'zhonghuamen',
              label: 'Zhong Hua Men',
            },
          ],
        },
      ],
    },
  ]
  const handleReset = () => {
    dispatch(createAction('reset', ''))
    onSearchChange({
      isReset: true,
      sreen: {
        title: '',
        beginTime: 0,
        endTime: 0,
        type: 0,
        templateIds: [],
        tab: 0,
        createUids: [],
        doneUids: [],
        status: 0,
        otherOrgId: 0,
        deptIds: [],
        refNo1: '',
        refNo2: '',
        refNo3: '',
      },
    })
  }
  const handleSearch = () => {
    onSearchChange({
      isReset: false,
      sreen: {
        title: formData.docTitle,
        type: formData.docType[0],
        beginTime: formData.docTimer[0]
        ? new Date(`${formatDate(formData.docTimer[0], 'YYYY-MM-DD')} 00:00:00`).getTime()
        : 0,
      endTime: formData.docTimer[1]
        ? new Date(`${formatDate(formData.docTimer[1], 'YYYY-MM-DD')} 23:59:59`).getTime()
        : 0,
        templateIds: formData.docType[1],
        tab: 0,
        createUids: formData.docCreater.uid,
        doneUids: '',
        status: formData.docState,
        otherOrgId: 0,
        deptIds: formData.docDept,
        refNo1: formData.refNo[0],
        refNo2: formData.refNo[1],
        refNo3: formData.refNo[2],
      },
    })
  }
  useEffect(() => {
    return () => {}
  }, [])
  return (
    <div className={styles.search}>
      <Form layout="inline">
        <SearchTerm
          type="input"
          label="公文标题:"
          placeholder="请输入标题"
          value={formData.docTitle}
          onChange={value => {
            handleFormItemValueChange('docTitle', value)
          }}
        />
        <SearchTerm
          type="cascader"
          label="公文类型:"
          options={options}
          placeholder="请选择公文类型"
          value={formData.docType}
          onChange={value => {
            handleFormItemValueChange('docType', value)
          }}
        />
        <SearchTerm
          type="refNo"
          label="发文文号:"
          value={formData.refNo}
          onChange={value => {
            handleFormItemValueChange('refNo', value)
          }}
        />
        <SearchTerm
          type="datePicker"
          label="起草时间:"
          placeholder="请选择公文类型"
          value={formData.docTimer}
          onChange={value => {
            handleFormItemValueChange('docTimer', value)
          }}
        />
        <SearchTerm
          type="selectUser"
          label="起草人"
          placeholder="请选择公文类型"
          value=""
          onChange={value => {
            handleFormItemValueChange('docCreater', value)
          }}
        />
        <SearchTerm
          type="selectDept"
          label="起草部门"
          placeholder="请选择公文类型"
          value=""
          onChange={value => {
            handleFormItemValueChange('docDept', value)
          }}
        />
        <SearchTerm
          type="select"
          label="公文状态"
          placeholder="请选择公文状态"
          options={options}
          value={formData.docState}
          onChange={value => {
            handleFormItemValueChange('docState', value)
          }}
        />
        <SearchTerm>
          <Button className={styles.reset} onClick={handleReset}>
            重置
          </Button>
          <Button type="primary" onClick={handleSearch}>
            查询
          </Button>
        </SearchTerm>
      </Form>
    </div>
  )
}

export default connect(
  state => ({
    orgId: state.globalInfo.baseInfo.orgId,
  }),
  dispatch => ({
    actions: bindActionCreators({}, dispatch),
  }),
)(HeaderSearch)
