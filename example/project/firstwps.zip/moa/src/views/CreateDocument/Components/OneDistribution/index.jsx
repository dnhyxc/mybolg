import React, { useState, useEffect } from 'react'
import { Modal, Spin } from 'antd'

import styles from './index.scss'

const OneDistribution = (props) => {

  const {
    visible,
    copyUserList = [], // 抄送列表
    mainUserList = [], // 主送列表
    oneDistributionOk,
    oneDistributionCancel,
    userLoading,
  } = props

  const userNum = copyUserList && copyUserList.concat(mainUserList).length

  const handleOk = () => oneDistributionOk && oneDistributionOk()

  const handleCancel = () => oneDistributionCancel && oneDistributionCancel()


  return (<Modal
    title="确定要一键分发吗？"
    visible={visible}
    width={680}
    onOk={handleOk}
    onCancel={handleCancel}
  >
    <Spin spinning={userLoading}>
      <p>{`即将分发给以下人员（${userNum}人）:`}</p>
      <div className={styles.mainContent}>
        <div className={styles.mainDelivery}>
          <div className={styles.mainHeader}>主送人员：</div>
          {mainUserList && mainUserList.map((item, index) => {
            return <div className={styles.mainList} key={index}>{`${item.deptName || item.orgName}(${item.name})`}</div>
          })}

        </div>
        <div className={styles.mainDelivery}>
          <div className={styles.mainHeader}>抄送人员：</div>
          {copyUserList && copyUserList.map((item, index) => {
            return <div className={styles.mainList} key={index}>{`${item.deptName || item.orgName}(${item.name})`}</div>
          })}
        </div>
      </div>
    </Spin>

  </Modal>)
}


export default OneDistribution
