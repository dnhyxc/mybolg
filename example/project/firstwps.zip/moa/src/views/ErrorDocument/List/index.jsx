import React, { useState, useEffect, useRef } from 'react'
import { Table, Button, message } from 'antd'
import HeaderSearch from 'ROOT/views/ErrorDocument/Components/HeaderSearch'
import PageHeader from 'ROOT/components/PageHeader'
import PageContent from 'ROOT/components/PageContent'
import TableTitle from 'ROOT/components/TableTitle'
import DiffCustomConfigInput from 'ROOT/components/DiffCustomConfigInput'
import DiffCustomInput from 'ROOT/components/DiffCustomInput'
import service from 'ROOT/service'
import { formatDate, downloadFile } from 'ROOT/utils'
import { OFFICIAL_TYPE_TEXT } from 'ROOT/constant'
import ClassNames from 'classnames'
import styles from './index.scss'

const List = () => {
  const diffRef = useRef(null)
  const diffConfigRef = useRef(null)
  const [list, setList] = useState([])
  const [viewDetail, setViewDetail] = useState(null)
  const [selectedRowKeys, setSelectedRowKeys] = useState([])
  const [loading, setLoading] = useState(false)
  const [allCount, setallCount] = useState(0)
  const [params, setParams] = useState({
    pageId: 1,
    pageCount: 10,
    screen: {
      title: '',
      type: 0,
      childType: 0,
    },
  })

  const handleSearchChange = data => {
    setSelectedRowKeys([])
    setParams({ ...params, pageId: 1, screen: data })
  }

  const getData = () => {
    setLoading(true)
    service
      .getDocumentErrList({
        ...params,
      })
      .then(res => {
        const { allCount, infos } = res
        setLoading(false)
        setList(infos)
        setallCount(allCount)
      })
      .finally(() => {
        setLoading(false)
      })
  }

  const pageChange = page => {
    setParams({ ...params, pageId: page })
  }

  const onShowSizeChange = (current, pageSize) => {
    setParams({ ...params, pageCount: pageSize })
  }
  const clickJump = record => {
    setViewDetail(record)
    diffRef.current.wrappedInstance.open()
  }

  const columns = [
    {
      title: '公文标题',
      fixed: 'left',
      width: 300,
      key: 'title',
      dataIndex: 'title',
      render: text => <TableTitle title={{ value: text }} />,
    },
    {
      title: '部门',
      key: 'deptName',
      width: 200,
      dataIndex: 'deptName',
      render: text => text || '-',
    },
    {
      title: '文号',
      key: 'refNo',
      dataIndex: 'refNo',

      render: text => text || '-',
    },
    {
      title: '公文类型',
      key: 'type',
      width: 150,
      render: x => OFFICIAL_TYPE_TEXT[x.type],
    },
    {
      title: '问题数',
      key: 'errs',
      width: 150,
      dataIndex: 'errs',
      render: text => (
        <span style={{ color: '#FA5F5F' }}>{(Array.isArray(text) && text.length) || '-'}</span>
      ),
    },
    {
      title: '录入人',
      width: 150,
      key: 'createName',
      dataIndex: 'createName',
      render: text => text || '-',
    },
    {
      title: '录入时间',
      width: 200,
      key: 'createTime',
      dataIndex: 'createTime',
      render: x => formatDate(x, 'YYYY/MM/DD HH:mm'),
    },
  ]
  const handleConfigOpen = () => {
    diffConfigRef.current.wrappedInstance.open()
  }

  const getExportElsx = ({ ids, isAll = false }) => {
    return service
      .exportDocumentErrList({
        ids,
        isAll,
      })
      .then(res => {
        const { url } = res
        downloadFile(url, '', true)
      })
  }
  const handleExport = () => {
    if (selectedRowKeys.length === 0) {
      message.warning('至少选择一条差错才能导出')
      return
    }

    getExportElsx({
      ids: selectedRowKeys,
    }).then(() => {
      message.success('导出成功')
    })
  }

  const handleExportAll = () => {
    getExportElsx({
      isAll: true,
    }).then(() => {
      message.success('导出成功')
    })
  }
  const renderHeader = () => {
    return (
      <div className={styles['extra-actions']}>
        <a className={ClassNames('c_link', styles['action-item'])} onClick={handleConfigOpen}>
          <i className={ClassNames('iconfont icon-shezhi1', styles['err-icon'])} />
          <span className="ml-8">差错选项配置</span>
        </a>
        <Button className="ml-16" onClick={handleExport}>
          导出
        </Button>
        <Button className="ml-8" onClick={handleExportAll}>
          全部导出
        </Button>
      </div>
    )
  }
  const rowSelection = {
    selectedRowKeys,
    onChange: selectedRowKeys => {
      setSelectedRowKeys(selectedRowKeys)
    },
  }
  useEffect(() => {
    getData()
  }, [params])
  return (
    <div className={styles['my-warp']}>
      <PageHeader title="差错公文">{renderHeader()}</PageHeader>
      <PageContent>
        <HeaderSearch onSearchChange={handleSearchChange} />
        <Table
          loading={loading}
          columns={columns}
          dataSource={list}
          rowKey={x => x.documentId}
          fixed
          rowSelection={rowSelection}
          scroll={{
            x: 1500,
            scrollToFirstRowOnChange: true,
          }}
          pagination={
            !allCount
              ? false
              : {
                  total: allCount,
                  current: params.pageId,
                  pageSize: params.pageCount,
                  onChange: pageChange,
                  showSizeChanger: true,
                  showQuickJumper: true,
                  onShowSizeChange,
                  showTotal: total =>
                    `共${total}条记录  第${params.pageId}/${Math.ceil(total / params.pageCount)}页`,
                }
          }
          onRow={record => {
            return {
              onClick: () => {
                clickJump(record)
              },
            }
          }}
        />
        <DiffCustomInput
          ref={diffRef}
          readOnly
          dataSource={viewDetail}
          // onOk={handleCloseDiff}
        />

        <DiffCustomConfigInput ref={diffConfigRef} />
      </PageContent>
    </div>
  )
}

export default List
