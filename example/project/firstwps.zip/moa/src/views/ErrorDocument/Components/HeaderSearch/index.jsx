import React, { useState, useReducer, useEffect } from 'react'
import ClassNames from 'classnames'
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import { Form, Button } from 'antd'
import { OFFICIAL_TYPE_SEARCH_CASCADER } from 'ROOT/constant'
import SearchTerm from 'ROOT/components/SearchTerm'
import styles from './index.scss'

const initialState = {
  docTitle: '',
  docType: [],
}
const createAction = (type, payload) => {
  return {
    type,
    payload,
  }
}
const reducer = function reducer(state, action) {
  switch (action.type) {
    case 'docTitle':
      return { ...state, docTitle: action.payload }
    case 'docType':
      return { ...state, docType: action.payload }

    case 'reset':
      return { ...initialState }
    default:
      return state
  }
}
const HeaderSearch = props => {
  const { onSearchChange } = props
  const [formData, dispatch] = useReducer(reducer, initialState)

  const handleFormItemValueChange = (type, value) => {
    dispatch(createAction(type, value))
  }

  const handleReset = () => {
    dispatch(createAction('reset', ''))
    onSearchChange({
      title: '',
      type: 0,
      childType: 0,
    })
  }
  const handleSearch = () => {
    onSearchChange({
      title: formData.docTitle,
      type: formData.docType[0] || 0,
      childType: formData.docType[1] || 0,
    })
  }

  return (
    <div className={styles.search}>
      <Form layout="inline">
        <SearchTerm
          type="input"
          label="公文标题:"
          placeholder="请输入标题"
          value={formData.docTitle}
          onChange={value => {
            handleFormItemValueChange('docTitle', value)
          }}
        />
        <SearchTerm
          type="cascader"
          label="公文类型:"
          options={OFFICIAL_TYPE_SEARCH_CASCADER}
          placeholder="请选择公文类型"
          value={formData.docType}
          onChange={value => {
            handleFormItemValueChange('docType', value)
          }}
        />

        <SearchTerm>
          <Button className={styles.reset} onClick={handleReset}>
            重置
          </Button>
          <Button type="primary" onClick={handleSearch}>
            查询
          </Button>
        </SearchTerm>
      </Form>
    </div>
  )
}

export default connect(
  state => ({
    orgId: state.globalInfo.baseInfo.orgId,
  }),
  dispatch => ({
    actions: bindActionCreators({}, dispatch),
  }),
)(HeaderSearch)
