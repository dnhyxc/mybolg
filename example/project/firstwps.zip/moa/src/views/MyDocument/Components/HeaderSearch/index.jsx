import React, { useReducer, useEffect } from 'react'
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import { Form, Button } from 'antd'
import { OFFICIAL_TYPE_SEARCH_CASCADER } from 'ROOT/constant'
import SearchTerm from 'ROOT/components/SearchTerm'
import { formatDate } from 'ROOT/utils'
import styles from './index.scss'

const initialState = {
  createUserName: '',
  createDeptName: '',
  docTitle: '',
  docType: [],
  refNo: ['', undefined, ''],
  docTimer: [],
  docCreater: [],
  docDept: [],
  docState: undefined,
}
const createAction = (type, payload) => {
  return {
    type,
    payload,
  }
}
const reducer = function reducer(state, action) {
  switch (action.type) {
    case 'docTitle':
      return { ...state, docTitle: action.payload }
    case 'docType':
      return { ...state, docType: action.payload }
    case 'refNo':
      return { ...state, refNo: action.payload }
    case 'docTimer':
      return { ...state, docTimer: action.payload }
    case 'docCreater':
      return { ...state, docCreater: action.payload }
    case 'docDept':
      return { ...state, docDept: action.payload }
    case 'docState':
      return { ...state, docState: action.payload }
    case 'createUserName':
      return { ...state, createUserName: action.payload }
    case 'createDeptName':
      return { ...state, createDeptName: action.payload }
    case 'reset':
      return { ...initialState }
    default:
      return state
  }
}
const HeaderSearch = props => {
  const { onSearchChange } = props
  const [formData, dispatch] = useReducer(reducer, initialState)
  // const [typeOptions, setTypeOptions] = useState([])
  // const handleGetDocumentFlowListByUser = () => {
  //   service.getTemplateList({}).then(res => {
  //     const docTypeList = []
  //     OFFICIAL_TYPE_SEARCH.forEach(typeItem => {
  //       const typeItemObj = { ...typeItem }
  //       typeItemObj.children = res.flows
  //         .filter(flowItem => flowItem.type === typeItem.value)
  //         .map(child => ({ label: child.name, value: child.flowId }))
  //       docTypeList.push(typeItemObj)
  //     })

  //     setTypeOptions(docTypeList)
  //   })
  // }
  const handleFormItemValueChange = (type, value) => {
    dispatch(createAction(type, value))
  }

  const handleReset = () => {
    dispatch(createAction('reset', ''))
    onSearchChange({
      title: '',
      beginTime: 0,
      endTime: 0,
      type: 0,
      childType: 0,
      // templateIds: [],
      createUids: [],
      // status: 0,
      deptIds: [],
      createUserName: '',
      createDeptName: '',
      refNo1: '',
      refNo2: '',
      refNo3: '',
    })
  }
  const handleSearch = () => {
    onSearchChange({
      title: formData.docTitle,
      beginTime: formData.docTimer[0]
        ? new Date(`${formatDate(formData.docTimer[0], 'YYYY-MM-DD')} 00:00:00`).getTime()
        : 0,
      endTime: formData.docTimer[1]
        ? new Date(`${formatDate(formData.docTimer[1], 'YYYY-MM-DD')} 23:59:59`).getTime()
        : 0,
      type: formData.docType[0] || 0,
      childType: formData.docType[1] || 0,
      // templateIds: formData.docType[1] ? [formData.docType[1]] : [],
      // tab: 0,
      createUids: formData.docCreater.some(x => x.name === formData.createUserName)
        ? formData.docCreater.map(dc => dc.id)
        : [],
      deptIds: formData.docDept.some(x => x.name === formData.createDeptName)
        ? formData.docDept.map(dd => dd.id)
        : [],
      // status: formData.docState,
      refNo1: formData.refNo[0],
      refNo2: formData.refNo[1] ? formData.refNo[1] : '',
      refNo3: formData.refNo[2],
      createDeptName: formData.createDeptName,
      createUserName: formData.createUserName,
    })
  }
  useEffect(() => {
    // handleGetDocumentFlowListByUser()
  }, [])
  return (
    <div className={styles.search}>
      <Form layout="inline">
        <SearchTerm
          type="input"
          label="公文标题:"
          placeholder="请输入标题"
          value={formData.docTitle}
          onChange={value => {
            handleFormItemValueChange('docTitle', value)
          }}
        />
        <SearchTerm
          type="cascader"
          label="公文类型:"
          options={OFFICIAL_TYPE_SEARCH_CASCADER}
          placeholder="请选择公文类型"
          value={formData.docType}
          onChange={value => {
            handleFormItemValueChange('docType', value)
          }}
        />
        <SearchTerm
          type="refNo"
          label="发文文号:"
          value={formData.refNo}
          onChange={value => {
            handleFormItemValueChange('refNo', value)
          }}
        />
        <SearchTerm
          type="datePicker"
          label="起草时间:"
          placeholder={['开始时间', '结束时间']}
          value={formData.docTimer}
          onChange={value => {
            handleFormItemValueChange('docTimer', value)
          }}
        />
        <SearchTerm
          type="selectUser"
          label="起草人"
          title="请选择起草人"
          range={1}
          placeholder="请选择起草人"
          value={formData.createUserName}
          onChange={value => {
            handleFormItemValueChange('createUserName', value)
          }}
          onChangeByTree={value => {
            handleFormItemValueChange('docCreater', value)
          }}
        />
        <SearchTerm
          type="selectDept"
          label="起草部门"
          range={1}
          chooseDept
          placeholder="请选择起草部门"
          value={formData.createDeptName}
          onChange={value => {
            handleFormItemValueChange('createDeptName', value)
          }}
          onChangeByTree={value => {
            handleFormItemValueChange('docDept', value)
          }}
        />
        {/* <SearchTerm
          type="select"
          label="公文状态"
          placeholder="请选择公文状态"
          options={[]}
          value={formData.docState}
          onChange={value => {
            handleFormItemValueChange('docState', value)
          }}
        /> */}
        <SearchTerm>
          <Button className={styles.reset} onClick={handleReset}>
            重置
          </Button>
          <Button type="primary" onClick={handleSearch}>
            查询
          </Button>
        </SearchTerm>
      </Form>
    </div>
  )
}

export default connect(
  state => ({
    orgId: state.globalInfo.baseInfo.orgId,
  }),
  dispatch => ({
    actions: bindActionCreators({}, dispatch),
  }),
)(HeaderSearch)
