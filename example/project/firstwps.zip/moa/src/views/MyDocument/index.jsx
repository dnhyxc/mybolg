import React from 'react'
import { Route, Switch, Redirect } from 'react-router-dom'
import { getSearchParam } from 'ROOT/utils'

import List from './List'
import ListDetail from './ListDetail'

const MyDocument = props => {
  const { match } = props

  const procFormDataKey = getSearchParam('procFormDataKey') || null // 需要获取模板字段的id

  console.log(procFormDataKey, 'procFormDataKey')
  console.log(match, 'match')
  console.log(`${match.path}/${procFormDataKey}`, 'matchpath')

  return (
    <Switch>
      <Route path={match.path} exact component={List} />
      <Route path={`${match.path}/detail/:id?`} exact component={ListDetail} />
      <Redirect to={match.path} />
    </Switch>
  )
}

export default MyDocument
