import React, { useState, useEffect } from 'react'
import { Table, Button, message, Modal } from 'antd'
import HeaderSearch from 'ROOT/views/CitySearch/Components/HeaderSearch'
import PageHeader from 'ROOT/components/PageHeader'
import PageContent from 'ROOT/components/PageContent'
import TableTitle from 'ROOT/components/TableTitle'
import service from 'ROOT/service'
import { formatDate, getSerialNumStrFromStr } from 'ROOT/utils'
import styles from './index.scss'

const List = () => {
  const [list, setList] = useState([])
  const [loading, setLoading] = useState(false)
  const [allCount, setallCount] = useState(0)
  const [isShow, setIsShow] = useState(false)
  const [params, setParams] = useState({
    pageId: 1,
    pageCount: 10,
    screen: {
      beginTime: 0,
      endTime: 0,
      tab: 1,
      title: '',
    },
  })

  const handleSearchChange = data => {
    setParams({ ...params, pageId: 1, screen: data })
  }

  const getData = () => {
    setLoading(true)
    service
      .getDocumentOutFromList({
        ...params,
      })
      .then(res => {
        const { allCount, infos } = res
        setLoading(false)
        setList(infos)
        setallCount(allCount)
      })
      .finally(() => {
        setLoading(false)
      })
  }

  const onShowSizeChange = (current, pageSize) => {
    setParams({ ...params, pageCount: pageSize })
  }
  const pageChange = page => {
    setParams({ ...params, pageId: page })
  }

  const clickJump = record => {}

  const backDispatchDoc = item => {
    Modal.confirm({
      title: '系统提示',
      okText: '确认',
      cancelText: '取消',
      content: '您确定要撤回公文吗？撤回后对方单位将无法查看该公文',
      onOk: () => {
        service
          .recallDocumentOut({
            id: item.id,
          })
          .then(() => {
            message.success('撤回成功')
            getData()
          })
      },
    })
  }

  const columns = [
    {
      title: '公文标题',
      fixed: 'left',
      width: 300,
      key: 'title',
      dataIndex: 'title',
      render: text => <TableTitle title={{ value: text }} />,
    },
    {
      title: '发文文号',
      key: 'refNo',
      dataIndex: 'refNo',
      render: text => (text && getSerialNumStrFromStr(text)) || '-',
    },
    {
      title: '接收单位',
      key: 'toOrgs',
      dataIndex: 'toOrgs',
      width: 150,
      render: toOrgs => {
        const showedOrgNum = 3
        let orgs
        const allOrgs = toOrgs.map(it => it.orgName).join('、')
        if (toOrgs.length > showedOrgNum) {
          orgs = `${toOrgs
            .slice(0, showedOrgNum)
            .map(it => it.orgName)
            .join('、')}等${toOrgs.length}个单位`
        } else {
          orgs = allOrgs
        }
        return <div title={allOrgs}>{orgs}</div>
      },
    },
    {
      title: '发送时间',
      width: 200,
      key: 'sendTime',
      dataIndex: 'sendTime',
      render: x => formatDate(x, 'YYYY/MM/DD HH:mm'),
    },
    {
      title: '发送人',
      width: 160,
      key: 'sendName',
      dataIndex: 'sendName',
      render: text => text || '-',
    },
    {
      title: '签收/退回/待收',
      width: 160,
      render: item => {
        const sendNum = item.toOrgs.length
        const signNum = item.toOrgs.filter(it => it.signTime && !it.backTime).length
        const backNum = item.toOrgs.filter(it => it.backTime).length
        return (
          <span>
            <span className={styles.green}>{signNum}</span> /
            <span className={styles.red}>{backNum}</span> /
            <span>{sendNum - signNum - backNum}</span>
          </span>
        )
      },
    },
    {
      title: '操作',
      width: 200,
      render: item => {
        const isBack = item.status === 2 // status 1 正常，2 撤回
        return (
          <span>
            {isBack ? (
              <span>已撤回</span>
            ) : (
              <span>
                <a className="c_link" onClick={() => backDispatchDoc(item)}>
                  撤回
                </a>
                <a
                  className="c_link ml-16"
                  onClick={() => {
                    service
                      .urgeDocumentOut({
                        id: item.id,
                      })
                      .then(() => {
                        message.info('已催办未签收的收文单位')
                      })
                  }}
                >
                  催办
                </a>
              </span>
            )}
          </span>
        )
      },
    },
  ]

  const handleCreateSendDocument = () => {
    setIsShow(true)
  }

  const renderHeader = () => {
    return (
      <div className={styles['extra-actions']}>
        <Button type="primary" className="ml-16" onClick={handleCreateSendDocument}>
          新建对外发文
        </Button>
      </div>
    )
  }

  useEffect(() => {
    getData()
  }, [params])
  return (
    <div className={styles['my-warp']}>
      <PageHeader title="对外发文">{renderHeader()}</PageHeader>
      <PageContent>
        <HeaderSearch onSearchChange={handleSearchChange} />
        <Table
          loading={loading}
          columns={columns}
          dataSource={list}
          rowKey={x => x.id}
          fixed
          scroll={{
            x: 1500,
            scrollToFirstRowOnChange: true,
          }}
          pagination={
            !allCount
              ? false
              : {
                  total: allCount,
                  current: params.pageId,
                  pageSize: params.pageCount,
                  onChange: pageChange,
                  showSizeChanger: true,
                  showQuickJumper: true,
                  onShowSizeChange,
                  showTotal: total =>
                    `共${total}条记录  第${params.pageId}/${Math.ceil(total / params.pageCount)}页`,
                }
          }
          onRow={record => {
            return {
              onClick: () => {
                clickJump(record)
              },
            }
          }}
        />
      </PageContent>
    </div>
  )
}

export default List
