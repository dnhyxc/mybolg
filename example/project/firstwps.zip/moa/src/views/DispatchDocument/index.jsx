import React from 'react'
import { Route, Switch, Redirect } from 'react-router-dom'

import List from './List'
import ListDetail from './ListDetail'

const DispatchDocument = props => {
  const { match } = props

  return (
    <Switch>
      <Route path={match.path} exact component={List} />
      <Route path={`${match.path}/:id`} exact component={ListDetail} />
      <Redirect to={match.path} />
    </Switch>
  )
}

export default DispatchDocument
