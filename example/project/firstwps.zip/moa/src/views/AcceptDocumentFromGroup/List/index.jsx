import React, { useState, useEffect, useRef } from 'react'
import { Table, Tabs, Badge, message } from 'antd'
import HeaderSearch from 'ROOT/views/AcceptDocumentFromGroup/Components/HeaderSearch'
import PageHeader from 'ROOT/components/PageHeader'
import PageContent from 'ROOT/components/PageContent'
import TableTitle from 'ROOT/components/TableTitle'
import service from 'ROOT/service'
import { formatDate } from 'ROOT/utils'
import { connect } from 'react-redux'
import styles from './index.scss'

const { TabPane } = Tabs
const List = props => {
  const ref = useRef()
  const { history, uid } = props
  const [list, setList] = useState([])
  const [loading, setLoading] = useState(false)
  const [allCount, setallCount] = useState(0)
  const [params, setParams] = useState({
    pageId: 1,
    pageCount: 10,
    screen: {
      beginTime: 0,
      endTime: 0,
      tab: '1',
      title: '',
    },
  })
  const handleSearchChange = data => {
    setParams({ ...params, pageId: 1, screen: { ...params.screen, ...data } })
  }

  const getData = () => {
    setLoading(true)
    service
      .getGroupDocumentList({
        ...params,
      })
      .then(res => {
        const { allCount, infos } = res
        setLoading(false)
        setList(infos)
        setallCount(allCount)
      })
      .finally(() => {
        setLoading(false)
      })
  }

  const onShowSizeChange = (current, pageSize) => {
    setParams({ ...params, pageCount: pageSize })
  }
  const pageChange = page => {
    setParams({ ...params, pageId: page })
  }

  const jumpCreate = (item, id) => {
    service.getAppDetailList({ uid }).then(res => {
      let data = null
      // 递归查找流程定义key
      const getModelKey = details => {
        details.forEach(detail => {
          if (detail.children.length > 0) {
            getModelKey(detail.children)
          }
          if (detail.extra) {
            const extra = JSON.parse(detail.extra)
            if (extra.procFormKey === item.formModelKey) {
              data = detail
            }
          }
        })
      }

      if (res.details.length > 0) {
        const { details } = res
        getModelKey(details)
        if (data) {
          history.push(
            `create-document?id=${item.id}&checkId=${id}&isGroup=${true}&isRegister=${
              params.screen.tab === '1' ? '1' : '2'
            }&proKey=${data.detailKey}`,
          )
        } else {
          message.info('没有找到模版对应的流程')
        }
      }
    })
  }
  const clickJump = ({ id }) => {
    service.getTemplateList({ uid }).then(res => {
      const { docTemplates } = res
      const docTemplate = docTemplates.filter(x => x.type === 2)
      if (docTemplate.length === 0) {
        return message.error('请配置收文模板')
      }
      jumpCreate(docTemplate[0], id)
    })
  }

  const registerColumns = [
    {
      title: '公文标题',
      fixed: 'left',
      width: 300,
      key: 'docTitle',
      render: item => <TableTitle title={{ value: item.docInfo.docTitle }} />,
    },
    {
      title: '发文文号',
      key: 'docNumber',
      render: item => item.docInfo.docNumber || '-',
    },
    {
      title: '发送单位',
      key: 'issuingUnit',
      width: 200,
      render: item => item.docInfo.issuingUnit || '-',
    },
    // {
    //   title: '发送人',
    //   width: 160,
    //   key: 'sendName',
    //   dataIndex: 'sendName',
    //   render: text => text || '-',
    // },
    {
      title: '发送时间',
      width: 200,
      key: 'createTime',
      render: item => formatDate(item.docInfo.createTime, 'YYYY/MM/DD HH:mm') || '-',
    },
    {
      title: '状态',
      width: 160,
      dataIndex: 'status',
      render: text => {
        let statusColor = ''
        let statusText = ''
        switch (text) {
          case 1:
            statusColor = '#959BA3'
            statusText = '待签收'
            break
          case 2:
            statusColor = '#F4A022'
            statusText = '已签收'
            break
          default:
            break
        }
        return <Badge color={statusColor} text={statusText} />
      },
    },
  ]

  const registeredColumns = [
    {
      title: '公文标题',
      fixed: 'left',
      width: 300,
      key: 'docTitle',
      render: item => <TableTitle title={{ value: item.docInfo.docTitle }} />,
    },
    {
      title: '发文文号',
      key: 'docNumber',
      render: item => item.docInfo.docNumber || '-',
    },
    {
      title: '发送单位',
      key: 'issuingUnit',
      width: 200,
      render: item => item.docInfo.issuingUnit || '-',
    },
    // {
    //   title: '发送人',
    //   width: 160,
    //   key: 'sendName',
    //   render: item => item.docInfo.sendName || '-',
    // },
    {
      title: '发送时间',
      width: 200,
      key: 'createTime',
      render: item => formatDate(item.docInfo.createTime, 'YYYY/MM/DD HH:mm') || '-',
    },
    {
      title: '签收人',
      width: 150,
      key: 'signName',
      dataIndex: 'signName',
      render: text => text || '-',
    },
    {
      title: '签收时间',
      width: 150,
      key: 'signTime',
      render: x => formatDate(x, 'YYYY/MM/DD HH:mm'),
    },
    {
      title: '状态',
      width: 150,
      dataIndex: 'status',
      render: text => {
        let statusColor = ''
        let statusText = ''
        switch (text) {
          case 1:
            statusColor = '#959BA3'
            statusText = '待签收'
            break
          case 2:
            statusColor = '#F4A022'
            statusText = '已签收'
            break
          default:
            break
        }
        return <Badge color={statusColor} text={statusText} />
      },
    },
  ]

  const handleTabChange = key => {
    ref.current.onReset()
    setParams({ ...params, screen: { ...params.screen, tab: key } })
  }

  const renderHeader = () => {
    return (
      <div className={styles['tab-header']}>
        <Tabs
          className={styles['check-tab']}
          animated={false}
          activeKey={params.screen.tab}
          onChange={handleTabChange}
        >
          <TabPane key="1" tab="待登记" />
          <TabPane key="2" tab="已登记" />
        </Tabs>
      </div>
    )
  }

  useEffect(() => {
    getData()
  }, [params])
  return (
    <div className={styles['my-warp']}>
      <PageHeader>{renderHeader()}</PageHeader>
      <PageContent>
        <HeaderSearch onSearchChange={handleSearchChange} ref={ref} />
        <Table
          loading={loading}
          columns={params.screen.tab === '2' ? registeredColumns : registerColumns}
          dataSource={list}
          rowKey={x => x.id}
          fixed
          scroll={{
            x: 1300,
            scrollToFirstRowOnChange: true,
          }}
          pagination={
            !allCount
              ? false
              : {
                  total: allCount,
                  current: params.pageId,
                  pageSize: params.pageCount,
                  onChange: pageChange,
                  showSizeChanger: true,
                  showQuickJumper: true,
                  onShowSizeChange,
                  showTotal: total =>
                    `共${total}条记录  第${params.pageId}/${Math.ceil(total / params.pageCount)}页`,
                }
          }
          onRow={record => {
            return {
              onClick: () => {
                clickJump(record)
              },
            }
          }}
        />
      </PageContent>
      {/* {isShowModal && <BackModal itemScreen={itemScreen}  handleBack = {handleBack}/>} */}
    </div>
  )
}

export default connect(state => ({
  uid: state.globalInfo.baseInfo.uid,
}))(List)
