import React, { useReducer, useImperativeHandle, forwardRef } from 'react'
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import { Form, Button } from 'antd'
import SearchTerm from 'ROOT/components/SearchTerm'
import { formatDate } from 'ROOT/utils'

import styles from './index.scss'

const initialState = {
  docTitle: '',
  docTimer: [],
}
const createAction = (type, payload) => {
  return {
    type,
    payload,
  }
}
const reducer = function reducer(state, action) {
  switch (action.type) {
    case 'docTitle':
      return { ...state, docTitle: action.payload }

    case 'docTimer':
      return { ...state, docTimer: action.payload }

    case 'reset':
      return { ...initialState }
    default:
      return state
  }
}
const HeaderSearch = (props, ref) => {
  const { onSearchChange } = props
  const [formData, dispatch] = useReducer(reducer, initialState)

  const handleFormItemValueChange = (type, value) => {
    dispatch(createAction(type, value))
  }
  useImperativeHandle(ref, () => ({
    onReset: () => dispatch(createAction('reset', '')),
  }))
  const handleReset = () => {
    dispatch(createAction('reset', ''))
    onSearchChange({
      title: '',
      beginTime: 0,
      endTime: 0,
    })
  }
  const handleSearch = () => {
    onSearchChange({
      title: formData.docTitle,
      beginTime: formData.docTimer[0]
        ? new Date(`${formatDate(formData.docTimer[0], 'YYYY-MM-DD')} 00:00:00`).getTime()
        : 0,
      endTime: formData.docTimer[1]
        ? new Date(`${formatDate(formData.docTimer[1], 'YYYY-MM-DD')} 23:59:59`).getTime()
        : 0,
    })
  }

  return (
    <div className={styles.search}>
      <Form layout="inline">
        <SearchTerm
          type="input"
          label="公文标题:"
          placeholder="请输入标题"
          value={formData.docTitle}
          onChange={value => {
            handleFormItemValueChange('docTitle', value)
          }}
        />

        <SearchTerm
          type="datePicker"
          label="来文日期:"
          placeholder={['开始时间', '结束时间']}
          value={formData.docTimer}
          onChange={value => {
            handleFormItemValueChange('docTimer', value)
          }}
        />

        <SearchTerm>
          <Button className={styles.reset} onClick={handleReset}>
            重置
          </Button>
          <Button type="primary" onClick={handleSearch}>
            查询
          </Button>
        </SearchTerm>
      </Form>
    </div>
  )
}

export default forwardRef(HeaderSearch)
