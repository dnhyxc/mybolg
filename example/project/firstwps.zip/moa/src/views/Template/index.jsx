import React, { useState, useReducer, useEffect } from 'react'
import ClassNames from 'classnames'
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import styles from './index.scss'

const Demo = props => {
  const { de } = props
  const [state1, setstate1] = useState('')
  useEffect(() => {
    return () => {}
  }, [])
  return <div className={styles['demo-warp']}>测试例子</div>
}

export default connect(
  state => ({
    orgId: state.globalInfo.baseInfo.orgId,
  }),
  dispatch => ({
    actions: bindActionCreators({}, dispatch),
  }),
)(Demo)
