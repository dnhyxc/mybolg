/*
 * @Description: 水印创建/详情页
 * @Author: dnh
 * @Date: 2022-03-21 10:12:44
 * @LastEditTime: 2022-03-28 17:26:09
 * @LastEditors: dnh
 * @FilePath: \src\views\WatermarkService\Create\index.jsx
 */
import React, { useState, useEffect } from 'react'
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import cx from 'classnames'
import moment from 'moment'
import { previewFile, globalStore } from '@xm/util'
import { getFileIcon, getFileExt, getFileSize } from '@xm/FileList/dist/util'
import PageHeader from 'ROOT/components/PageHeader'
import PageContent from 'ROOT/components/PageContent'
import { Form, Radio, Upload, Icon, Spin, Row, Col, Input, Button, message } from 'antd'
import { formatDate } from 'ROOT/utils'
import { downloadFile } from 'ROOT/wpsutils/file-operator'
import Service from 'ROOT/service'
import { UPLOAD_URL } from 'ROOT/service/api'
import styles from './index.scss'

const formItemLayout = {
  labelCol: {
    xs: { span: 8 },
    sm: { span: 2 },
  },
  wrapperCol: {
    xs: { span: 24 },
    sm: { span: 20 },
  },
}

export const UPLOAD_LIMIT_DOC_TYPE = ['docx', 'pptx', 'pdf']
// export const UPLOAD_LIMIT_DOC_TYPE = ['doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'pdf']

const otherProps = { labelCol: { span: 6 }, wrapperCol: { span: 12 } }

// const id = getSearchParam('id') || null // 需要获取模板字段的id

const Create = ({ history, orgId, name, uid, ...props }) => {
  const [customValue, setCustomValue] = useState('')
  const [uploadFile, setUploadFile] = useState('')
  const [currentDept, setCurrentDept] = useState('')
  const [fileId, setFileId] = useState('')
  const [detail, setDetail] = useState({})
  const [fileInfo, setFileInfo] = useState({})
  const [loading, setLoading] = useState(false)

  const { getFieldDecorator, validateFieldsAndScroll } = props.form
  const deptList = globalStore.get('deptList')

  const {
    match: {
      params: { id },
    },
  } = props

  useEffect(() => {
    if (id && id !== 'create') {
      getWatermarkRecord(id)
    } else {
      getDept()
    }
  }, [id])

  // 返回事件
  const goBack = () => {
    history.goBack()
  }

  const beforeUpload = file => {
    const fileType = file.name.split('.').slice(-1)[0] || ''
    if (UPLOAD_LIMIT_DOC_TYPE.indexOf(fileType) < 0) {
      message.error('仅支持docx、xlsx、pptx、 pdf')
      // message.error('仅支持word、excel、pptx、pdf')
      return false
    }
  }

  const onUploadChange = ({ file }) => {
    const fileType = file.name.split('.').slice(-1)[0] || ''
    console.log(file.name, fileType, 'fileType')
    // 选择文件上传
    if (file.status === 'done') {
      setUploadFile({
        filename: file.name,
        size: file.size,
        url: file.response.fileUrl,
        fileType,
      })
    } else if (file.status === 'error') {
      message.error(file.response.msg)
    }
  }

  // 更改自定义显示
  const onChangeCustomValue = e => {
    setCustomValue(e.target.value)
  }

  // 字段处理
  const manageData = values => {
    return {
      orgId,
      uid,
      name,
      deptId: 0,
      deptName: values.deptName,
      createTime: values.createTime,
      title: values.title,
      comment: values.comment, // 备注
      originFile: uploadFile.url || fileInfo.originUrl, // 源文件url
      fileName: uploadFile.filename || fileInfo.fileName,
      fileSize: uploadFile.size || fileInfo.fileSize,
      fileType: uploadFile.fileType || fileInfo.fileType,
      watermark: {
        openWatermark: false,
        type: values.setting, // 1:姓名和后四位  2:自定义 3: 时间+姓名+手机后四位
        customize: values.setting === 2 ? customValue : '', // 自定义内容
      },
    }
  }

  // 保存水印
  const saveWatermarkRecord = values => {
    Service.saveWatermarkRecord({
      info: {
        ...manageData(values),
      },
    }).then(res => {
      setFileId(res.id)
      message.success('水印生成成功')
      getWatermarkRecord(res.id)
    })
  }

  // 编辑水印
  const modWatermarkRecord = values => {
    Service.modWatermarkRecord({
      id: fileId || id,
      info: {
        id: fileId || id,
        ...manageData(values),
      },
    }).then(() => {
      message.success('更改成功')
      getWatermarkRecord(fileId || id)
    })
  }

  // 获取水印详情
  const getWatermarkRecord = id => {
    setLoading(true)
    Service.getWatermarkRecord({
      id,
    }).then(res => {
      setLoading(false)
      setDetail(res.info)
      setCustomValue(res.info.watermark.customize)
      setFileInfo({
        fileName: res.info.fileName,
        fileSize: res.info.fileSize,
        fileType: res.info.fileType,
        url: res.info.finalFile,
        originUrl: res.info.originFile,
      })
      setUploadFile({})
    })
  }

  // 保存
  const onSubmit = () => {
    validateFieldsAndScroll((err, values) => {
      if (!err) {
        if (fileId || (id && id !== 'create')) {
          modWatermarkRecord(values)
        } else {
          saveWatermarkRecord(values)
        }
      }
    })
  }

  // 下载
  const onDownloadFile = () => {
    if (fileInfo || uploadFile) {
      downloadFile(
        fileInfo.url || uploadFile.url,
        fileInfo.fileName || uploadFile.filename,
        // (fileInfo.fileName && `${fileInfo.fileName.split('.')[0]}${fileInfo.fileType}`) ||
        //   uploadFile.filename,
      )
    }
  }

  // 预览
  const onPreviewFile = () => {
    if ((fileInfo && fileInfo.url) || uploadFile.url) {
      previewFile({
        previewUrl: fileInfo.url || uploadFile.url,
        fileName: fileInfo.fileName || uploadFile.filename,
        // (fileInfo.fileName && `${fileInfo.fileName.split('.')[0]}${fileInfo.fileType}`) ||
        // uploadFile.filename,
      })
    }
  }

  // 删除
  const onDelete = () => {
    setUploadFile({})
    setFileInfo({})
  }

  // 获取拟稿部门及后续接口获取
  const getDept = () => {
    const deptData =
      deptList && deptList.length > 0
        ? {
            value: deptList[0].id,
            label: deptList[0].name,
          }
        : {
            value: 0,
            label: 0,
          }
    Service.getOrgDeptPath({ deptId: deptData.value }).then(res => {
      setCurrentDept(res)
    })
  }

  return (
    <Spin spinning={loading}>
      <div className={styles.container}>
        <PageHeader
          title={{
            path: '/watermark-service',
            name: '水印服务',
            type: id === 'create' ? '创建' : '详情',
          }}
          icon="totheleft_line"
          type="detail"
          iconColor="#262a30"
          onTitleClick=""
          onIconClick={goBack}
        />
        <PageContent>
          <div className={styles.title}>中国移动广西公司商密文件打印服务</div>
          <Form {...formItemLayout}>
            <Row gutter={24}>
              <Col span={8}>
                <Form.Item label="姓名" {...otherProps}>
                  {getFieldDecorator('username', {
                    rules: [
                      {
                        required: true,
                        message: '请先设置正文',
                      },
                    ],
                    initialValue: detail.name || name,
                  })(<span>&nbsp;{detail.name || name}</span>)}
                </Form.Item>
              </Col>
              <Col span={8}>
                <Form.Item label="部门" {...otherProps}>
                  {getFieldDecorator('deptName', {
                    rules: [
                      {
                        required: true,
                        message: '请先设置部门',
                      },
                    ],
                    initialValue: detail.deptName || currentDept || '-',
                  })(<span>{detail.deptName || currentDept || '-'}</span>)}
                </Form.Item>
              </Col>
              <Col span={8}>
                <Form.Item label="创建时间" {...otherProps}>
                  {getFieldDecorator('createTime', {
                    rules: [
                      {
                        required: true,
                        message: '请先设置时间',
                      },
                    ],
                    initialValue: detail.createTime || moment().valueOf(),
                  })(
                    <span>
                      {formatDate(detail.createTime, 'YYYY/MM/DD') ||
                        formatDate(moment().valueOf(), 'YYYY/MM/DD')}
                    </span>,
                  )}
                </Form.Item>
              </Col>
            </Row>
            <Form.Item label="标题">
              {getFieldDecorator('title', {
                rules: [
                  {
                    required: true,
                    message: '请先设置标题',
                  },
                ],
                initialValue: detail.title,
              })(<Input placeholder="请输入标题" />)}
            </Form.Item>
            <Form.Item label="备注">
              {getFieldDecorator('comment', {
                required: true,
                initialValue: detail.comment,
              })(<Input placeholder="请输入备注" />)}
            </Form.Item>
            <Form.Item label="水印设置">
              {getFieldDecorator('setting', {
                required: true,
                initialValue: detail && detail.watermark ? detail.watermark.type : 1,
              })(
                <Radio.Group>
                  <Radio value={1}>显示姓名+手机号后四位</Radio>
                  <Radio value={3}>显示日期+姓名+手机号后四位</Radio>
                  <Radio value={2}>
                    自定义显示 &nbsp;
                    <Input
                      placeholder="请输入"
                      value={customValue}
                      onChange={onChangeCustomValue}
                    />
                  </Radio>
                </Radio.Group>,
              )}
            </Form.Item>
            <Form.Item label="附件">
              {getFieldDecorator('enclosure', {
                required: false,
                initialValue: '',
              })(
                <Upload
                  name="logo"
                  action={UPLOAD_URL}
                  listType="picture"
                  maxFileSize={50}
                  multiple
                  showUploadList={false}
                  onChange={onUploadChange}
                  beforeUpload={beforeUpload}
                >
                  <Button>
                    <Icon type="upload" /> 上传文件
                  </Button>
                </Upload>,
              )}
              {((fileInfo && fileInfo.url) || (uploadFile && uploadFile.url)) && (
                <div className={styles.fileWrap}>
                  <div className={styles.fileInfo}>
                    <div className={styles.uploadIcon}>
                      <i
                        className={cx(
                          styles.fileicon,
                          styles.filetype,
                          styles[
                            getFileIcon(
                              getFileExt(
                                uploadFile.filename || fileInfo.fileName,
                                // (fileInfo.fileName &&
                                //   `${fileInfo.fileName.split('.')[0]}${fileInfo.fileType}`),
                              ),
                            )
                          ],
                        )}
                      />
                    </div>
                    <div className={styles.filename}>
                      <span>
                        {uploadFile.filename || fileInfo.fileName}
                        {/* (fileInfo.fileName &&
                            `${fileInfo.fileName.split('.')[0]}${fileInfo.fileType}`)} */}
                      </span>
                      <span className={styles.size}>
                        {getFileSize(uploadFile.size || fileInfo.fileSize)}
                      </span>
                    </div>
                  </div>
                  <div className={styles.actions}>
                    <span onClick={onPreviewFile}>预览</span>
                    <span className={styles.download} onClick={onDownloadFile}>
                      下载
                    </span>
                    <span className={styles.delete} onClick={onDelete}>
                      删除
                    </span>
                  </div>
                </div>
              )}
            </Form.Item>
          </Form>
        </PageContent>
        <div className={styles.footer}>
          <Button className={styles.close} onClick={goBack}>
            关闭
          </Button>
          <Button type="primary" onClick={onSubmit}>
            保存
          </Button>
        </div>
      </div>
    </Spin>
  )
}

export default connect(
  state => ({
    orgId: state.globalInfo.baseInfo.orgId,
    name: state.globalInfo.baseInfo.name,
    uid: state.globalInfo.baseInfo.uid,
  }),
  dispatch => ({
    actions: bindActionCreators({}, dispatch),
  }),
)(Form.create({})(Create))
