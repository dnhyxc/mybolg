import React from 'react'
import { Route, Switch, Redirect } from 'react-router-dom'

import List from './List'
import Create from './Create'

const WatermarkService = props => {
  const { match } = props

  return (
    <Switch>
      <Route path={match.path} exact component={List} />
      <Route path={`${match.path}/:id`} exact component={Create} />
      <Redirect to={match.path} />
    </Switch>
  )
}

export default WatermarkService
