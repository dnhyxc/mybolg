import React, { useState, useEffect } from 'react'
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import { Table, Button } from 'antd'
import { formatDate } from 'ROOT/utils'
import PageHeader from 'ROOT/components/PageHeader'
import PageContent from 'ROOT/components/PageContent'
import service from 'ROOT/service'
import HeaderSearch from '../Components/HeaderSearch'
import styles from './index.scss'

const columns = [
  {
    title: '标题',
    key: 'title',
    dataIndex: 'title',
    render: text => text || '-',
  },
  {
    title: '备注',
    key: 'comment',
    dataIndex: 'comment',
    render: text => text || '-',
  },
  {
    title: '创建时间',
    key: 'createTime',
    dataIndex: 'createTime',
    render: x => formatDate(x, 'YYYY/MM/DD HH:mm'),
  },
]
const List = props => {
  const { history, match } = props
  const [list, setList] = useState([])
  const [loading, setLoading] = useState(false)
  const [params, setParams] = useState({
    pageId: 1,
    pageCount: 10,
    screen: {
      title: '',
      beginTime: 0,
      endTime: 0,
    },
  })

  const [allCount, setallCount] = useState(0)

  const handleSearchChange = data => {
    setParams({ ...params, pageId: 1, screen: data })
  }

  const getData = () => {
    setLoading(true)
    service
      .getWatermarkRecordList({
        ...params,
      })
      .then(res => {
        const { allCount, infos } = res
        setLoading(false)
        setList(infos)
        setallCount(allCount)
      })
      .finally(() => {
        setLoading(false)
      })
  }

  const pageChange = page => {
    setParams({ ...params, pageId: page })
  }
  const onShowSizeChange = (current, pageSize) => {
    setParams({ ...params, pageCount: pageSize })
  }

  const handleAdd = () => {
    history.push(`${match.path}/create`)
  }
  const onRowClick = record => {
    history.push(`${match.path}/${record.id}`)
  }
  useEffect(() => {
    getData()
  }, [params])
  return (
    <div className={styles['my-warp']}>
      <PageHeader title="水印服务">
        <div className={styles['extra-actions']}>
          <Button type="primary" onClick={handleAdd}>
            新建
          </Button>
        </div>
      </PageHeader>
      <PageContent>
        <HeaderSearch onSearchChange={handleSearchChange} />
        <Table
          loading={loading}
          columns={columns}
          dataSource={list}
          rowKey={x => x.id}
          pagination={
            !allCount
              ? false
              : {
                  total: allCount,
                  current: params.pageId,
                  pageSize: params.pageCount,
                  onChange: pageChange,
                  showSizeChanger: true,
                  showQuickJumper: true,
                  onShowSizeChange,
                  showTotal: total =>
                    `共${total}条记录  第${params.pageId}/${Math.ceil(total / params.pageCount)}页`,
                }
          }
          onRowClick={record => onRowClick(record)}
        />
      </PageContent>
    </div>
  )
}

export default connect(
  state => ({
    orgId: state.globalInfo.baseInfo.orgId,
  }),
  dispatch => ({
    actions: bindActionCreators({}, dispatch),
  }),
)(List)
