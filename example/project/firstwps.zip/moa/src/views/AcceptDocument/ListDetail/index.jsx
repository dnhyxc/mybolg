import React from 'react'
import OfficialContent from 'ROOT/components/OfficialContent'

const ListDetail = props => {
  return <OfficialContent {...props} />
}

export default ListDetail
