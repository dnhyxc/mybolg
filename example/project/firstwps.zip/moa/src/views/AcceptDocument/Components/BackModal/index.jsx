import React, { useState } from 'react'
import { Modal, Input, message } from 'antd'
import service from 'ROOT/service'

const { TextArea } = Input
export default props => {
  const { handleBack, title = '退回意见', itemScreen } = props
  const { id, fromOrgId } = itemScreen
  const [value, setValue] = useState(undefined)
  const handleOk = () => {
    service
      .backDocumentOut({
        fromOrgId,
        id,
        opinion: value,
      })
      .then(() => {
        message.success('退回成功')
        handleBack()
      })
  }
  const handleChangeValue = e => {
    setValue(e.target.value)
  }
  return (
    <div>
      <Modal visible onOk={handleOk} onCancel={handleBack} title={title}>
        <TextArea
          maxLength={500}
          rows={4}
          onChange={handleChangeValue}
          value={value}
          placeholder="请输入意见"
        />
      </Modal>
    </div>
  )
}
