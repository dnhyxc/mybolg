import React, { useState, useEffect, useRef } from 'react'
import { Table, Tabs, Badge, message, Modal } from 'antd'
import HeaderSearch from 'ROOT/views/AcceptDocument/Components/HeaderSearch'
import PageHeader from 'ROOT/components/PageHeader'
import PageContent from 'ROOT/components/PageContent'
import TableTitle from 'ROOT/components/TableTitle'
import service from 'ROOT/service'
import { INCOMING_DOC_STATUS } from 'ROOT/constant'
import { formatDate, getSerialNumStrFromStr } from 'ROOT/utils'
import { connect } from 'react-redux'
import styles from './index.scss'

const { TabPane } = Tabs
const List = props => {
  const ref = useRef()
  const { history, uid } = props
  const [list, setList] = useState([])
  const [loading, setLoading] = useState(false)
  const [allCount, setallCount] = useState(0)
  const [areaOrgs, setAreaOrgs] = useState([])
  const [cityOrgIds, setCityOrgIds] = useState([])
  const [params, setParams] = useState({
    pageId: 1,
    pageCount: 10,
    screen: {
      beginTime: 0,
      endTime: 0,
      tab: '1',
      title: '',
    },
  })
  const handleSearchChange = data => {
    setParams({ ...params, pageId: 1, screen: { ...params.screen, ...data } })
  }

  const getData = () => {
    setLoading(true)
    service
      .getDocumentOutToList({
        ...params,
      })
      .then(res => {
        const { allCount, infos } = res
        setLoading(false)
        setList(infos)
        setallCount(allCount)
      })
      .finally(() => {
        setLoading(false)
      })
  }

  const onShowSizeChange = (current, pageSize) => {
    setParams({ ...params, pageCount: pageSize })
  }
  const pageChange = page => {
    setParams({ ...params, pageId: page })
  }

  const jumpCreate = (item, id, fromOrgId, record) => {
    service.getAppDetailList({ uid }).then(res => {
      let data = null
      // 递归查找流程定义key
      const getModelKey = details => {
        details.forEach(detail => {
          if (detail.children.length > 0) {
            getModelKey(detail.children)
          }
          if (detail.extra) {
            const extra = JSON.parse(detail.extra)
            if (extra.procFormKey === item.formModelKey) {
              data = detail
            }
          }
        })
      }

      if (res.details.length > 0) {
        const { details } = res
        getModelKey(details)
        if (data) {
          history.push(
            `create-document?id=${item.id}&fromOrgId=${fromOrgId}&checkId=${id}&isRegister=${
              handleCanBack(record) && params.screen.tab === '1' ? '1' : '2'
            }&proKey=${data.detailKey}`,
          )
          // history.push(`/create-document?id=${item.id}&proKey=${data.detailKey}`)
        } else {
          message.info('没有找到模版对应的流程')
        }
      }
    })
  }

  const clickJump = record => {
    const { id, fromOrgId, backTime } = record
    if (!backTime) {
      service.getTemplateList({ uid }).then(res => {
        const { docTemplates } = res
        const docTemplate = docTemplates.filter(x => x.type === 2)
        if (docTemplate.length === 0) {
          return message.error('请配置收文模板')
        }
        jumpCreate(docTemplate[0], id, fromOrgId, record)
        // history.push(
        //   `create-document?id=${
        //     docTemplate[0].id
        //   }&fromOrgId=${fromOrgId}&checkId=${id}&isRegister=${params.screen.tab === '1'}`,
        // )
      })
    }
  }

  // const handleSign = (e, { fromOrgId, id: checkId }) => {
  //   e.stopPropagation()
  //   const { history, uid } = props
  //   service.getTemplateList({ uid }).then(res => {
  //     const { docTemplates } = res
  //     const docTemplate = docTemplates.filter(x => x.type === 2)
  //     if (docTemplate.length === 0) {
  //       return message.error('请配置收文模板')
  //     }
  //     service
  //       .signDocumentOut({
  //         fromOrgId,
  //         id: checkId,
  //         opinion: '',
  //       })
  //       .then(() => {
  //         history.push(
  //           `create-document?id=${docTemplate[0].id}&fromOrgId=${fromOrgId}&checkId=${checkId}`,
  //         )
  //       })
  //   })
  // }
  const handleBack = (e, { fromOrgId, id }) => {
    e.stopPropagation()
    Modal.confirm({
      title: '确定退回？',
      onOk: () => {
        service
          .backDocumentOut({
            fromOrgId,
            id,
            opinion: '',
          })
          .then(() => {
            message.success('退回成功')
            getData()
          })
      },
    })
  }
  const registerColumns = [
    {
      title: '公文标题',
      fixed: 'left',
      width: 300,
      key: 'title',
      dataIndex: 'title',
      render: text => <TableTitle title={{ value: text }} />,
    },
    {
      title: '发文文号',
      key: 'refNo',
      dataIndex: 'refNo',
      render: text => (text && getSerialNumStrFromStr(text)) || '-',
    },
    {
      title: '发送单位',
      key: 'fromOrgName',
      dataIndex: 'fromOrgName',
      width: 150,
      render: text => text || '-',
    },
    {
      title: '发送人',
      width: 160,
      key: 'sendName',
      dataIndex: 'sendName',
      render: text => text || '-',
    },
    {
      title: '发送时间',
      width: 200,
      key: 'sendTime',
      dataIndex: 'sendTime',
      render: x => formatDate(x, 'YYYY/MM/DD HH:mm'),
    },
    {
      title: '签收状态',
      width: 160,
      render: item => {
        let statusColor = ''
        let statusText = ''
        if (item.status === INCOMING_DOC_STATUS.TODO) {
          if (item.backTime) {
            statusColor = '#959BA3'
            statusText = '已退回'
          } else {
            statusColor = '#F4A022'
            statusText = '待登记'
          }
        } else {
          statusText = '已撤销'
        }
        return <Badge color={statusColor} text={statusText} />
      },
    },
    {
      title: '操作',
      width: 200,
      render: item => (
        <span>
          {handleCanBack(item) ? (
            <span>
              <span>
                <a className={styles.red} onClick={e => handleBack(e, item)}>
                  退回
                </a>
              </span>
            </span>
          ) : (
            '-'
          )}
        </span>
      ),
    },
  ]
  const handleCanBack = item => {
    let isCanBack = false
    const isArea = areaOrgs.some(x => x.id === item.toOrgId) // 当前是否是区公司
    const isCity = cityOrgIds.some(x => x === item.fromOrgId) // 来文单位是否是市公司
    if (isArea && !item.backTime) {
      isCanBack = true
    }
    if (!isArea && !item.backTime && isCity) {
      isCanBack = true
    }
    return isCanBack
  }
  const registeredColumns = [
    {
      title: '公文标题',
      fixed: 'left',
      width: 300,
      key: 'title',
      dataIndex: 'title',
      render: text => <TableTitle title={{ value: text }} />,
    },
    {
      title: '发文文号',
      key: 'refNo',
      dataIndex: 'refNo',
      render: text => (text && getSerialNumStrFromStr(text)) || '-',
    },
    {
      title: '发送单位',
      key: 'fromOrgName',
      dataIndex: 'fromOrgName',
      width: 150,
      render: text => text || '-',
    },
    {
      title: '发送人',
      width: 160,
      key: 'sendName',
      dataIndex: 'sendName',
      render: text => text || '-',
    },
    {
      title: '发送时间',
      width: 200,
      key: 'sendTime',
      dataIndex: 'sendTime',
      render: x => formatDate(x, 'YYYY/MM/DD HH:mm'),
    },
    {
      title: '签收人',
      width: 160,
      key: 'signName',
      dataIndex: 'signName',
      render: text => text || '-',
    },
    {
      title: '签收时间',
      width: 200,
      key: 'signTime',
      dataIndex: 'signTime',
      render: x => formatDate(x, 'YYYY/MM/DD HH:mm'),
    },
    {
      title: '状态',
      width: 160,
      render: item => {
        let statusColor = ''
        let statusText = ''
        if (item.backTime) {
          statusColor = '#959BA3'
          statusText = '已退回'
        } else {
          statusColor = '#F4A022'
          statusText = '已签收'
        }
        return <Badge color={statusColor} text={statusText} />
      },
    },
  ]
  const handleTabChange = key => {
    ref.current.onReset()
    setParams({ ...params, screen: { ...params.screen, tab: key } })
  }

  const renderHeader = () => {
    return (
      <div className={styles['tab-header']}>
        <Tabs
          className={styles['check-tab']}
          animated={false}
          activeKey={params.screen.tab}
          onChange={handleTabChange}
        >
          <TabPane key="1" tab="待登记" />
          <TabPane key="2" tab="已登记" />
        </Tabs>
      </div>
    )
  }
  useEffect(() => {
    service.getOrgGroup({}).then(res => {
      setAreaOrgs(res.areaOrgIds)
      setCityOrgIds(res.cityOrgIds)
    })
  }, [])
  useEffect(() => {
    getData()
  }, [params])
  return (
    <div className={styles['my-warp']}>
      <PageHeader>{renderHeader()}</PageHeader>
      <PageContent>
        <HeaderSearch onSearchChange={handleSearchChange} ref={ref} />
        <Table
          loading={loading}
          columns={params.screen.tab === '2' ? registeredColumns : registerColumns}
          dataSource={list}
          rowKey={x => x.id}
          fixed
          scroll={{
            x: 1500,
            scrollToFirstRowOnChange: true,
          }}
          pagination={
            !allCount
              ? false
              : {
                  total: allCount,
                  current: params.pageId,
                  pageSize: params.pageCount,
                  onChange: pageChange,
                  showSizeChanger: true,
                  showQuickJumper: true,
                  onShowSizeChange,
                  showTotal: total =>
                    `共${total}条记录  第${params.pageId}/${Math.ceil(total / params.pageCount)}页`,
                }
          }
          onRow={record => {
            return {
              onClick: () => {
                clickJump(record)
              },
            }
          }}
        />
      </PageContent>
    </div>
  )
}

export default connect(state => ({
  uid: state.globalInfo.baseInfo.uid,
}))(List)
