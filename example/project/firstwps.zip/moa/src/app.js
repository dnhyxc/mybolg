/*
 * @Description: 
 * @Author: dnh
 * @Date: 2022-03-09 13:09:43
 * @LastEditTime: 2022-03-09 18:13:35
 * @LastEditors: dnh
 * @FilePath: \src\app.js
 */
import { ConfigProvider, message, Empty } from 'antd'
import React from 'react'
import { Provider } from 'react-redux'
import { HashRouter } from 'react-router-dom'

import { zhCN, RootPath } from '@xm/util'

import store from 'ROOT/store'
import Routes from 'ROOT/router'
import NoData from 'ROOT/assets/images/empty.png'
import 'ROOT/assets/styles/common.scss'

const { Context } = RootPath

// 控制同时弹出的消息数，避免在页面调用多个接口异常时，出现多个 toast 提示问题
message.config({
  maxCount: 1,
})

export default ({ appName = '' }) => (
  <ConfigProvider
    locale={zhCN || {}}
    renderEmpty={() => <Empty description="暂无相关数据" image={NoData} />}
  >
    <Provider store={store}>
      <Context.Provider value={appName}>
        <HashRouter basename={appName}>
          <Routes rootPath={appName} />
        </HashRouter>
      </Context.Provider>
    </Provider>
  </ConfigProvider>
)
