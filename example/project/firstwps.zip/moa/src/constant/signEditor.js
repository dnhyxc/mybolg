export const SIGN_TYPE = {
  TEXT: 0, // 文字框
  INPUT: 1, // 输入框
  TIME: 2, // 时间框
  REFNO: 3, // 文号框
  SELECT: 4, // 下拉框
  MULTI: 5, // 多人输入框
  CHECKBOX: 6, // 勾选框
}

export const SIGN_TYPE_LIST = {
  [SIGN_TYPE.TEXT]: {},
  [SIGN_TYPE.INPUT]: {
    canAssField: true,
  },
  [SIGN_TYPE.TIME]: {
    canAssField: true,
  },
  [SIGN_TYPE.REFNO]: {
    canAssField: true,
  },
  [SIGN_TYPE.SELECT]: {
    canAssField: true,
  },
  [SIGN_TYPE.MULTI]: {
    canAssOpinion: true,
  },
  [SIGN_TYPE.CHECKBOX]: {},
}

export const FIELD_TYPE = {
  INPUT: 'input',
  SELECT: 'select',
  DROPDOWN: 'dropDown',
  TIME: 'time',
  REFNO: 'refno',
  SIGN: 'sign',
  FILENO: 'fileNo',
  USERDEPT: 'userOrdept',
}
