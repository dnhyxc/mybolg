import TYPE_FAWEN from 'ROOT/assets/images/type-fawen.png'
import TYPE_SHOUWEN from 'ROOT/assets/images/type-shouwen.png'
import TYPE_QIAN from 'ROOT/assets/images/type-qian.png'
import TYPE_XIE from 'ROOT/assets/images/type-xie.png'
import BODY_FILE from 'ROOT/assets/images/bodyfile.png'
import SIGN_FILE from 'ROOT/assets/images/signfile.png'

export { ADMIN_NONE, UPLOAD_URL, EVENTS } from './original-webim'

export const FIELD_TYPE = {
  /**
   * 标题
   */
  TITLE: 'title',

  /**
   * 文号
   */
  REF_NO: 'refNo',

  /**
   * 外部来文文号
   */
  OUTSIDE_REF_NO: 'outsideRefNo',

  /**
   * 签批单
   */
  SIGN_FILE: 'signFile',

  /**
   * 正文
   */
  BODY_FILE: 'bodyFile',

  THEME_WORD: 'themeWord',

  /**
   * 公文类型
   */
  OFFICIAL_TYPE: 'officialType',

  /**
   * 紧急程度
   */
  URGENCY_LEVEL: 'urgencyLevel',

  /**
   * 密级
   */
  SECRET_CLASS: 'secretClass',
  /**
   * 保密期限
   */
  SECRECY_TERM: 'secrecyTerm',

  /**
   * 发送日期
   */
  DISPATCH_DATE: 'dispatchDate',

  /**
   * 接收日期
   */
  RECEIPT_DATE: 'receiptDate',

  /**
   * 接收单位
   */
  DISPATCH_COMPANY: 'dispatchCompany',

  /**
   * 收文单位
   */
  RECEIPT_COMPANY: 'receiptCompany',

  /**
   * 主送
   */
  MAIN_SEND: 'mainSend',

  /**
   * 抄送
   */
  COPY_SEND: 'copySend',

  ISS_UER: 'issUer',
  PROOFREADER: 'proofreader',
  PRINTER: 'printer',
  IMPRESSION: 'impression',

  /**
   * 附件
   */
  ENCLOSURE: 'enclosure',

  /**
   * 收文文号
   */
  RECEIPT_REF_NO: 'receiptRefNo',

  /**
   * 行文类型
   */
  WRITING: 'writing',

  /**
   * 是否用章
   */
  USESEAL: 'useSeal',

  /**
   * 拟稿部门
   */
  FILE_DEPARTMENT: 'fileDepartment',

  /**
   * 起草人
   */
  CREAT_PERSON: 'creatPerson',

  /**
   * 创建时间/拟稿时间
   */
  CREAT_TIME: 'creatTime',

  /**
   * 参考信息
   */
  REFERENCE: 'reference',
}

// 操作类型,主要用于操作记录，和传递给后端区分不同的正文操作
export const OPER_TYPE = {
  SIGN: 1,
  BACK: 22,
  RECALL: 3,
  CREATE: 4,
  SEAL: 5,
  SUBMIT: 6,
  TURN_TO: 7,
  APPROVE: 9,
  PASS: 10,
  DELETE: 11,
  MODIFY_FILE: 12,
  RENAME_FILE: 13,
  TAOHONG: 14,
  PASS_READ: 15,
  RE_CREATE: 16,
  WITH_DRAW: 17,
  UPLOAD: 18,
  URGE: 19,

  /**
   * 填写处理意见
   */
  PROCESS_OPONION: 61,
}

export const STEP_TYPE = {
  DEFAULT: 1, // 默认
  SEQUENCE: 2, // 顺序
  TOGETHER: 3, // 会签
  ORSIGN: 4, // 或签
}

// 公文类型
export const OFFICIAL_TYPE = {
  SEND: 1, // 发文
  RECEIVE: 2, // 收文
  CHENGYUE: 3, // 协调函
  CHENGPI: 4, // 签报
}

// 模板类型
export const UPLOAD_FILE_TYPE = {
  BODY_FILE: 1,
  TAOHONG: 2,
}

// 公文类型str
export const OFFICIAL_TYPE_TEXT = {
  [OFFICIAL_TYPE.SEND]: '发文',
  [OFFICIAL_TYPE.RECEIVE]: '收文',
  [OFFICIAL_TYPE.CHENGYUE]: '协调函',
  [OFFICIAL_TYPE.CHENGPI]: '签报',
}
// 公文列表搜索数据
export const OFFICIAL_TYPE_SEARCH = [
  {
    value: 1,
    label: '发文',
  },
  {
    value: 2,
    label: '收文',
  },
  {
    value: 3,
    label: '协调函',
  },
  {
    value: 4,
    label: '签报',
  },
]

export const OFFICIAL_STATE_SEARCH = [
  // 流程实例标记 0, 运行中 1, 正常通过 2, 已拒绝  4,终止  8,c status
  {
    value: JSON.stringify([0]),
    label: '运行中',
  },
  {
    value: JSON.stringify([1]),
    label: '正常通过',
  },
  {
    value: JSON.stringify([2]),
    label: '已拒绝',
  },
  {
    value: JSON.stringify([4]),
    label: '终止',
  },
  {
    value: JSON.stringify([8]),
    label: '已撤销',
  },
]

// /流程实例标记 0, 运行中 1, 正常通过 2, 已拒绝 4,终止 8,已撤销
// 公文状态
export const DOC_STATUS = {
  HAVEINHAND: 0,
  NORMALPASS: 1,
  REJECTED: 2,
  TERMINATION: 4,
  RESCINDED: 8,
}

// 公文状态str
export const DOC_STATUS_TXT = {
  [DOC_STATUS.HAVEINHAND]: '进行中',
  [DOC_STATUS.NORMALPASS]: '正常通过',
  [DOC_STATUS.REJECTED]: '已拒绝',
  [DOC_STATUS.TERMINATION]: '终止',
  [DOC_STATUS.RESCINDED]: '已撤销',
}
// 公文状态Color
export const DOC_STATUS_COLOR = {
  [DOC_STATUS.HAVEINHAND]: '#F4A022',
  [DOC_STATUS.NORMALPASS]: '#23C172',
  [DOC_STATUS.REJECTED]: '#FA5F5F',
  [DOC_STATUS.TERMINATION]: '#FA5F5F',
  [DOC_STATUS.RESCINDED]: '#CBCFD6',
}

// 后台公文查询 管理权限
export const DOC_SEARCH_OPER = {
  PASS: 1,
  ARCHIVE: 2,
  DELETE: 3,
  RECYCLE: 4,
  URGE: 5,
  FLOW_CHANGE: 6,
}

/**
 * 类型图片列表
 */
export const TYPE_IMGS = {
  [OFFICIAL_TYPE.SEND]: TYPE_FAWEN,
  [OFFICIAL_TYPE.RECEIVE]: TYPE_SHOUWEN,
  [OFFICIAL_TYPE.CHENGYUE]: TYPE_QIAN,
  [OFFICIAL_TYPE.CHENGPI]: TYPE_XIE,
}

export const FILE_TYPES = {
  [FIELD_TYPE.BODY_FILE]: BODY_FILE,
  [FIELD_TYPE.SIGN_FILE]: SIGN_FILE,
}
// 签收状态
export const INCOMING_DOC_STATUS = {
  TODO: 1,
  TRANSACTED: 2,
}

export const PDFGENERATOR_URL = '/pdfgenerator/down'

export const UPLOAD_LIMIT_IMG_TYPE = ['png', 'jpg', 'jpeg']
export const UPLOAD_LIMIT_DOC_TYPE = ['doc', 'docx', 'doct', 'docm']
export const UPLOAD_LIMIT_PDF_TYPE = ['pdf']
export const UPLOAD_LIMIT_TYPE = [
  ...UPLOAD_LIMIT_IMG_TYPE,
  ...UPLOAD_LIMIT_DOC_TYPE,
  ...UPLOAD_LIMIT_PDF_TYPE,
]
export const BODY_FILE_ACCEPT_LIST = ['.doc', '.docx', '.doct', '.docm']

// 正文操作配置
export const BODY_FILE_OPERATION = {
  PREVIEW: 'preview',
  DOWNLOAD: 'download',
  TAO_HONG: 'tahong',
  EDIT: 'edit',
  RENAME: 'rename',
  DELETE: 'delete',
  STAMP: 'stamp',
  PERMISSION: 'permission',
}

// 详情页所有的功能操作权限，因为部分操作权限在管理后台流程中未定义,管理后台有的部分与管理后台保持统一
export const ALL_OPERATIONS = {
  BODY_FILE_EDIT: 1,
  SIGN: 2,
  STAMP: 3,
  FINALIZE: 4,
  UPLOAD_DELETE: 5,
  TAOHONG: 6,
  SIGN_FILE_EDIT: 7,
  SUPERVISION: 12, // 设置督办
  BTN_SUPERVISION: 12, // 督办
  BTN_PASS: 13,
  BTN_TURN_TO: 14,
  BTN_SEND_APPROVE: 15,
  BTN_ADD_USER: 16,
  BTN_OPERATOR_WITHDRAW: 17,
  BTN_FENSONG: 19,
  BTN_CREATE: 21,
  BTN_DELETE: 22,
  BTN_WITHDRAW: 23,
  BTN_SUBMIT: 25,
  BTN_BACK: 20,
  BTN_CANCEL: 27,
  ARCHIVE: 28,
  BTN_URGE: 29,
  HAS_OPER_RECORDS: 30,
  HAS_STEPS: 32,
  HAS_CHOOSE_USER_LIST: 34,
  HAS_FLOW: 35,
  HAS_FOOTER_BTNS: 36,
  HAS_PASS_USERS: 37,
  BTN_ARCHIVE: 40,
  BTN_READ_PASS_DOCUMENT: 41,
  CAN_EDIT_FIELD: 42,
  BTN_SUBMIT_ONLY: 43,
  BTN_DOWNLOAD_OFFICIAL: 44,
  BTN_RE_CREATE: 45,
  BTN_RE_CREATE_SUBMIT: 46,
  BTN_SAVE_DRAFT: 47,
  BTN_DEL_DRAFT: 48,
  BTN_CANCEL_WITHDRAW: 49,

  /**
   * 打包下载
   */
  BTN_PACK_DOWNLOAD: 50,

  /**
   * 打包下载记录
   */
  BTN_PACK_DOWNLOAD_HISTORY: 51,

  /**
   * 反馈按钮
   */
  BTN_FEEDBACK: 52,

  /**
   * 录入差错公文
   */
  BTN_DIFF_INPUT: 53,

  /**
   * 分发
   */
  BTN_DISTRIBUTE: 54,

  /**
   * 一键分发
   */
  BTN_TAP_TO_DISTRIBUTE: 55,

  /**
   * 收办
   */
  BTN_CHARGE_FOR: 56,

  /**
   * 收阅
   */
  BTN_ATTENTION: 57,

  /**
   * 集团发文
   */
  BTN_ORG_SEND_FILE: 58,

  /**
   * 分发记录 TAB
   */
  HAS_DISTRIBUTE_TAB: 59,

  /**
   * 收藏
   */
  BTN_COLLECTION: 60,

  /**
   * 填写处理意见
   */
  BTN_PROCESS_OPONION: 61,

  /**
   * 一键下载
   */
  ONE_CLICK_DOWNLOAD: 62,

  /**
   * 填写处理意见-收文
   */
  BTN_PROCESS_OPONION_RECEIVE: 63,

  /**
   * 收文结束后提交
   */
  BTN_RECEIVE_SUBMIT: 64,

  /**
   * 流程中保存
   */
  BTN_IN_SAVE: 65,
}

export const OFFICIAL_TYPE_SEARCH_CASCADER = [
  {
    value: 0,
    label: '全部',
  },
  {
    value: 1,
    label: '发文',
    children: [
      {
        value: 101,
        label: '公司发文',
      },
      {
        value: 102,
        label: '公司函',
      },
      {
        value: 103,
        label: '党委发文',
      },
      {
        value: 104,
        label: '党委办公室发文',
      },
      {
        value: 105,
        label: '扶贫办公室发文',
      },
      {
        value: 106,
        label: '纪委发文',
      },
      {
        value: 107,
        label: '工会发文',
      },
      {
        value: 108,
        label: '工会联合发文',
      },
      {
        value: 109,
        label: '人事任免发文',
      },
      {
        value: 110,
        label: '人事任免党委发文',
      },
      {
        value: 111,
        label: 'TD公司发文',
      },
      {
        value: 112,
        label: '服务公司发文',
      },
      {
        value: 113,
        label: '团委发文',
      },
      {
        value: 114,
        label: '情况通报',
      },
      {
        value: 115,
        label: '会议纪要',
      },
      {
        value: 116,
        label: '党委会议纪要',
      },
      {
        value: 117,
        label: '部门业务通报',
      },
      {
        value: 118,
        label: '部门会议纪要',
      },
      {
        value: 119,
        label: '情况汇报',
      },
      {
        value: 120,
        label: '纪委会议纪要',
      },
    ],
  },
  {
    value: 2,
    label: '收文',
    children: [
      {
        value: 21,
        label: '公司收文',
      },
      {
        value: 22,
        label: '团委收文',
      },
    ],
  },
  // {
  //   value: 3,
  //   label: "协调函",
  //   children: [
  //     {
  //       value: 31,
  //       label: "协调函",
  //     },
  //   ],
  // },
  {
    value: 4,
    label: '签报',
    children: [
      {
        value: 41,
        label: '签报',
      },
    ],
  },
]
