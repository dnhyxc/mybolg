import React, { forwardRef } from 'react'
import styles from './index.scss'

const PageContent = forwardRef((props, ref) => {
  const { children } = props

  return (
    <div className={styles['content-card']} ref={ref}>
      {children}
    </div>
  )
})

export default PageContent
