export const getTypeData = (type, data = [], key) => {
  if (type) {
    return data.filter(item => item[key] === type)
  }
  return data
}