import React, { useState, useEffect } from 'react'
import { Modal, Spin } from 'antd'
import service from 'ROOT/service'
import { globalStore } from '@xm/util'
import { OFFICIAL_TYPE_SEARCH } from 'ROOT/constant'
import DraftItem from './components/DraftItem'
import { getTypeData } from './const'

import styles from './index.scss'

function DraftModal(props) {
  // const { visible } = props

  const [isShow, setIsShow] = useState(true)
  const [loading, setLoading] = useState(false)
  const [data, setData] = useState([])
  const [commonData, setCommonData] = useState([])

  const orgId = globalStore.get('orgId')
  const uid = globalStore.get('uid')

  const getData = () => {
    setLoading(true)
    service.getTemplateList({
      orgId,
      uid,
    }).then(res => {
      setLoading(false)
      setCommonData(res.commonTemplates)
      setData(res.docTemplates)
    })
  }

  useEffect(() => {
    getData()
  }, [])

  return (
    <Modal
      visible={isShow}
      className="draftModal"
      title="发起公文"
      onCancel={() => setIsShow(false)}
      onOk={() => setIsShow(false)}
      width={800}
      maskStyle={{backgroundColor:'rgba(0, 0, 0, 0.4)'}}
    >
      {/* <Spin tip="加载中..." spinning={loading}> */}
        <div>
          {commonData.length > 0 && (
            <DraftItem title="常用" data={commonData} isCommons getData={getData} />
          )}
          {OFFICIAL_TYPE_SEARCH.map(
            item =>
              getTypeData(item.value, data, 'type').length > 0 && (
                <DraftItem
                  key={item.value}
                  type={item.value}
                  title={item.label}
                  data={getTypeData(item.value, data, 'type')}
                  getData={getData}
                />
              ),
          )}
        </div>
      {/* </Spin> */}
    </Modal>
  )
}

export default DraftModal
