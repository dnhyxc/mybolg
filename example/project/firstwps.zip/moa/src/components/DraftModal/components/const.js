import { typeFawen, typeShouwen, typeQian, typeXie } from 'ROOT/assets/images'

export const typeMap = {
  1: {
    img: typeFawen,
    name: '发文',
    color: '#FA5F5F',
  },
  2: {
    img: typeShouwen,
    name: '收文',
    color: '#F4A022',
  },
  3: {
    img: typeXie,
    name: '协调函',
    color: '#00C758',
  },
  4: {
    img: typeQian,
    name: '签报',
    color: '#3586FF',
  },
}

export const OFFICIAL_TYPE = {
  101: {
    value: 101,
    label: '公司发文',
  },
  102:{
    value: 102,
    label: '公司函',
  },
  103:{
    value: 103,
    label: '党委发文',
  },
  104:{
    value: 104,
    label: '党委办公室发文',
  },
  105:{
    value: 105,
    label: '扶贫办公室发文',
  },
  106:{
    value: 106,
    label: '纪委发文',
  },
  107:{
    value: 107,
    label: '工会发文',
  },
  108:{
    value: 108,
    label: '工会联合发文',
  },
  109:{
    value: 109,
    label: '人事任免发文',
  },
  110:{
    value: 110,
    label: '人事任免党委发文',
  },
  111:{
    value: 111,
    label: 'TD公司发文',
  },
  112:{
    value: 112,
    label: '服务公司发文',
  },
  113:{
    value: 113,
    label: '团委发文',
  },
  114:{
    value: 114,
    label: '情况通报',
  },
  115:{
    value: 115,
    label: '会议纪要',
  },
  116:{
    value: 116,
    label: '党委会议纪要',
  },
  117:{
    value: 117,
    label: '部门业务通报',
  },
  118:{
    value: 118,
    label: '部门会议纪要',
  },
  21:{
    value: 21,
    label: '公司收文',
  },
  22:{
    value: 22,
    label: '团委收文',
  },
  31:{
    value: 31,
    label: '协调函',
  },
  41:{
    value: 41,
    label: '签报',
  },
}
