import React from 'react'
import { collect as collectImg, noCollect } from 'ROOT/assets/images'
import { globalStore } from '@xm/util'
import service from 'ROOT/service'
import { typeMap } from '../const'
import styles from './index.scss'

function DraftItemCard(props) {
  const { data: { id, name, type, isCommon }, getData, isCommons = false } = props
  const uid = globalStore.get('uid')
  const collect = (id) => {
    const request = (isCommon || isCommons) ? 'cancelCommonFlow' : 'addCommonFlow'
    // 收藏/取消收藏
    service[request]({
      id,
      uid,
    }).then(res => {
      getData(true)
    })


  }

  return (
    <div className={styles.draftItemCard}>
      <img className={styles.docImg} width={44} src={typeMap[type].img} alt="" />
      <div className={styles.title}>
        {name}
      </div>
      <img 
        className={styles.star} 
        onClick={(e) =>{
          e.stopPropagation()
          e.nativeEvent.stopImmediatePropagation()
          collect(id)
        }}
        title={isCommon || isCommons ? '取消常用' : '设为常用'}
        width={18} 
        src={isCommon || isCommons ? collectImg : noCollect} 
        alt="" 
      />
    </div>
  )
}

export default DraftItemCard