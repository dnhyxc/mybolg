import React, { useEffect, useState } from 'react'
import { Tag, message } from 'antd'
import { down } from 'ROOT/assets/images'
import { RootPath, globalStore } from '@xm/util'
import service from 'ROOT/service'
import { withRouter } from 'react-router-dom'
import _ from 'lodash'
import { OFFICIAL_TYPE_SEARCH_CASCADER } from 'ROOT/constant'
import DraftItemCard from '../DraftItemCard'
import { getTypeData } from '../../const'
import { typeMap } from '../const'

import styles from './index.scss'

const { Context, Consumer } = RootPath
const { CheckableTag } = Tag
function DraftItem(props) {
  const { title, type, data = [], getData, getPath, history, isCommons } = props
  const [checked, setChecked] = useState(0) // 选择的tag
  const [showMore, setShowMore] = useState(false) // 是否展示全部
  const [currNum, setCurrNum] = useState(12) // 当前展示模板数
  const [tagMap, setTagMap] = useState([]) // tag列表

  const uid = globalStore.get('uid')

  useEffect(() => {
    const newList = OFFICIAL_TYPE_SEARCH_CASCADER.find(item => item.value === type)
    if (!newList) {
      return
    }
    const child = {}
    newList.children.forEach(item => {
      child[item.value] = {
        value: item.value,
        label: item.label,
      }
    })
    const newData = data.filter(item => item.childType && child[item.childType]).map(item => ({
      id: item.childType,
      text: item.childType ? (child[item.childType] || { label: '其他' }).label : '全部', // childType没有时的容错
    }))
    const dataX = _.uniqBy(newData, 'id')
    dataX.sort((a, b) => {
      return a.id - b.id
    })
    setTagMap([
      {
        id: '',
        text: '全部',
      },
      ...dataX,
    ])
    // if (dataX.length > 0) {
    setChecked('')
    // }
  }, [data])

  useEffect(() => {
    // getData()
  }, [checked])

  const handleTagChange = newTag => {
    setChecked(newTag)
  }

  const jumpCreate = item => {
    service.getAppDetailList({ uid }).then(res => {
      let data = null
      // 递归查找流程定义key
      const getModelKey = details => {
        details.forEach(detail => {
          if (detail.children.length > 0) {
            getModelKey(detail.children)
          }
          if (detail.extra) {
            const extra = JSON.parse(detail.extra)
            if (extra.procFormKey === item.formModelKey) {
              data = detail
            }
          }
        })
      }

      if (res.details.length > 0) {
        const { details } = res
        getModelKey(details)
        if (data) {
          history.push(`/create-document?id=${item.id}&proKey=${data.detailKey}`)
        } else {
          message.info('没有找到模版对应的流程')
        }
      }
    })
  }

  return (
    <div className={styles.draftItem}>
      <div className={styles.title}>
        <div
          className={styles.title_left}
          style={{ borderLeft: `4px solid ${typeMap[type] ? typeMap[type].color : '#F4A022'}` }}
        >
          {' '}
        </div>
        <span className={styles.title_right}>{title}</span>
      </div>
      {!isCommons && (
        <div className={styles.tag} style={{ height: showMore ? '' : '30px' }}>
          <div className={styles.tag_left}>
            {(tagMap || []).map((item, index) => (
              <CheckableTag
                className={`${styles.tag_item} ${
                  checked === item.id ? styles.tag_item_checked : ''
                }`}
                key={index}
                checked={checked === item.id}
                onChange={() => handleTagChange(item.id)}
              >
                {item.text}
              </CheckableTag>
            ))}
          </div>
          <div
            className={styles.more}
            style={{ display: showMore ? 'none' : 'block' }}
            onClick={() => {
              setShowMore(true)
            }}
          >
            {tagMap.length > 5 && (
              <span>
                <img width={16} alt="" src={down} />
                &nbsp;展开
              </span>
            )}
          </div>
        </div>
      )}

      <div className={styles.inner}>
        {(isCommons ? data : getTypeData(checked, data, 'childType'))
          .slice(0, currNum)
          .map((item, index) => (
            <div
              className={styles.draftItemCard}
              key={index}
              onClick={() => {
                jumpCreate(item)
              }}
            >
              <DraftItemCard data={item} getData={getData} isCommons={isCommons} />
            </div>
          ))}
        <div className={styles.inner_more}>
          <div
            className={styles.more}
            style={{
              display: currNum > getTypeData(checked, data, 'childType').length ? 'none' : 'block',
            }}
            onClick={() => {
              setCurrNum(currNum + 12)
            }}
          >
            <img width={16} alt="" src={down} />
            &nbsp;展开更多
          </div>
        </div>
      </div>
    </div>
  )
}

export default Consumer(Context)(withRouter(DraftItem))
