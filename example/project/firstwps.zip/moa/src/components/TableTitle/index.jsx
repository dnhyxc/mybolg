import React from 'react'

export default ({ title = {}, level = {} }) => {
  const renderLevel = () => {
    let excl = ''
    if (level.value === "1") {
      excl = '!!'
    }
    if (level.value === "2") {
      excl = '!'
    }
    return excl
  }
  return (
    <span>
      <span style={{ color: '#FA5F5F', fontSize: '14px' }}>{renderLevel()}</span>
      {title.value || '-'}
    </span>
  )
}
