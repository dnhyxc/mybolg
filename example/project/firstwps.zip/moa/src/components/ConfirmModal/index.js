import React from 'react'
import { Modal } from '@xm/Dialog'
import { Button } from 'antd'
import styles from './index.scss'

class Confirm {
  constructor(props) {
    this.props = props

    this.modal = null
    return this.show()
  }

  show() {
    const { content, onClose, closable, maskClosable, title, style = {} } = this.props
    this.modal = Modal.show({
      title: title || false,
      closable,
      maskClosable,
      style: {
        width: 400,
        height: 180,
        ...style,
      },
      content: <div className={styles.content}>{content}</div>,
      footer: this.getFooterBtns(),
      onClose: () => {
        this.modal()
        onClose && onClose()
      },
    })

    return this.modal
  }

  getFooterBtns() {
    const { alert, onConfirm, onCancel, confirmTxt = '确定', cancelTxt = '取消' } = this.props
    if (alert) {
      return (
        <div className={styles.footer}>
          <Button
            cls={styles.btn}
            color="blue"
            onClick={() => {
              this.modal()
              onConfirm && onConfirm()
            }}
          >
            知道了
          </Button>
        </div>
      )
    } else {
      return (
        <div className={styles.footer}>
          <Button
            className={styles.btn}
            onClick={() => {
              this.modal()
              onCancel && onCancel()
            }}
          >
            {cancelTxt}
          </Button>
          <Button
            className={styles.btn}
            type="primary"
            onClick={() => {
              if (onConfirm && onConfirm() === false) return
              this.modal()
            }}
          >
            {confirmTxt}
          </Button>
        </div>
      )
    }
  }
}

export default Confirm
