import React, { useEffect, useState } from 'react'
import { message, Modal } from 'antd'
import ClassNames from 'classnames'
import official from 'ROOT/service'
import styles from './index.scss'

const REMIND_TYPE = {
  APP: 1, // 应用内
  MSG: 2, // 短信
}
export default props => {
  const { isShow, onClose, id } = props
  const [types, setTypes] = useState([1])
  useEffect(() => {
    setTypes([1])
  }, [isShow])
  const submit = () => {
    onClose()
    Modal.confirm({
      title: '您确定要催办当前办理人吗？',
      onOk: () => {
        official
          .urgeDocument({
            id,
            types,
          })
          .then(() => {
            message.success('已发送催办提醒')
          })
      },
    })
  }
  const clickTab = types => {
    setTypes(types)
  }
  return (
    <Modal title="提醒方式" visible={isShow} onCancel={onClose} onOk={submit}>
      <div>
        <div className={ClassNames(styles.type, styles.active)}>
          <span>应用内</span>
          <i className={ClassNames('icon-duigou iconfont', styles.icon)} />
        </div>
        <div
          className={ClassNames(
            styles.type,
            types.some(x => x === REMIND_TYPE.MSG) ? styles.active : '',
          )}
          onClick={() => clickTab(types.some(x => x === REMIND_TYPE.MSG) ? [1] : [1, 2])}
        >
          <span>短信</span>
          <i className={ClassNames('icon-duigou iconfont', styles.icon)} />
        </div>
      </div>
    </Modal>
  )
}
