/**
 * 全站预览组件
 */
import React from 'react'
import ClassNames from 'classnames'
import { unmountComponentAtNode, render } from 'react-dom'
import { FileIcon } from '@xm/util'
import { downloadFile } from '../../wpsutils'
import styles from './index.scss'

export const preview = ({ fileName, url, fileType }) => {
  console.log(url,'url')
  console.log(fileName,'fileName')
  let type = fileType
  if (!type) {
    type = fileName.split('.').slice(-1)[0]
  }

  const container = document.createElement('div')
  document.body.appendChild(container)

  const handleClose = () => {
    unmountComponentAtNode(container)
    document.body.removeChild(container)
  }

  return render(
    <PreviewFile
      fileName={fileName}
      url={url}
      fileType={type}
      onClose={handleClose}
    />,
    container
  )
}

export const PreviewFile = ({ fileType, url, fileName, onClose }) => {
  const previewUrl = `${window._APP_CONFIG.webHost}/filepreview/index.html?fileType=${fileType}&fileName=${encodeURIComponent(fileName)}&fileUrl=${encodeURIComponent(url)}`

  const handleClose = () => {
    onClose && onClose()
  }

  const handleDownload = () => {
    downloadFile(url, fileName)
  }

  return (
    <div className={styles.preview}>
      <div className={styles.header}>
        <FileIcon
          type={fileType}
          name={fileName}
          size={32}
        />
        <div className={styles.name}>{fileName}</div>
        <i
          className={ClassNames('iconfont icon-xiazai', styles.icon)}
          onClick={handleDownload}
        />
        <i
          className={ClassNames('iconfont icon-close', styles.icon)}
          onClick={handleClose}
        />
      </div>
      <iframe
        className={styles.iframe}
        src={previewUrl}
      />
    </div>
  )
}
