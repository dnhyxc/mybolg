/*
 * @Description: 渲染表单组件
 * @Author: dnh
 * @Date: 2022-03-02 19:24:51
 * @LastEditTime: 2022-03-28 21:15:35
 * @LastEditors: dnh
 * @FilePath: \src\components\FileRender\index.jsx
 */

import React from 'react'
import { Form } from 'antd'
import { globalStore } from '@xm/util'
import { formatDate } from 'ROOT/utils'
import BehaviorType from 'ROOT/components/OfficialContent/AddDocumentComponent/BehaviorType'
import SecretClassification from 'ROOT/components/OfficialContent/AddDocumentComponent/SecretClassification'
import ConfidentialityPeriod from 'ROOT/components/OfficialContent/AddDocumentComponent/ConfidentialityPeriod'
import UseSeal from 'ROOT/components/OfficialContent/AddDocumentComponent/UseSeal'
import Urgency from 'ROOT/components/OfficialContent/AddDocumentComponent/Urgency'
import DocumentType from 'ROOT/components/OfficialContent/AddDocumentComponent/DocumentType'
import RefNo from 'ROOT/components/OfficialContent/AddDocumentComponent/RefNo'
import InputRender from 'ROOT/components/OfficialContent/AddDocumentComponent/InputRender'
import DocumentDate from 'ROOT/components/OfficialContent/AddDocumentComponent/DocumentDate'
import BodyFile from 'ROOT/components/OfficialContent/BodyFile'
import AttachmentUpload from 'ROOT/components/OfficialContent/AddDocumentComponent/AttachmentUpload' // 附件
import ReferenceInformation from 'ROOT/components/OfficialContent/AddDocumentComponent/ReferenceInformation' // 参考信息
import MainDelivery from 'ROOT/components/OfficialContent/AddDocumentComponent/MainDelivery' // 主送
import CopyDelivery from 'ROOT/components/OfficialContent/AddDocumentComponent/CopyDelivery' // 抄送
import JointlySign from 'ROOT/components/OfficialContent/AddDocumentComponent/JointlySign' // 会签部门

const name = globalStore.get('name')
const mobile = globalStore.get('mobile')

const FileRender = (data, renderNeedData, otherProps) => {
  const {
    form: { getFieldValue, getFieldDecorator, setFieldsValue, setFields, resetFields },
    access,
    refNoDataSource,
    classifiedCallback,
    getUploadBodyFile,
    onWpsContentChange,
    docTemplate,
    id,
    previewIndex,
    getDocumentDetail,
    redheadTemplates,
    formDataSource,
    eventTimeList,
    type,
    fileLimit,
    deptId,
    deptName,
    fullDepartment,
    isOperate,
    status,
  } = renderNeedData

  const renderFormItem = (data, value, props) => {
    return (
      <Form.Item
        label={data.customName || data.aliasName}
        key={data.fieldName}
        {...(props ? props.otherProps || {} : {})}
      >
        {getFieldDecorator(data.fieldName, {
          rules: [
            {
              required: data.isFill,
              message: '请输入',
            },
          ],
          initialValue: value,
        })(<span>{value}</span>)}
      </Form.Item>
    )
  }
  // const renderFormItem = (data, value, props) => {
  //   if (props.access === 'WRITE') {
  //     if (type === 'ADD' || isOperate) {
  //       return (
  //         <Form.Item
  //           label={data.customName || data.aliasName}
  //           key={data.fieldName}
  //           {...(props ? props.otherProps || {} : {})}
  //         >
  //           {getFieldDecorator(data.fieldName, {
  //             rules: [
  //               {
  //                 required: data.isFill,
  //                 message: '请输入',
  //               },
  //             ],
  //             initialValue: value,
  //           })(<span>{value}</span>)}
  //         </Form.Item>
  //       )
  //     }
  //     return (
  //       <Form.Item
  //         label={data.customName || data.aliasName}
  //         key={data.fieldName}
  //         {...(props ? props.otherProps || {} : {})}
  //       >
  //         {getFieldDecorator(data.fieldName, {})(<span>-</span>)}
  //       </Form.Item>
  //     )
  //   }
  //   return (
  //     <Form.Item
  //       label={data.customName || data.aliasName}
  //       key={data.fieldName}
  //       {...(props ? props.otherProps || {} : {})}
  //     >
  //       {getFieldDecorator(data.fieldName, {})(<span>-</span>)}
  //     </Form.Item>
  //   )
  // }

  const { fieldName } = data

  const addProductProp = {
    data,
    getFieldDecorator,
    classifiedCallback,
    getFieldValue,
    setFieldsValue,
    setFields,
    resetFields,
    labelsTags: [],
    isDetailedList: fieldName === 'secretClass',
    access: access && access[fieldName], // 当前节点编辑权限
    otherProps,
    id,
    fileLimit,
    previewIndex,
    getDocumentDetail,
    redheadTemplates,
    formDataSource,
    eventTimeList, // 签发日期，印发日期
    type,
    deptId,
    deptName,
    fullDepartment,
    isOperate,
    status,
    paragraphPermissionsAccess: access && access.paragraphPermissions,
    docTemplate,
  }
  switch (fieldName) {
    case 'writing':
      return <BehaviorType key={fieldName} {...addProductProp} />
    case 'secretClass':
      return <SecretClassification key={fieldName} {...addProductProp} />
    case 'secrecyTerm':
      return <ConfidentialityPeriod key={fieldName} {...addProductProp} />
    case 'useSeal':
    case 'dropDownControl':
      return <UseSeal key={fieldName} {...addProductProp} />
    case 'urgencyLevel':
      return <Urgency key={fieldName} {...addProductProp} />
    case 'officialType':
      return <DocumentType key={fieldName} {...addProductProp} />
    case 'fileDepartment': // 拟稿部门
      if (type === 'ADD') {
        return renderFormItem(data, fullDepartment, { ...addProductProp })
      }
      return renderFormItem(data, data.value, { ...addProductProp })
    case 'title':
    case 'remarks':
    case 'impression':
    case 'themeWord':
    case 'proofreader':
    case 'printer':
    case 'issUer':
    case 'dispatchCompany':
    case 'receiptCompany':
    case 'inputControl':
      return <InputRender key={fieldName} {...addProductProp} />
    case 'refNo':
    case 'outsideRefNo':
    case 'receiptRefNo': {
      const accessX = {
        [`${fieldName}1`]: (access && access[`${fieldName}1`]) || 'READ',
        [`${fieldName}2`]: (access && access[`${fieldName}2`]) || 'READ',
        [`${fieldName}3`]: (access && access[`${fieldName}3`]) || 'READ',
      }
      return (
        <RefNo dataSource={refNoDataSource} key={fieldName} {...addProductProp} accessX={accessX} />
      )
    }
    case 'bodyFile':
      return (
        <BodyFile
          key={fieldName}
          formProps={renderNeedData.form}
          getUploadBodyFile={getUploadBodyFile}
          onChange={onWpsContentChange}
          documentFlowData={docTemplate}
          {...addProductProp}
        />
      )
    case 'mobile':
      if (type === 'ADD') {
        return renderFormItem(data, mobile, { ...addProductProp })
      }
      return renderFormItem(data, data.value, { ...addProductProp })
    case 'creatPerson':
      if (type === 'ADD') {
        return renderFormItem(data, name, { ...addProductProp })
      }
      return renderFormItem(data, data.value, { ...addProductProp })
    case 'countersignDepartment':
      return <JointlySign key={fieldName} {...addProductProp} />
    case 'creatTime':
      if (type === 'ADD') {
        return renderFormItem(data, formatDate(new Date(), 'YYYY/MM/DD'), { ...addProductProp })
      }
      return renderFormItem(data, data.value, { ...addProductProp })
    case 'dispatchDate':
    case 'receiptDate':
    case 'timeControl':
      return <DocumentDate key={fieldName} {...addProductProp} />
    case 'enclosure':
      return <AttachmentUpload key={fieldName} {...addProductProp} />
    case 'reference':
      return <ReferenceInformation key={fieldName} {...addProductProp} />
    case 'mainSend':
      return <MainDelivery key={fieldName} {...addProductProp} />
    case 'copySend':
      return <CopyDelivery key={fieldName} {...addProductProp} />
    default:
      return ''
  }
}

export default FileRender
