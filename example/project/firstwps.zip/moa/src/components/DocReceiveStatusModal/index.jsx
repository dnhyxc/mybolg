import React, { useEffect, useState } from 'react'
import { message, Modal, Table } from 'antd'
import service from 'ROOT/service'
import { formatDate } from 'ROOT/utils'

export default props => {
  const { onClose, title = '公文接收状态', id, history, match } = props
  const [outList, setOutList] = useState([])
  const [groupList, setGroupList] = useState([])
  const getList = () => {
    // 地市发文的接受状态
    service
      .getDocumentOutToListByDocumentId({
        documentId: id,
      })
      .then(res => {
        setOutList(res.infos)
      })
    // 集团发文的接受状态
    service
      .getGroupSendListByDocumentId({
        documentId: id,
      })
      .then(res => {
        const newList = res.list.map(x => {
          if (x.operType === 1) {
            return {
              ...x,
              signTime: x.operTime,
              toOrgName: x.shortOrgName,
            }
          }
          return {
            ...x,
            toOrgName: x.shortOrgName,
          }
        })
        setGroupList(newList)
      })
  }
  useEffect(() => {
    getList()
  }, [])
  const columns = [
    {
      title: '单位名称',
      key: 'toOrgName',
      dataIndex: 'toOrgName',
    },
    {
      title: '接收状态',
      key: 'receiveStatus',
      render: item => {
        if (item.backTime) {
          return '已退回'
        }
        if (item.signTime) {
          return '已签收'
        }
        return '待签收'
      },
    },
    {
      title: '接收时间',
      key: 'signTime',
      dataIndex: 'signTime',
      render: text => (text ? formatDate(text, 'YYYY/MM/DD HH:mm') : '-'),
    },
  ]
  const onRowClick = record => {
    if (record.documentId) {
      history.push(`/mydocument/${record.documentId}`)
    } else {
      message.error('系统未生成公文，无法跳转')
    }
  }
  return (
    <Modal onOk={onClose} onCancel={onClose} visible title={title}>
      <Table
        columns={columns}
        dataSource={[...outList, ...groupList]}
        onRowClick={record => onRowClick(record)}
      />
    </Modal>
  )
}
