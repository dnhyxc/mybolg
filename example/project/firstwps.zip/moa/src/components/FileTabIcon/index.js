import React from 'react'
import ClassNames from 'classnames'
import TipWrapper from 'ROOT/components/TipWrapper'
import styles from './index.scss'

export default class FileTabIcon extends React.Component {
  constructor(props) {
    super(props)
    this.state = {
      isOpChildrenShow: false,
    }
  }

  operationClick = (item, e) => {
    e.stopPropagation()
    item.handler && item.handler()
  }

  render() {
    const { data: item } = this.props
    return (
      <div
        className={ClassNames(styles.op)}
        onClick={this.operationClick.bind(null, item)}
      >
        <TipWrapper
          className={styles['op-tip']}
          tipCls={styles.tip}
          tip={item.name}
          direction="up"
        >
          <i className={ClassNames('iconfont ', item.icon, styles['op-icon'])} />
        </TipWrapper>
        {!!item.children && (
          <div className={styles['operation-children']}>
            {item.children.map((it) => (
              <div
                key={it.name}
                className={styles.operation}
                onClick={this.operationClick.bind(null, it)}
              >
                {it.name}
              </div>
            ))}
          </div>
        )}
      </div>
    )
  }
}
