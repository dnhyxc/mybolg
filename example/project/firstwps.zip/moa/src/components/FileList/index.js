import React, { useState, useEffect } from 'react'
import cx from 'classnames'
import { DragDropContext, Droppable, Draggable } from 'react-beautiful-dnd'
import { Spin } from 'antd'
import service from 'ROOT/service'
import { globalStore } from '@xm/util'
import RenameModal from 'ROOT/Components/RenameModal'
import FileItem from './item'

import styles from './index.scss'

const FileList = (props) => {
  const {
    enableSort,
    wrapperClassName,
    contentClassName,
    dataSource = [],
    onDelete,
    onSortEnd,
    onRename,
    downloadable,
    beforeDownload,
    onClick,
    renderExtraActions,
    secretClassStatus,
    type,
    deptId,
    access,
    status,
    docTemplate,
  } = props
  const [midData, setMidData] = useState(dataSource)
  const [loading, setLoading] = useState(false)
  const [renameVisible, setRenameVisible] = useState(false)
  const [renameIndex, setRenameIndex] = useState(-1)
  const orgId = globalStore.get('orgId')

  useEffect(() => {
   // 查询所有子部门
    service.getDeptRoot({deptId: deptId || 0}).then(subDept => {
      if (status === 1) {
        dataSource.forEach(item => {
          // 当前登录人为根部门，则附件全部可见
          if (!deptId) {
            item.isSeeing = true
            return
          }
          if (
            item.visibleRange &&
            Array.isArray(item.visibleRange.depts) &&
            item.visibleRange.depts.length > 0
          ) {
            const isRight = item.visibleRange.depts.find((i) =>
              String(i.id) === String(subDept.id) ||
              String(i.id) === String(orgId),
            )
            if (isRight) {
              item.isSeeing = true
            } else {
              item.isSeeing = false
            }
          } else {
            item.isSeeing = true
          }
        })
      }
      setMidData(dataSource)
    })
  }, [dataSource])

  const handleDragEnd = (result) => {
    if (!(onSortEnd instanceof Function)) {
      return
    }
    if (!result || dataSource.length === 0) {
      return
    }

    const { destination, source } = result

    if (!destination || !source) {
      return
    }

    if (destination.index === source.index) {
      return
    }

    const newData = [...midData];
    [newData[destination.index], newData[source.index]] = [
      newData[source.index],
      newData[destination.index],
    ]

    setMidData(newData)

    // setLoading(true)
    onSortEnd(newData)
    // .catch(() => {
    //   message.error('排序失败')
    // })
    // .finally(() => {
    //   setLoading(false)
    // })
  }

  const handleRename = (index) => {
    setRenameVisible(true)
    setRenameIndex(index)
  }

  const handleRenameCancel = () => {
    setRenameVisible(false)
  }

  const handleRenameOk = (newName) => {
    // if (!(onRename instanceof Function)) {
    //   return
    // }

    handleRenameCancel()

    const newData = [...midData]
    newData[renameIndex] = {
      ...newData[renameIndex],
      name: newName,
    }
    setMidData(newData)

    // setLoading(true)
    onRename(newData)
    // .catch(() => {
    //   message.error('重命名失败')
    // })
    // .finally(() => {
    //   setLoading(false)
    // })
  }

  const renderItems = () => {
    return midData.map((item, index) => {
      if (status === 1) {
        if (!item.isSeeing) {
          return null
        }
      }

      // const key = item.key || item.originalUrl || item.downloadUrl || item.name
      const key = item.key || item.originalUrl || item.downloadUrl || item.uid

      return (
        <Draggable
          key={key}
          draggableId={key}
          index={index}
          isDragDisabled={!enableSort}
        >
          {(provided, snapshot) => {
            return (
              <FileItem
                key={item.key || index}
                enableSort={enableSort}
                provided={provided}
                snapshot={snapshot}
                dataSource={item}
                curIndex={index}
                secretClassStatus={secretClassStatus}
                className={contentClassName}
                beforeDownload={beforeDownload}
                downloadable={item.downloadable === false ? item.downloadable : downloadable}
                onDelete={item.onDelete || onDelete}
                onClick={onClick}
                onRename={() => handleRename(index)}
                renderExtraActions={renderExtraActions}
                access={access}
                docTemplate={docTemplate}
                type={type}
              />
            )
          }}
        </Draggable>
      )
    })
  }

  return (
    <div className={styles.fileLists}>
      <Spin spinning={loading} >
        <DragDropContext onDragEnd={handleDragEnd} >
          <Droppable
            direction="vertical"
            droppableId="droppable-1"
            type="PERSON"
            isDropDisabled={!enableSort}
          >
            {(provided, snapshot) => (
              <div
                className={cx(styles.filelist, wrapperClassName)}
                ref={provided.innerRef}
                {...provided.droppableProps}
              >
                {renderItems()}
                {provided.placeholder}
              </div>
            )}
          </Droppable>
        </DragDropContext>

        <RenameModal
          dataSource={midData[renameIndex]}
          visible={renameVisible}
          onOk={handleRenameOk}
          onCancel={handleRenameCancel}
        />
      </Spin>
    </div>
  )
}

export default FileList
