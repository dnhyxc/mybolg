import React from 'react'
import PropTypes from 'prop-types'
import cx from 'classnames'
import service from 'ROOT/service/official'
import { Button, message } from 'antd'
// import { omit } from 'lodash'
import { download, getFileIcon, getFileExt, getFileSize } from '@xm/FileList/dist/util'

import { getFieldChild } from 'ROOT/utils'
import { FIELD_TYPE } from 'ROOT/constant'

import styles from './item.scss'

const FileItem = props => {
  const {
    enableSort,
    className,
    dataSource,
    onDelete,
    onRename,
    downloadable,
    beforeDownload,
    provided,
    snapshot,
    onClick,
    curIndex,
    renderExtraActions,
    secretClassStatus,
    docTemplate: { isOperate = false, fields = [] } = {},
    access,
    type,
  } = props
  if (!dataSource) {
    return null
  }
  
  const isShow = () => {
    return type === 'ADD' || (type === 'DETAIL' && isOperate && access === 'WRITE')
  }

  const upload = [
    {
      name: '预览',
      key: 'preview',
    },
    {
      name: '下载',
      key: 'download',
    },
  ]

  const uploadAction = [
    {
      name: '预览',
      key: 'preview',
    },

    {
      name: '重命名',
      key: 'rename',
    },
    {
      name: '下载',
      key: 'download',
    },

    {
      name: '删除',
      key: 'delete',
    },
  ]

  const enableDownload =
    dataSource.itemDownloadable === false ? dataSource.itemDownloadable : downloadable

  const onDownloadHandler = () => {
    const fileType = dataSource.name.split('.')[1]
    const { url } = dataSource
    const currentField = getFieldChild(fields, FIELD_TYPE.SECRET_CLASS)
    const isCommonly = currentField.value && currentField.value == 4 // 密级4是一般
    if (!currentField.value || (currentField.value && isCommonly)) {
      // 没有密级 后者 密级是一般不加水印
      download(url, dataSource.name)
    } else {
      service.addWatermark({ url, type: fileType }, true).then(res => {
        download(res.descUrl, dataSource.name)
      }).catch((err) => {
        if (err.retcode === 401) {
          download(url, dataSource.name)
          message.info('该文件无法添加水印，已下载原文件')
          return
        }
        message.error('系统错误，请重新刷新页面')
      })
    }
  }

  const getMark = url => {
    service.addWatermark({ url }).then(res => {
      console.log(res, 'res')
      download(res.descUrl, dataSource.name)
    })
  }

  const wordTransformationPDT = (fileName, srcUrl) => {
    return service.doc2pdf({ fileName, srcUrl }).then()
  }

  const onDeleteHandler = () => {
    // ev.stopPropagation()
    onDelete(dataSource)
  }

  // const onPreviewHandler = () =>

  const onPreviewHandler = () => {
    onClick && onClick(dataSource)
  }

  const handleOptions = (key, domEvent) => {
    console.log(domEvent, 'pp')
    console.log(key, 'kk')
    domEvent.stopPropagation()
    domEvent.preventDefault()

    switch (key) {
      case 'download':
        return onDownloadHandler()
      case 'delete':
        return onDeleteHandler()
      case 'preview':
        return onPreviewHandler()
      case 'rename': {
        if (!onRename) {
          return
        }
        return onRename()
      }
      default: {
        break
      }
    }
  }

  const hasTwoBtn = () => {
    const hasDownload = enableDownload && dataSource.downloadUrl
    const hasDelete = !!onDelete
    const hasExtra = renderExtraActions instanceof Function
    return [hasDownload, hasDelete, hasExtra].filter(Boolean).length === 2
  }

  const hasTwo = enableSort && (enableDownload || onDelete)

  const clazz = cx(
    styles.item,
    {
      [styles.has_one]: !hasTwo,
      [styles.has_two]: hasTwo,
      [styles.draging]: snapshot.isDragging,
    },
    className,
  )

  const renderExtraBtn = () => {
    if (!(renderExtraActions instanceof Function)) {
      return null
    }
    return renderExtraActions(props)
  }

  const renderBtns = () => {
    if (!enableDownload && !onDelete) {
      return null
    }

    // const menu = (
    //   <Menu onClick={handleOptions}>
    //     {onDelete && (
    //       <Menu.Item
    //         key="rename"
    //       >
    //         重命名
    //       </Menu.Item>
    //     )}
    //     {enableDownload && (
    //       <Menu.Item
    //         key="download"
    //       >
    //         下载
    //       </Menu.Item>
    //     )}
    //     {onDelete && (
    //       <Menu.Item
    //         key="delete"
    //       >
    //         删除
    //       </Menu.Item>
    //     )}
    //   </Menu>
    // )

    return (
      <div className={styles.actionStyle}>
        {/* {(enableDownload || onDelete) && (
          <Dropdown
            overlay={menu}
            // trigger={['click']}
          >
            <i
              className={cx(
                'iconfont icon-more',
                styles['icon-more'],
              )}
              onClick={stopPropagation}
              // onClick={onDownloadHandler}
            />
          </Dropdown>
        )} */}

        {(isShow() ? uploadAction : upload).map(item => {
          return (
            <Button
              type="link"
              onClick={e => handleOptions(item.key, e)}
              style={{ color: item.key === 'delete' ? '#FA6C6C' : '#5577CC' }}
              key={item.key}
            >
              {item.name}
            </Button>
          )
        })}
      </div>
    )
  }

  return (
    <div
      className={clazz}
      className={styles.fileItemStyle}
      // onClick={onFileClickHandler}
      ref={provided.innerRef}
      {...provided.draggableProps}
    >
      <span
        title="排序"
        // className={styles.moreIcon}
        className={cx('iconfont icon-paixu', {
          [styles['drag-disable']]: !enableSort,
          [styles.moreIcon]: enableSort,
        })}
        {...provided.dragHandleProps}
      />
      <div className={styles.uploadIcon}>
        {dataSource.icon ? (
          <img src={dataSource.icon} alt={dataSource.name} />
        ) : (
          <i
            className={cx(
              styles.fileicon,
              styles.filetype,
              styles[getFileIcon(getFileExt(dataSource.name))],
            )}
          />
        )}
      </div>
      <div className={styles.contentName}>
        <span className={styles.uploadName} title={dataSource.name}>
          {`${curIndex + 1}.${dataSource.name}`}
        </span>
        {dataSource.size ? (
          <span className={styles.uploadSize}>{getFileSize(dataSource.size)}</span>
        ) : null}
      </div>
      {renderBtns()}
    </div>
  )
}

export default FileItem
