import React, { useState, useEffect } from 'react'
import { Modal, Table, Row, Col, Select, Input, Form, Button } from 'antd'

import service from 'ROOT/service'
// import official from 'ROOT/service'
import MountInPopup from '../MountInPopup'
import { columns } from './config'

const formItemLayout = {
  labelCol: { span: 6 },
  wrapperCol: { span: 18 },
}
export default (props) => {
  const { handleCloseModal, onChange } = props
  const [visible] = useState(true)
  const [radioValue, setRadioValue] = useState(undefined)
  const [totalSize, setTotalSize] = useState(0)
  const [dataSource, setDataSource] = useState([])
  const [loading, setLoading] = useState(true)
  const [selectInfo, setSelectInfo] = useState({ deptName: [], itemSubType: [], itemType: [] })
  const [params, setParams] = useState({
    pageId: 1,
    pageCount: 10,
  })
  const [query, setQuery] = useState({
    screen: {
      itemType: '',
      itemSubType: '',
      deptName: '',
      itemInfo: '',
    },
  })
  const handleChangeValue = (val, type) => {
    setQuery({
      screen: {
        ...query.screen,
        [type]: val,
      },
    })
  }
  const handleSearch = () => {
    setParams({
      pageId: 1,
      pageCount: 10,
    })
    setLoading(true)
  }

  const handleReset = () => {
    setParams({
      pageId: 1,
      pageCount: 10,
    })
    setLoading(true)
    setQuery({
      screen: {
        itemType: '',
        itemSubType: '',
        deptName: '',
        itemInfo: '',
      },
    })
    setRadioValue(undefined)
  }
  const closeModal = () => {
    // eslint-disable-next-line no-unused-expressions
    handleCloseModal && handleCloseModal()
  }
  const getItemSecretList = () => {
    service
      .getItemSecretList({
        ...params,
        ...query,
      })
      .then((res) => {
        console.log(res, 'res')
        const { infos, allCount } = res
        setDataSource(infos.map((x, j) => ({ ...x, id: params.pageId * 10 + j + 1 })))
        setTotalSize(allCount)
        setLoading(false)
      })
  }
  const getItemClassify = () => {
    service.getItemClassify({}).then((res) => {
      const { info } = res
      setSelectInfo(info)
    })
  }

  const onRadioChange = (e) => {
    console.log(e.target.value, 'e.target.value')
    setRadioValue(e.target.value)
  }

  const handleOk = () => {
    console.log(typeof(dataSource), 'dataSource')
    console.log(radioValue, 'radioValue')
    if (onChange) onChange(dataSource.filter((x) => x.id === radioValue))

  }

  const pagination = {
    current: params.pageId,
    total: totalSize,
    onChange: (page) => {
      setParams({
        ...params,
        pageId: page,
      })
      setLoading(true)
    },
  }
  useEffect(() => {
    getItemSecretList()
  }, [params])
  useEffect(() => {
    getItemClassify()
  }, [])
  return (
    <Modal
      visible={visible}
      onCancel={closeModal}
      width={'90%'}
      onOk={handleOk}
      okButtonProps={{ disabled: !radioValue }}
      title="密级清单"
    >
      <Row>
        <Col span={8}>
          <Form.Item
            label="事项分类"
            {...formItemLayout}
          >
            <MountInPopup>
              {(renderProps) => (
                <Select
                  {...renderProps}
                  value={query.screen.itemType || undefined}
                  style={{ width: '100%' }}
                  placeholder="请选择"
                  onChange={(val) => handleChangeValue(val, 'itemType')}
                  allowClear
                  getPopupContainer={triggerNode => triggerNode.parentNode}
                >
                  {selectInfo.itemType.map((x) => (
                    <Select.Option
                      value={x}
                      key={x}
                    >
                      {x}
                    </Select.Option>
                  ))}
                </Select>
              )}
            </MountInPopup>
          </Form.Item>
        </Col>
        <Col span={8}>
          <Form.Item
            label="事项小类"
            {...formItemLayout}
          >
            <MountInPopup>
              {(renderProps) => (
                <Select
                  {...renderProps}
                  value={query.screen.itemSubType || undefined}
                  style={{ width: '100%' }}
                  placeholder="请选择"
                  onChange={(val) => handleChangeValue(val, 'itemSubType')}
                  allowClear
                  getPopupContainer={triggerNode => triggerNode.parentNode}
                >
                  {selectInfo.itemSubType.map((x) => (
                    <Select.Option
                      value={x}
                      key={x}
                    >
                      {x}
                    </Select.Option>
                  ))}
                </Select>
              )}
            </MountInPopup>
          </Form.Item>
        </Col>
        <Col span={8}>
          <Form.Item
            label="责任部门"
            {...formItemLayout}
          >
            <MountInPopup>
              {(renderProps) => (
                <Select
                  {...renderProps}
                  value={query.screen.deptName || undefined}
                  style={{ width: '100%' }}
                  placeholder="请选择"
                  onChange={(val) => handleChangeValue(val, 'deptName')}
                  allowClear
                  getPopupContainer={triggerNode => triggerNode.parentNode}
                >
                  {selectInfo.deptName.map((x) => (
                    <Select.Option
                      value={x}
                      key={x}
                    >
                      {x}
                    </Select.Option>
                  ))}
                </Select>
              )}
            </MountInPopup>
          </Form.Item>
        </Col>
        <Col span={8}>
          <Form.Item
            label="具体事项"
            {...formItemLayout}
          >
            <Input
              autoComplete='off'
              value={query.screen.itemInfo}
              placeholder="请输入"
              onChange={(e) => handleChangeValue(e.target.value, 'itemInfo')}
              allowClear
            />
          </Form.Item>
        </Col>
        <Col
          span={8}
          push={1}
        >
          <Form.Item>
            <Button
              onClick={handleSearch}
              type="primary"
              className="mr-8"
            >
              查询
            </Button>
            <Button onClick={handleReset}>重置</Button>
          </Form.Item>
        </Col>
      </Row>
      <Table
        columns={columns(onRadioChange, radioValue)}
        dataSource={dataSource}
        loading={loading}
        pagination={pagination}
      />
    </Modal>
  )
}
