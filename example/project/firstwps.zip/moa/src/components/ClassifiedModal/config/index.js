import { Radio } from 'antd'
import React from 'react'
import { tooltipText } from 'ROOT/utils'

export const columns = (onChange, value) => {
  return [
    {
      title: '事项分类',
      dataIndex: 'itemType',
      key: 'itemType',
      render: (text, record) => (
        <Radio.Group
          onChange={onChange}
          value={value}
        >
          <Radio value={record.id}>{text}</Radio>
        </Radio.Group>
      ),
    },
    {
      title: '事项小类',
      dataIndex: 'itemSubType',
      key: 'itemSubType',
    },
    {
      title: '具体事项、信息',
      dataIndex: 'itemInfo',
      key: 'itemInfo',
      render: (text) => tooltipText(text),
    },
    {
      title: '密级',
      dataIndex: 'secretClass',
      key: 'secretClass',
    },
    {
      title: '保密期限',
      dataIndex: 'secretTime',
      key: 'secretTime',
    },
    {
      title: '责任部门',
      dataIndex: 'deptName',
      key: 'deptName',
      render: (text) => tooltipText(text),
    },
  ]
}
