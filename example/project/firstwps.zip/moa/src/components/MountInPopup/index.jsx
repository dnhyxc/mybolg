import React, { Fragment, useRef } from 'react';
import PropTypes from 'prop-types'

const MountInPopup = (props) => {
  const { containerFuncName, children } = props
  const containerRef = useRef()

  if (!(children instanceof Function)) {
    return children
  }

  const renderProps = {
    [containerFuncName]: () => containerRef.current,
  }

  return (
    <Fragment>
      <div ref={containerRef} />
      {children(renderProps, containerRef)}
    </Fragment>
  )
}

MountInPopup.defaultProps = {
  containerFuncName: 'getPopupContainer',
}

MountInPopup.propTypes = {
  containerFuncName: PropTypes.string,
  children: PropTypes.func.isRequired,
}

export default MountInPopup
