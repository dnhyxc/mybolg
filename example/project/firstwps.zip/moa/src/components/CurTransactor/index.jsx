import React from 'react'
import { Tooltip } from 'antd'

const MAX_SHOW = 2

const CurTransactor = props => {
  const { users = [], defaultValue = '-' } = props
  const userTxt = users.map(it => it.name).join('、')
  const limitTxt = users
    .slice(0, MAX_SHOW)
    .map(it => it.name)
    .join('、')

  if (users.length === 0) {
    return defaultValue
  }

  if (users.length <= MAX_SHOW) {
    return userTxt
  }

  return (
    <Tooltip placement="left" title={userTxt}>
      <span>
        {limitTxt}等{users.length}人
      </span>
    </Tooltip>
  )
}

export default CurTransactor
