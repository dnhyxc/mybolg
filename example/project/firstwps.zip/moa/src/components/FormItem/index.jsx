import React, { useState, useEffect } from 'react'
import { Form, Select } from 'antd'
import styles from './index.scss'

const { Option } = Select

const FormItem = props => {
  const {
    data: { aliasName, fieldName, property, isFill, value, customName },
    getFieldDecorator,
    classifiedCallback,
    isDetailedList,
    access = 'READ',
    otherProps,
    isOperate,
    type,
    getFieldValue,
    setFieldsValue,
    // selectChange,
  } = props.formDataProps
  // console.log('otherProps', otherProps, aliasName)

  const [dataSource, setDataSource] = useState([])
  const [formItemValue, setFormItemValue] = useState('')

  const classifiedEvent = () => {
    if (classifiedCallback) classifiedCallback(classifiedCallback)
  }

  const selectChangeMethods = (value) => {
    if (fieldName === 'secretClass') {
      if (!(value !== 4 && value)) {
        setFieldsValue({secrecyTerm: ''})
      }
    }

  }

  const renderForm = () => {
    if (access === 'WRITE') {
      if (type === 'ADD' || isOperate) {
        return renderItem()
      }
      return (
        <Form.Item {...otherProps} label={customName || aliasName}>
          {getFieldDecorator(fieldName, {
          initialValue: Number(value) || '',
          rules: [{ required: isFill, message: `请输入${aliasName}！` }],
        })(
          <span>{formItemValue || '-'}</span>,
        )}
        </Form.Item>
      )
    }
    if (access === 'READ') {
      return (
        <Form.Item {...otherProps} label={customName || aliasName}>
          {getFieldDecorator(fieldName, {
          initialValue: Number(value) || '',
          rules: [{ required: isFill, message: `请输入${aliasName}！` }],
        })(
          <span>{formItemValue || '-'}</span>,
        )}
        </Form.Item>
      )
    }
  }

  const renderItem = () => {
    if (fieldName === 'secrecyTerm') {
      const secretClassStatus = getFieldValue('secretClass')
      const isShow = secretClassStatus !== 4 && secretClassStatus
      return (
        <Form.Item {...otherProps} label={isShow ? (customName || aliasName) : ''}>
          {getFieldDecorator(fieldName, {
            initialValue: isShow ? (Number(value) || '') : '',
            rules: [{ required: isShow ? isFill : false, message: `请输入${(customName || aliasName)}！` }],
          })(
            isShow ?
            <Select placeholder="请选择"
            //  onChange={selectChangeMethods} 
             getPopupContainer={triggerNode => triggerNode.parentNode}>
              {dataSource &&
                (dataSource).map(item => {
                  return (
                    <Option key={item.value} value={item.value}>
                      {item.text}
                    </Option>
                  )
                })}
            </Select> : <span> </span>,
          )}
        </Form.Item>
      )
    }
    return (
      <Form.Item {...otherProps} label={(customName || aliasName)}>
        {getFieldDecorator(fieldName, {
          initialValue: Number(value) || '',
          rules: [{ required: isFill, message: `请输入${(customName || aliasName)}！` }],
        })(
          <Select placeholder="请选择"
           onChange={selectChangeMethods} 
           getPopupContainer={triggerNode => triggerNode.parentNode}>
            {dataSource &&
              (dataSource).map(item => {
                return (
                  <Option key={item.value} value={item.value}>
                    {item.text}
                  </Option>
                )
              })}
          </Select>,
        )}
        {isDetailedList && (
          <div className={styles['docnum-auto']}>
            <span className={styles['auto-num']} onClick={classifiedEvent}>
              查看密级清单
            </span>
          </div>
        )}
      </Form.Item>
    )
  }

  useEffect(() => {
    const options = property && JSON.parse(property).options
    if (access === 'READ') {
      if (value !== '') {
        const optionsValue =
          options.length !== 0 && options.filter(item => item.value === Number(value))[0]
        if (optionsValue) {
          setFormItemValue(optionsValue.text)
        }
        
      }
    }
    setDataSource(options)
  }, [props])

  return <div className={styles.formItemStyle}>{renderForm()}</div>
}

export default FormItem
