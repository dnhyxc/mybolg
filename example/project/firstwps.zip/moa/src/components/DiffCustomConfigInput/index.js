import React, { Component } from 'react'
import { Modal, message, Spin } from 'antd'
import cx from 'classnames'
// import { v1 as uuidv1 } from 'uuid'
import { connect } from 'react-redux'

import AddItem from 'ROOT/components/DiffCustomInput/AddItem'
import official from 'ROOT/service'

import styles from './index.scss'

const secondData = [
  {
    label: '标题',
    value: 1,
  },
  {
    label: '正文',
    value: 2,
  },
  {
    label: '附件',
    value: 3,
  },
  {
    label: '主抄送单位',
    value: 4,
  },
  {
    label: '密级',
    value: 5,
  },
  {
    label: '其他',
    value: 6,
  },
]

const gerSecondData = index => {
  return secondData.map(item => {
    return {
      ...item,
      label: `${item.label}--${index}`,
    }
  })
}

const firstData = [
  {
    label: '标题',
    value: 1,
    children: gerSecondData(1),
  },
  {
    label: '正文',
    value: 2,
    children: gerSecondData(2),
  },
  {
    label: '附件',
    value: 3,
    children: gerSecondData(3),
  },
  {
    label: '主抄送单位',
    value: 4,
    children: gerSecondData(4),
  },
  {
    label: '密级',
    value: 5,
    children: gerSecondData(5),
  },
  {
    label: '其他',
    value: 6,
    children: gerSecondData(6),
  },
]

const RenderConfigList = 'RenderDiffList'
const RenderAddItem = 'RenderAddItem'
const GetFields = 'GetFields'
const HandleInitData = 'HandleInitData'
const HandleResetEdit = 'HandleResetEdit'
const HandleClose = 'HandleClose'
const HandleSubmit = 'HandleSubmit'
const HandleChangeActiveKey = 'HandleChangeActiveKey'
const HandleOpenAdd = 'HandleOpenAdd'
const HandleCloseAdd = 'HandleCloseAdd'
const HandleSubmitAdd = 'HandleSubmitAdd'
const HandleDeleteItem = 'HandleDeleteItem'

class DiffCustomConfigInput extends Component {
  state = {
    visible: false,
    loading: false,
    submiting: false,
    configData: [],
    firstActiveKey: 0,
    isAdd: [false, false],

    /**
     * 编辑态标识
     *
     * [depth, index]
     */
    editKeyList: [0, -1],
  }

  /**
   * 是否在编辑态
   *
   * @readonly
   * @memberof DiffCustomConfigInput
   */
  get isEditing() {
    const { editKeyList = [], isAdd = [] } = this.state

    // 正在添加
    if (isAdd.some(item => item)) {
      return true
    }

    return editKeyList[1] !== -1
  }

  open = () => {
    this[HandleInitData]()
    this.setState({
      visible: true,
      isAdd: [false, false],
    })
  };

  [GetFields] = () => {
    return official.getUserErrFields({}).then(res => {
      const { errFields = [] } = res || {}
      this.setState({
        configData: errFields,
      })
    })
  };

  [HandleInitData] = () => {
    this.setState({ loading: true })

    Promise.all([this[GetFields]()]).finally(() => {
      this.setState({ loading: false })
    })
  };

  [HandleClose] = (isOk = false) => {
    if (isOk) {
      this.setState({
        visible: false,
      })
      return
    }
    Modal.confirm({
      title: '确认要关闭吗?',
      content: '关闭后，刚新建或者修改的内容不保存',
      okText: '确定',
      cancelText: '取消',
      onOk: () => {
        this.setState({
          visible: false,
        })
      },
    })
  };

  [HandleSubmit] = () => {
    const { configData = [] } = this.state

    if (configData.length === 0) {
      message.error('请至少添加 1 个一级问题点')
      return
    }

    this.setState({
      submiting: true,
    })

    const params = {
      errFields: configData,
    }
    return official
      .setUserErrFields(params)
      .then(() => {
        message.success('修改问题点成功')
        this[HandleClose](true)
      })
      .finally(() => {
        this.setState({
          submiting: false,
        })
      })
  };

  [HandleChangeActiveKey] = (activeKey, depth) => {
    if (depth !== 0) {
      return
    }

    if (this.isEditing) {
      message.warning('当前有选项正在编辑，请结束后再操作！')
      return
    }

    this.setState({
      firstActiveKey: activeKey,
    })
  };

  [HandleResetEdit] = () => {
    this.cacheDataIndex = -1
    this.setState({
      isAdd: [false, false],
      editKeyList: [0, -1],
    })
  };

  [HandleOpenAdd] = (depth = 0, cacheIndex = -1) => {
    const { editKeyList = [], isAdd = [] } = this.state
    if (this.isEditing) {
      message.warning('当前有选项正在编辑，请结束后再操作！')
      return
    }

    // 去编辑
    if (cacheIndex !== -1) {
      const newEditKeyList = [...editKeyList]
      newEditKeyList[0] = depth
      newEditKeyList[1] = cacheIndex
      this.setState({
        editKeyList: newEditKeyList,
      })
      return
    }

    // 新增
    const newIsAdd = [...isAdd]
    newIsAdd[depth] = true
    this.setState({
      isAdd: newIsAdd,
    })
  };

  [HandleCloseAdd] = (depth = 0) => {
    const { editKeyList, isAdd = [] } = this.state
    // 退出编辑
    if (editKeyList[1] !== -1) {
      this[HandleResetEdit]()
      return
    }

    // 退出添加
    const newIsAdd = [...isAdd]
    newIsAdd[depth] = false
    this.setState({
      isAdd: newIsAdd,
    })
    this[HandleResetEdit]()
  };

  [HandleSubmitAdd] = (depth, content) => {
    const { editKeyList = [], firstActiveKey, configData = [] } = this.state
    const cacheDataIndex = editKeyList[1]

    this[HandleCloseAdd](depth)

    const newConfig = [...configData]

    // 编辑
    if (cacheDataIndex !== -1) {
      if (depth === 0) {
        newConfig[editKeyList[1]].value = content
      } else {
        const curList = newConfig[firstActiveKey].subFields || []
        curList[editKeyList[1]] = content
        newConfig[firstActiveKey].subFields = curList
      }
      this.setState({
        configData: newConfig,
      })
      return
    }

    // 添加
    if (depth === 0) {
      newConfig.push({
        value: content,
        subFields: [],
      })
      this.setState({
        configData: newConfig,
      })
      return
    }

    const curList = newConfig[firstActiveKey].subFields || []
    curList.push(content)
    newConfig[firstActiveKey].subFields = curList
    this.setState({
      configData: newConfig,
    })
  };

  [HandleDeleteItem] = (depth, index) => {
    if (this.isEditing) {
      message.warning('当前有选项正在编辑，请结束后再操作！')
      return
    }
    const confirmOK = () => {
      const { configData, firstActiveKey } = this.state
      const newConfig = [...configData]
      if (depth === 0) {
        newConfig.splice(index, 1)
      } else {
        const curList = newConfig[firstActiveKey].subFields || []
        curList.splice(index, 1)
        newConfig.subFields = curList
      }
      this.setState({
        configData: newConfig,
      })
    }

    if (depth !== 0) {
      confirmOK()
      return
    }

    Modal.confirm({
      title: '确定要删除该选项吗？',
      content: '删除后，该选项下面的子二级选项也将删除',
      onOk: confirmOK,
    })
  };

  [RenderAddItem] = (depth = 0) => {
    const { isAdd } = this.state
    const curIsAdd = isAdd[depth]

    if (!curIsAdd) {
      return (
        <span
          className={cx(styles['config-item-text'], styles['config-item-add-text'])}
          onClick={() => this[HandleOpenAdd](depth)}
        >
          <i className={cx('iconfont icon-jiahao', styles['config-item-icon'])} />
          新增选项
        </span>
      )
    }

    return (
      <AddItem
        width="100%"
        size="small"
        onOk={content => this[HandleSubmitAdd](depth, content)}
        onClose={() => this[HandleCloseAdd](depth)}
      />
    )
  };

  [RenderConfigList] = (depth = 0) => {
    const { loading, configData = [], firstActiveKey, editKeyList } = this.state
    let dataList = configData
    let headerTitle = '一级选项'
    if (depth !== 0) {
      const { subFields = [] } = dataList[firstActiveKey] || {}
      dataList = subFields
      headerTitle = '二级选项'
    }

    const editKey = editKeyList[0] === depth ? editKeyList[1] : -1

    const dataDom = dataList.map((item, index) => {
      if (!item) {
        return null
      }

      const label = depth === 0 ? item.value : item

      if (editKey !== index) {
        return (
          <li
            key={`${label}-${index}`}
            className={cx(styles['config-item'], {
              [styles['config-item-active']]: depth === 0 && firstActiveKey === index,
            })}
            onClick={() => this[HandleChangeActiveKey](index, depth)}
          >
            <span className={styles['config-item-text']}>{label}</span>
            <div className={styles['config-item-actions']}>
              <i
                className={cx('iconfont icon-gongzuobianji', styles['config-item-icon'])}
                onClick={() => this[HandleOpenAdd](depth, index)}
              />
              <i
                className={cx('iconfont icon-shanchu2', styles['config-item-icon'])}
                onClick={() => this[HandleDeleteItem](depth, index)}
              />
            </div>
          </li>
        )
      }

      return (
        <li
          key={`${label}-${index}`}
          className={cx(styles['config-item'], {
            [styles['config-item-active']]: depth === 0 && firstActiveKey === index,
          })}
        >
          <AddItem
            width="100%"
            size="small"
            defaultValue={label}
            onOk={content => this[HandleSubmitAdd](depth, content)}
            onClose={() => this[HandleCloseAdd](depth)}
          />
        </li>
      )
    })

    dataDom.push(
      <li key="add-item" className={styles['config-item']}>
        {this[RenderAddItem](depth)}
      </li>,
    )

    return (
      <div className={styles['config-list-block']}>
        <div className={styles['config-header']}>
          <span className={styles['config-header-text']}>{headerTitle}</span>
        </div>
        <Spin spinning={loading}>
          <ul className={styles['config-list']}>{!loading && dataDom}</ul>
        </Spin>
      </div>
    )
  }

  render() {
    const { visible, submiting } = this.state

    return (
      <Modal
        title="差错选项配置"
        visible={visible}
        width={800}
        centered
        maskClosable={false}
        confirmLoading={submiting}
        onOk={this[HandleSubmit]}
        onCancel={() => this[HandleClose]()}
      >
        <div className={styles['config-wrapper']}>
          {this[RenderConfigList](0)}
          {this[RenderConfigList](1)}
        </div>
      </Modal>
    )
  }
}

export default connect(null, null, null, {
  withRef: true,
  forwardRef: true,
})(DiffCustomConfigInput)
