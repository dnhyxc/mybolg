import React from 'react'
import { Button } from 'antd'

import styles from './index.scss'

function PageFooter(props) {

  const { btnList } = props

  return (
    <div className={styles.pageFooter}>
      {
        (btnList || []).map((item, index) => (
          <Button key={index} {...item.otherProps} onClick={item.onClick} type={item.type || 'default'}>{item.text}</Button>
        ))
      }
    </div>
  )
}

export default PageFooter