/*
 * @Description: 段落权限弹窗
 * @Author: dnh
 * @Date: 2022-02-17 09:31:19
 * @LastEditTime: 2022-03-25 21:38:04
 * @LastEditors: dnh
 * @FilePath: \src\components\ParagraphModal\index.jsx
 */

import React, { useEffect, useState } from 'react'
import ReactDOM from 'react-dom'
import { Button, Modal, Checkbox, message, Spin } from 'antd'
import classNames from 'classnames'
import { OrgSelector } from '@xm/util'
import Service from 'ROOT/service/official'
import styles from './index.scss'

export const ParagraphPermissionsModal = ({
  url,
  name,
  width = 1170,
  callback,
  className,
  fileListData: fileListDataProps,
  centered = true,
  title = '段落权限设置',
}) => {
  const [visible, setVisible] = useState(true)
  const [activeList, setActiveList] = useState([])
  const [showSelectUser, setShowSelectUser] = useState(false)
  const [loading, setLoading] = useState(false)
  const [showUserId, setShowUserId] = useState(null)
  const [depList, setDepList] = useState([])
  const [orgList, setOrgList] = useState([])
  const [fileListData, setFileListData] = useState([])

  useEffect(() => {
    if (!fileListDataProps.length) {
      wordDocumentSplit()
    } else {
      setFileListData(fileListDataProps)
    }
  }, [fileListDataProps])

  // 上传/拆分接口
  const wordDocumentSplit = () => {
    setLoading(true)
    Service.wordDocumentSplit({
      url,
      name,
      // fileId,
      pageIndex: 1,
      pageSize: 9999,
    })
      .then(res => {
        const fileData = res.list.map(i => ({
          ...i,
          list: [],
        }))
        setFileListData(fileData)
        setLoading(false)
      })
      .catch(error => {
        message.error(error.message)
      })
  }

  // 处理段落选中逻辑
  const onSelected = _data => {
    const isActive = activeList.some(i => {
      if (i.id === _data.id) {
        return true
      }
      return false
    })
    if (isActive) {
      const res = activeList.filter(i => i.id !== _data.id)
      setActiveList(res)
    } else {
      const res = activeList.concat(_data)
      setActiveList(res)
    }
  }

  // 全选段落
  const onSelectAll = () => {
    if (activeList.length < fileListData.length) {
      setActiveList(fileListData)
    } else {
      setActiveList([])
    }
  }

  // 确定
  const onSubmit = () => {
    setVisible(false)
    setActiveList([])
    callback({
      fileListData,
      paragraph: fileListData,
    })
  }

  // 批量设置权限
  const onBatchSetting = () => {
    setShowSelectUser(true)
    setShowUserId(-1)
  }

  // 取消
  const onCancel = () => {
    setVisible(false)
    callback({ paragraph: fileListData, fileListData })
    setActiveList([])
  }

  // 选择部门/人
  const onSelectUser = (id, list) => {
    setShowSelectUser(true)
    setShowUserId(id)
    const deptList = list.filter(i => i.orgType === 2)
    const orgList = list.filter(i => i.orgType === 1)
    setOrgList(orgList)
    setDepList(deptList)
  }

  // 选人回调
  const handleConfirm = data => {
    const { depts, orgs } = data
    const list = [...depts, ...orgs]

    const ids = activeList.map(i => i.id)

    const fileData = fileListData.map(i => {
      if ((ids.indexOf(i.id) !== -1 && showUserId === -1) || i.id === showUserId) {
        i.list = list
      }
      return i
    })
    setFileListData([...fileData])
    setShowSelectUser(false)
    setActiveList([])
  }

  // 关闭选人
  const handleCancel = () => {
    setShowSelectUser(false)
  }

  return (
    <Modal
      visible={visible}
      width={width}
      title={title}
      onCancel={onCancel}
      centered={centered}
      footer={[
        <Button key="confirm" type="primary" onClick={onSubmit}>
          确定
        </Button>,
        <Button key="cancel" onClick={() => onCancel()}>
          取消
        </Button>,
      ]}
    >
      <Spin spinning={loading} style={{ maxHeight: '680px' }}>
        <div className={classNames(className, styles.container)}>
          <div className={styles.header}>
            <div className={styles.title}>
              <Checkbox
                checked={fileListData.length === activeList.length && activeList.length > 0}
                onClick={onSelectAll}
              />
              <div className={styles.text}>正文段落</div>
            </div>
            <div className={styles.action}>权限部门</div>
          </div>
          {fileListData.map(i => {
            return (
              <div className={styles.content} key={i.id}>
                <div
                  className={
                    activeList.map(j => j.id).includes(i.id)
                      ? classNames(styles.descWrap, styles.isActive)
                      : styles.descWrap
                  }
                >
                  <Checkbox
                    checked={activeList.map(i => i.id).includes(i.id)}
                    onClick={() => onSelected(i)}
                  />
                  {i.type === 1 ? (
                    <div className={styles.desc}>{i.text}</div>
                  ) : (
                    <img src={i.text} alt="" />
                  )}
                </div>
                <div className={styles.setAuth} onClick={() => onSelectUser(i.id, i.list)}>
                  {i.list && i.list.length
                    ? i.list.map(i => {
                        return `${i.name}、`
                      })
                    : '设置权限'}
                </div>
              </div>
            )
          })}
          <Button
            disabled={activeList.length <= 0}
            onClick={onBatchSetting}
            className={styles.setAllBtn}
          >
            批量设置权限
          </Button>
          {showSelectUser && (
            <OrgSelector
              visible={showSelectUser}
              onConfirm={handleConfirm}
              onCancel={handleCancel}
              defaultDeptList={depList}
              defaultOrgList={orgList}
            />
          )}
        </div>
      </Spin>
    </Modal>
  )
}

export default ({
  url,
  name,
  // fileId,
  width,
  callback,
  htmlCode,
  className,
  fileListData,
  title,
  centered,
  container,
}) => {
  let _ParagraphPermissions = { destroy: () => {} }
  let _container = document.body
  const defaultAppContainer = document.querySelector('.sub-app')
  if (container) {
    _container = container
  } else if (defaultAppContainer) {
    defaultAppContainer.style.position = 'relative'
    _container = defaultAppContainer
  }
  const div = document.createElement('div')
  _container.appendChild(div)
  ReactDOM.render(
    <ParagraphPermissionsModal
      url={url}
      name={name}
      htmlCode={htmlCode}
      // fileId={fileId}
      width={width}
      className={className}
      title={title}
      fileListData={fileListData}
      centered={centered}
      callback={callback}
    />,
    div,
  )
  _ParagraphPermissions.destroy = () => {
    ReactDOM.unmountComponentAtNode(div)
    div.remove()
    _ParagraphPermissions = null
  }
  return _ParagraphPermissions
}
