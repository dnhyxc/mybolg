/* eslint-disable no-unused-expressions */
import React, { useEffect } from 'react'
import { Link } from 'react-router-dom'
import { Button } from 'antd'
import XmiconReact from '@xm/icons-guangxicmcc-moa/dist/react'
import styles from './index.scss'

const PageContent = props => {
  const { title, onTitleClick, icon, iconColor, onIconClick, children, type } = props
  const handleTitleClick = () => {
    onTitleClick && onTitleClick()
  }
  const handleIconClick = () => {
    onIconClick && onIconClick()
  }
  useEffect(() => {
    return () => {}
  }, [])
  return (
    <div className={styles['header-card']}>
      <div className={styles.left}>
        {icon && (
          <div className={styles.icon} onClick={handleIconClick}>
            {type ? (
              <Button className={styles.backBtn}>
                <XmiconReact name={icon} size={16} />
                返回
              </Button>
            ) : (
              <XmiconReact name={icon} size={16} color={iconColor} />
            )}
          </div>
        )}
        {title && typeof title === 'string' && (
          <div className={styles.title} onClick={handleTitleClick}>
            {title}
          </div>
        )}
        {title && typeof title === 'object' && title.path && (
          <div>
            <Link to={title.path} className={styles.link}>
              {title.name}
            </Link>
            &nbsp;/&nbsp;<span className={styles.type}>{title.type}</span>
          </div>
        )}
      </div>
      <div className={styles.right}>{children}</div>
    </div>
  )
}

export default PageContent
