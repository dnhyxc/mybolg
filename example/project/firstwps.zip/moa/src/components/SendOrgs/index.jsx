import React, { useState, useEffect } from 'react'
import { Modal, message, Tree, Spin } from 'antd'
import { connect } from 'react-redux'
import ClassNames from 'classnames'
import service from 'ROOT/service'
import styles from './index.scss'

const { TreeNode } = Tree
const SendOrgs = props => {
  const { orgId, orgName, onClose, onSuccess, emptyText = '请从左侧选择组织或部门', id } = props
  const [checkedKeys, setCheckedKeys] = useState([])
  const [selectUsers, setSelectUsers] = useState([])
  const [OrgUserList, setOrgUserList] = useState([])
  const [loading, setLoading] = useState(false)

  const onCheck = checkedKeysValue => {
    setCheckedKeys(checkedKeysValue)
    const selectKeys = []
    for (let i = 0; i < checkedKeysValue.length; i++) {
      selectKeys.push(OrgUserList.find(item => item.id == checkedKeysValue[i]))
    }
    setSelectUsers(selectKeys)
  }

  const initState = () => {
    setCheckedKeys([])
    setSelectUsers([])
  }
  const handleCancelSecretSend = () => {
    initState()
    onClose && onClose()
  }
  const handleOkSecretSend = () => {
    if (selectUsers.length === 0) return message.error('请选择需要发文的公司')
    service
      .createDocumentOut({
        create: {
          id: Number(id),
          toOrgs: selectUsers.map(x => ({
            orgId: x.id,
            orgName: x.name,
          })),
          fromOrg: { orgId, orgName },
        },
      })
      .then(() => {
        message.success('发文成功')
        initState()
        onSuccess && onSuccess()
      })
  }
  const handleDeleteUser = id => {
    const newSelect = checkedKeys.filter(i => i != id)
    const delSelectusers = selectUsers.filter(d => d.id != id)
    setCheckedKeys(newSelect)
    setSelectUsers(delSelectusers)
  }
  const handleDelAllUser = () => {
    initState()
  }
  const initOrgListData = () => {
    setLoading(true)
    service
      .getOrgFilters({ orgIdFilters: [orgId], orgCodeFilters: ['33000000'] /* 区公司固定code */ })
      .then(res => {
        setLoading(false)
        setOrgUserList(res)
      })
      .finally(() => {
        setLoading(false)
      })
  }

  const handleRenderOrgTree = list => {
    if (Array.isArray(list) && list.length > 0) {
      return list.map(l => {
        return (
          <TreeNode
            checkable={l.level !== 0}
            key={l.id}
            icon={
              l.level === 2 ? (
                <span
                  className={ClassNames('iconfont icon-CombinedShape1', styles['tree-icon'])}
                  style={{ color: '#ffa400' }}
                />
              ) : (
                <span
                  className={ClassNames('iconfont icon-qiye1', styles['tree-icon'])}
                  style={{ color: l.level < 1 ? '#4f84d2' : '#23c172' }}
                />
              )
            }
            title={l.name}
          >
            {l.children && l.children.length > 0 && handleRenderOrgTree(l.children)}
          </TreeNode>
        )
      })
    }
    return []
  }

  useEffect(() => {
    initOrgListData()
  }, [])
  return (
    <Modal
      title="选择组织"
      visible
      onOk={handleOkSecretSend}
      onCancel={handleCancelSecretSend}
      width="750px"
      okText="确认"
      cancelText="取消"
      bodyStyle={{ padding: 0 }}
    >
      <div className={styles['selelct-warp']}>
        <div className={styles.tree}>
          {loading ? (
            <Spin className={styles.spin} />
          ) : (
            <Tree
              className={styles['user-tree']}
              checkable
              showIcon
              selectable={false}
              onCheck={onCheck}
              checkedKeys={checkedKeys}
            >
              {OrgUserList.length > 0 ? handleRenderOrgTree(OrgUserList) : null}
            </Tree>
          )}
        </div>
        <div className={styles.users}>
          <div className={styles['user-top']}>
            <div className="text">已选择的：</div>
            <div className={styles['all-clear']} onClick={handleDelAllUser}>
              清除
            </div>
          </div>
          <div className={styles['user-list']}>
            {selectUsers.length > 0 &&
              selectUsers.map(item => (
                <div className={styles['user-item']} key={item.id}>
                  {item.level === 2 ? (
                    <span
                      className={ClassNames('iconfont icon-CombinedShape1', styles['user-icon'])}
                      style={{ color: '#ffa400' }}
                    />
                  ) : (
                    <span
                      className={ClassNames('iconfont icon-qiye1', styles['user-icon'])}
                      style={{ color: item.level < 1 ? '#4f84d2' : '#23c172' }}
                    />
                  )}
                  <div className={styles['user-info']}>
                    <div className={styles.name}>{item.name}</div>
                  </div>
                  <span
                    className={ClassNames('iconfont icon-shanchu1', styles.close)}
                    onClick={() => {
                      handleDeleteUser(item.id)
                    }}
                  />
                </div>
              ))}
            {selectUsers.length === 0 && <div className={styles.empty}>{emptyText}</div>}
          </div>
        </div>
      </div>
    </Modal>
  )
}
export default connect(state => ({
  orgId: state.globalInfo.baseInfo.orgId,
  orgName: state.globalInfo.baseInfo.orgName,
}))(SendOrgs)
