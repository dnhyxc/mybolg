/* eslint-disable no-unused-expressions */
import React, { useState } from 'react'
import ClassNames from 'classnames'
import PropTypes from 'prop-types'
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import { Form, Input, Cascader, Select, DatePicker } from 'antd'
import { Tree } from '@xm/util'
import XmiconReact from '@xm/icons-guangxicmcc-moa/dist/react'
import { getYearList } from 'ROOT/utils'
import styles from './index.scss'

const { Option } = Select
const { RangePicker } = DatePicker
const SearchTerm = props => {
  const {
    type,
    label,
    value,
    cls,
    placeholder,
    onChange,
    options = [],
    children,
    orgId,
    orgName,
    title,
    chooseDept = false,
    range = 1,
    onChangeByTree,
  } = props
  const [isTreeShow, setIsTreeShow] = useState(false)
  const yearList = getYearList()
  const handleFromChange = (type, val) => {
    onChange && onChange(val)
  }
  const handleRefNoChange = (type, val) => {
    const refNoVal = [...value]
    if (type === 'word') {
      refNoVal[0] = val
    }
    if (type === 'year') {
      refNoVal[1] = val
    }
    if (type === 'number') {
      refNoVal[2] = val
    }
    onChange && onChange(refNoVal)
  }
  const handleSelectInputClick = () => {
    setIsTreeShow(true)
  }
  const handleTreeConfirmHandler = treeData => {
    onChange(treeData[0].name)
    onChangeByTree(treeData)
    setIsTreeShow(false)
  }
  const handleTreeCancelHandler = () => {
    setIsTreeShow(false)
  }

  const onlyDept = chooseDept
  const handleFilter = (inputValue, path) => {
    return path.some(option => option.label.toLowerCase().indexOf(inputValue.toLowerCase()) > -1)
  }
  return (
    <Form.Item className={ClassNames(styles['search-item'], cls)} label={label}>
      {type === 'input' && (
        <Input
          autoComplete="off"
          placeholder={placeholder}
          value={value}
          onChange={e => {
            handleFromChange('input', e.target.value)
          }}
        />
      )}
      {type === 'cascader' && (
        <Cascader
          options={options}
          value={value}
          changeOnSelect
          showSearch={handleFilter}
          expandTrigger="hover"
          onChange={(value, selectedOptions) => {
            handleFromChange('cascader', value)
          }}
          placeholder={placeholder}
        />
      )}
      {type === 'refNo' && (
        <div className={styles.refno}>
          <Input
            autoComplete="off"
            className={styles.word}
            placeholder="发文机关代字"
            value={value[0]}
            onChange={e => {
              handleRefNoChange('word', e.target.value)
            }}
          />
          <div className={styles.symbol}>[</div>
          <Select
            placeholder="年份"
            className={styles.year}
            value={value[1]}
            onChange={val => {
              handleRefNoChange('year', val)
            }}
            getPopupContainer={triggerNode => triggerNode.parentNode}
          >
            {yearList.length > 0 &&
              yearList.map(year => {
                return (
                  <Option key={year.value} value={year.value}>
                    {year.text}
                  </Option>
                )
              })}
          </Select>
          <div className={styles.symbol}>]</div>
          <Input
            autoComplete="off"
            className={styles.number}
            placeholder="序号"
            value={value[2]}
            onChange={e => {
              handleRefNoChange('number', e.target.value)
            }}
          />
        </div>
      )}
      {type === 'datePicker' && (
        <RangePicker
          className={styles.timer}
          allowClear
          value={value}
          placeholder={placeholder}
          onChange={val => {
            handleFromChange('datePicker', val)
          }}
        />
      )}
      {type === 'selectUser' && (
        <Input
          autoComplete="off"
          allowClear
          placeholder={placeholder}
          value={value}
          suffix={
            <span
              onClick={() => {
                handleSelectInputClick()
              }}
            >
              <XmiconReact name="down_line" />
            </span>
          }
          onChange={e => handleFromChange('selectUser', e.target.value, value)}
        />
      )}
      {type === 'selectDept' && (
        <Input
          autoComplete="off"
          allowClear
          placeholder={placeholder}
          value={value}
          suffix={
            <span
              onClick={() => {
                handleSelectInputClick()
              }}
            >
              <XmiconReact name="down_line" />
            </span>
          }
          onChange={e => handleFromChange('selectDept', e.target.value)}
        />
      )}
      {type === 'select' && (
        <Select
          placeholder={placeholder}
          value={value}
          className={ClassNames(styles.select, cls)}
          onChange={val => {
            handleFromChange('select', val)
          }}
          getPopupContainer={triggerNode => triggerNode.parentNode}
        >
          {options.length > 0 &&
            options.map(op => {
              return (
                <Option key={op.value} value={op.value}>
                  {op.label}
                </Option>
              )
            })}
        </Select>
      )}
      {children && children}
      {isTreeShow && (
        <Tree
          needSearchBar
          orgId={orgId}
          orgName={orgName}
          isShow={isTreeShow}
          title={title}
          choosedUser={[]}
          onConfirm={handleTreeConfirmHandler}
          onCancel={handleTreeCancelHandler}
          orgTree={{ add: true, isopen: true, chooseDept, onlyDept }}
          range={range}
          canBeNull
          self={{ canchoose: false, bechoosed: false }}
        />
      )}
    </Form.Item>
  )
}

export default connect(
  state => ({
    orgId: state.globalInfo.baseInfo.orgId,
    orgName: state.globalInfo.baseInfo.orgName,
  }),
  dispatch => ({
    actions: bindActionCreators({}, dispatch),
  }),
)(SearchTerm)
SearchTerm.propTypes = {
  type: PropTypes.string.isRequired,
  label: PropTypes.string.isRequired,
  cls: PropTypes.string,
  placeholder: PropTypes.string,
  onChange: PropTypes.func,
  options: PropTypes.array,
}
