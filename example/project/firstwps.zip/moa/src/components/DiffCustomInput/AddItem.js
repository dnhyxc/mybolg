import React, { PureComponent, createRef } from 'react'
import { Input, Button } from 'antd'
import cx from 'classnames'

import { stopPropagation } from 'ROOT/utils'

import styles from './add-item.scss'


class AddItem extends PureComponent {
  inputRef = createRef()

  state = {
    value: '',
  }

  componentDidMount() {
    if (this.inputRef.current) {
      this.inputRef.current.focus()
    }
    this.handleInit()
  }

  handleInit = () => {
    const { defaultValue = '' } = this.props
    this.setState({
      value: defaultValue,
    })
  }

  handleClick = (e) => {
    stopPropagation(e)

    if (e.target.tagName === 'INPUT' && this.inputRef.current) {
      this.inputRef.current.focus()
    }
  }

  handleFocus = (e) => {
    stopPropagation(e)

    if (this.inputRef.current) {
      this.inputRef.current.focus()
    }
  }

  handleChange = (e) => {
    const newValue = e.target.value
    this.setState({
      value: newValue,
    })
  }

  handleOk = () => {
    const { value } = this.state
    const { onOk } = this.props

    if (onOk instanceof Function) {
      onOk(value)
    }
  }

  handleCancel = () => {
    const { onClose } = this.props

    if (onClose instanceof Function) {
      onClose()
    }
  }

  render() {
    const { size = 'default', width } = this.props
    const { value } = this.state

    return (
      <span
        className={styles['add-item']}
        onClick={this.handleClick}
        style={width ? { width } : {}}
      >
        <Input
          autoComplete='off'
          ref={this.inputRef}
          size={size}
          className={styles['add-input']}
          value={value}
          onClick={this.handleClick}
          onChange={this.handleChange}
          onFocus={this.handleFocus}
        />
        <Button
          size={size}
          className={cx(
            styles['add-btn'],
            {
              [styles['add-btn-small']]: size === 'small',
            },
          )}
          onClick={this.handleOk}
        >
          <i className={cx(
            'iconfont icon-zhengque',
            styles['add-ok-icon'],
            {
              [styles['add-ok-icon-small']]: size === 'small',
            },
          )}
          />
        </Button>
        <Button
          size={size}
          className={cx(
            styles['add-btn'],
            {
              [styles['add-btn-small']]: size === 'small',
            },
          )}
          onClick={this.handleCancel}
        >
          <i className={cx(
            'iconfont icon-cuowu',
            styles['add-icon'],
            {
              [styles['add-icon-small']]: size === 'small',
            },
          )}
          />
        </Button>
      </span>
    )
  }
}

export default AddItem
