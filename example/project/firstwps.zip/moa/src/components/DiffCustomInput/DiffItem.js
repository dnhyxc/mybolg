import React, { PureComponent } from 'react'
import { Radio, Select, Input, message } from 'antd'
import cx from 'classnames'
import { completeNumByLen } from 'ROOT/utils'
import AddItem from './AddItem'
import styles from './index.scss'

const RadioGroup = Radio.Group
const SelectOption = Select.Option
const { TextArea } = Input

class DiffItem extends PureComponent {
  secondCacheKey = null

  secondCloseTimer = null

  state = {
    isAdd: false,
    secondOpen: false,
  }

  getBrText = (text = '') => {
    if (!text) {
      return '-'
    }

    return text.replace(/[\n\r]/g, '<br />')
  }

  getTargetData = () => {
    const { value, dataSource } = this.props
    const { field } = value || {}

    let curIndex = -1

    if (dataSource.length === 0) {
      return [null, curIndex]
    }

    const curFirstField = dataSource.find((item, index) => {
      if (item && item.value === field) {
        curIndex = index
        return true
      }
      return false
    })

    return [curFirstField, curIndex]
  }

  handleDelete = () => {
    const { index, onDelete } = this.props
    if (onDelete instanceof Function) {
      onDelete(index)
    }
  }

  handleSecondOpenChange = (secondOpen = true) => {
    if (secondOpen) {
      this.setState({
        secondOpen,
      })
      return
    }

    if (this.secondCacheKey === 'second-add') {
      this.secondCacheKey = null
      return
    }

    this.setState({
      secondOpen,
      isAdd: false,
    })
  }

  handleSecondOptionClick = ({ key }) => {
    this.secondCacheKey = key
  }

  handleSecondSelect = (key) => {
    this.secondCacheKey = key
  }

  handleAddOpen = () => {
    this.setState({
      isAdd: true,
    })
  }

  handleAddClose = () => {
    this.setState({
      isAdd: false,
    })
  }

  handleAddOk = (content) => {
    this.handleAddClose()
    const { onChangeDataSource } = this.props

    if (!(onChangeDataSource instanceof Function)) {
      console.error('请求函数未传啊')
      return
    }

    const newDataSource = [...this.props.dataSource]
    const [targetData, index] = this.getTargetData()

    if (!targetData) {
      message.error('目标一级错误不存在，添加错误')
      return
    }

    const curSubField = targetData.subFields || []
    curSubField.push(content)
    newDataSource[index].subFields = curSubField

    onChangeDataSource(newDataSource)
  }

  handleChange = (data) => {
    const { onChange, value: dataSource, index } = this.props
    if (onChange instanceof Function) {
      onChange(
        {
          ...dataSource,
          ...data,
        },
        index,
      )
    }
  }

  handleChangeFirst = (e) => {
    const { getDefaultField } = this.props
    const newValue = e.target.value
    const selectIndex = e.target.index

    const [_, subField] = getDefaultField(selectIndex)
    this.handleChange({
      field: newValue,
      subField,
    })
  }

  handleChangeSecond = (newValue) => {
    const { value } = this.props
    const { isAdd } = this.state
    const { field } = value || {}

    if (newValue === 'second-add') {
      if (!field) {
        message.warning('请先选择一级错误类型')
        return
      }
      if (!isAdd) {
        this.handleAddOpen()
      }
      return
    }

    this.handleChange({ subField: newValue })
  }

  handleChangeBeforeContent = (e) => {
    const newValue = e.target.value || ''

    this.handleChange({ errContent: newValue })
  }

  handleChangeAfterContent = (e) => {
    const newValue = e.target.value || ''

    this.handleChange({ correctContent: newValue })
  }

  handleChangeRemark = (e) => {
    const newValue = e.target.value || ''

    this.handleChange({ remark: newValue })
  }

  renderAddOptions = () => {
    const { isAdd } = this.state

    let addContent = (
      <span className={styles['add-second']}>
        <i className={cx('iconfont icon-jiahao', styles['add-second-icon'])} />
        新增选项
      </span>
    )

    if (isAdd) {
      addContent = (<AddItem
        onOk={this.handleAddOk}
        onClose={this.handleAddClose}
      />)
    }

    return (
      <SelectOption
        key="second-add"
        value="second-add"
        onClick={this.handleSecondOptionClick}
      >
        {addContent}
      </SelectOption>
    )
  }

  renderSecondOptions = () => {
    const [targetData] = this.getTargetData()

    const secondData = targetData ? targetData.subFields : []

    const options = secondData.map((item, index) => {
      return (
        <SelectOption
          key={index}
          value={item}
          onClick={this.handleSecondOptionClick}
        >
          {item}
        </SelectOption>
      )
    })

    options.push(this.renderAddOptions())

    return options
  }

  renderFirstData = () => {
    const { dataSource = [] } = this.props
    if (dataSource.length === 0) {
      return null
    }

    return dataSource.map((item, index) => {
      if (!item) {
        return null
      }
      const { value: label } = item || {}
      return (
        <Radio
          key={index}
          value={label}
          index={index}
        >
          {label}
        </Radio>
      )
    })
  }

  render() {
    const { value, index, readOnly } = this.props
    const { secondOpen } = this.state
    const { field, subField, errContent, correctContent, remark } = value || {}

    return (
      <div className={styles['diff-item']}>
        <div className={styles['item-header']}>
          <span className={styles['header-title']}>问题{completeNumByLen(index + 1 || 1)}</span>

          {!readOnly && (
            <div className={styles['header-actions']}>
              <a
                className={styles['header-actions-item']}
                onClick={this.handleDelete}
              >
                删除
              </a>
            </div>
          )}
        </div>
        {readOnly ? (
          <ul className={styles['item-body']}>
            <li className={styles['item-field']}>
              <span className={styles['item-field-label']}>错误类型：</span>
              <span className={styles['item-field-value']}>{field} / {subField}</span>
            </li>
            <li className={styles['item-field']}>
              <span className={styles['item-field-label']}>错误的内容：</span>
              <span
                className={cx(styles['item-field-value'], styles['item-field-value-before'])}
                // eslint-disable-next-line react/no-danger
                dangerouslySetInnerHTML={{
                  __html: this.getBrText(errContent || ''),
                }}
              />
            </li>
            <li className={styles['item-field']}>
              <span className={styles['item-field-label']}>订正后的内容：</span>
              <span
                className={cx(styles['item-field-value'], styles['item-field-value-after'])}
                // eslint-disable-next-line react/no-danger
                dangerouslySetInnerHTML={{
                  __html: this.getBrText(correctContent || ''),
                }}
              />
            </li>
            <li className={styles['item-field']}>
              <span className={styles['item-field-label']}>备注：</span>
              <span
                className={styles['item-field-value']}
                // eslint-disable-next-line react/no-danger
                dangerouslySetInnerHTML={{
                  __html: this.getBrText(remark || ''),
                }}
              />
            </li>
          </ul>
        ) : (
          <div className={styles['item-body']}>
            <RadioGroup
              value={field}
              onChange={this.handleChangeFirst}
            >
              {this.renderFirstData()}
            </RadioGroup>
            <Select
              className={styles['second-label']}
              onClick={this.handleSecondClick}
              open={secondOpen}
              onDropdownVisibleChange={this.handleSecondOpenChange}
              onSelect={this.handleSecondSelect}
              value={subField}
              onChange={this.handleChangeSecond}
              getPopupContainer={triggerNode => triggerNode.parentNode}
            >
              {this.renderSecondOptions()}
            </Select>

            <div className={styles['item-content']}>
              <div className={styles['content-block']}>
                <div className={cx(styles['content-label'], styles['content-label-before'])}>
                  错误的内容：
                </div>
                <TextArea
                  className={styles['content-textarea']}
                  value={errContent}
                  onChange={this.handleChangeBeforeContent}
                />
              </div>
              <div className={styles['content-block']}>
                <div className={cx(styles['content-label'], styles['content-label-after'])}>
                  订正后的内容：
                </div>
                <TextArea
                  className={styles['content-textarea']}
                  value={correctContent}
                  onChange={this.handleChangeAfterContent}
                />
              </div>
            </div>

            <div className={styles['item-remark']}>
              <div className={cx(styles['content-label'], styles['content-label-normal'])}>
                备注：
              </div>
              <TextArea
                maxLength={200}
                className={styles['remark-input']}
                value={remark}
                onChange={this.handleChangeRemark}
              />
            </div>
          </div>
        )}
      </div>
    )
  }
}

export default DiffItem
