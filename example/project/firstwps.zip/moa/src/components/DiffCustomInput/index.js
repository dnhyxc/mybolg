import React, { Component } from 'react'
import { Modal, Button, message, Spin } from 'antd'
import { connect } from 'react-redux'
import cx from 'classnames'
import Cookies from 'js-cookie'
import official from 'ROOT/service'
import { getSerialNumStrFromStr, safeJsonParse, getField, getFieldChild } from 'ROOT/utils'
import { FIELD_TYPE, OFFICIAL_TYPE_SEARCH_CASCADER, TYPE_IMGS } from 'ROOT/constant'
import DiffItem from './DiffItem'
import styles from './index.scss'

const RenderHeader = 'RenderHeader'
const RenderDiffList = 'RenderDiffList'
const GetFields = 'GetFields'
const GetInfos = 'GetInfos'
const GetDefaultField = 'GetDefaultField'
const HandleCheckData = 'HandleCheckData'
const HandleInitFieldValue = 'HandleInitFieldValue'
const HandleInitData = 'HandleInitData'
const HandleSubmitDataSource = 'HandleSubmitDataSource'
const HandleClose = 'HandleClose'
const HandleAfterClose = 'HandleAfterClose'
const HandleSubmit = 'HandleSubmit'
const HandleChange = 'HandleChange'
const HandleAdd = 'HandleAdd'
const HandleDelete = 'HandleDelete'
const HandleSaveCache = 'HandleSaveCache'
const HandleApplyCache = 'HandleApplyCache'

const DEFAULT_DIFFITEM = {
  field: '',
  subField: '',
  errContent: '',
  correctContent: '',
  remark: '',
}

const CACHE_DATA_NAME = '__diff_data__'

class DiffCustomInput extends Component {
  isCache = false

  state = {
    visible: false,
    loading: false,
    submiting: false,
    dataSource: [],
    diffList: [DEFAULT_DIFFITEM],
    data: null,
  }

  open = () => {
    const { readOnly } = this.props
    // if (!readOnly) {
    //   this[HandleApplyCache]()
    // }

    this[HandleInitData]()

    this.setState({
      visible: true,
    })
  };

  [GetFields] = () => {
    return new Promise(resolve => {
      official
        .getUserErrFields({})
        .then(res => {
          const { errFields = [] } = res || {}
          this.setState(
            {
              dataSource: errFields,
            },
            resolve,
          )
        })
        .catch(resolve)
    })
  };

  [GetInfos] = () => {
    const { id } = this.props

    return new Promise(resolve => {
      if (!id) {
        resolve()
        return
      }

      const params = {
        id,
      }

      official
        .getDocumentErrInfo(params)
        .then(res => {
          const { info } = res || {}
          if (!info) {
            return
          }
          const { errs = [] } = info || {}
          this.setState(
            {
              diffList: errs.length ? errs : [DEFAULT_DIFFITEM],
              data: info,
            },
            resolve,
          )
        })
        .catch(resolve)
    })
  };

  [GetDefaultField] = (firseFieldIndex = 0) => {
    const { dataSource = [] } = this.state

    if (dataSource.length === 0) {
      return ['', '']
    }

    const firstField = dataSource[firseFieldIndex]

    if (!firstField) {
      return ['', '']
    }

    const subField = (firstField.subFields || [])[0] || ''
    return [firstField.value, subField]
  };

  [HandleInitData] = () => {
    const { readOnly } = this.props
    this.setState({ loading: true })

    return Promise.all([!readOnly && this[GetFields](), !this.isCache && this[GetInfos]()]).finally(
      () => {
        this.setState({ loading: false })

        if (!readOnly) {
          this[HandleInitFieldValue]()
        }
      },
    )
  };

  [HandleInitFieldValue] = () => {
    const { diffList = [], dataSource = [] } = this.state
    if (dataSource.length === 0 || diffList.length === 0) {
      return
    }

    const [firstField, subField] = this[GetDefaultField]()

    const newDiffList = diffList.map(item => {
      const newItem = {
        ...item,
      }
      if (!item.field) {
        Object.assign(newItem, {
          field: firstField,
          subField,
        })
      }
      return newItem
    })

    this.setState({
      diffList: newDiffList,
    })
  };

  [HandleSubmitDataSource] = (newDataSource = []) => {
    const params = {
      errFields: newDataSource,
    }
    return official.setUserErrFields(params).then(() => {
      message.success('添加问题点成功')
      this[GetFields]()
    })
  };

  [HandleApplyCache] = () => {
    const { id } = this.props
    const cacheData = safeJsonParse(Cookies.get(CACHE_DATA_NAME), {})
    const currentData = cacheData[id]

    if (!currentData) {
      this[HandleInitData]()
      return
    }

    this[HandleInitData](true).then(() => {
      delete cacheData[id]
      Cookies.set(CACHE_DATA_NAME, cacheData)
      this.setState({
        diffList: currentData,
      })
    })
  };

  [HandleSaveCache] = callback => {
    // const { id } = this.props
    const { diffList = [] } = this.state
    const hasContent = diffList.some(item => {
      if (!!item.errContent || !!item.correctContent || !item.remark) {
        return true
      }
      return false
    })
    if (!hasContent) {
      return callback()
    }

    // const cacheData = safeJsonParse(Cookies.get(CACHE_DATA_NAME), {})

    Modal.confirm({
      title: '是否保留已编辑的内容？',
      content: '保留已编辑的内容后，再次录入该公文的差错，则可以继续编辑之前已录入的内容',
      okText: '确定',
      cancelText: '取消',
      onCancel: () => {
        // if (cacheData[id]) {
        //   delete cacheData[id]
        // }
        // Cookies.set(CACHE_DATA_NAME, cacheData)
        this.isCache = false
        callback()
      },
      onOk: () => {
        // cacheData[id] = diffList
        // Cookies.set(CACHE_DATA_NAME, cacheData)
        this.isCache = true
        callback()
      },
    })
  };

  [HandleClose] = (_, isSubmit = false) => {
    const { readOnly } = this.props
    if (readOnly || isSubmit) {
      this.isCache = false
      this.setState({
        visible: false,
      })
      return
    }
    this[HandleSaveCache](() => {
      this.setState({
        visible: false,
      })
    })
  };

  [HandleAfterClose] = () => {
    if (this.isCache) {
      return
    }
    this.setState({
      diffList: [DEFAULT_DIFFITEM],
    })
  };

  [HandleCheckData] = (diffList = []) => {
    if (diffList.length === 0) {
      return false
    }

    return diffList.some(item => {
      if (!item) {
        return true
      }
      if (!item.field || !item.subField || !item.errContent || !item.correctContent) {
        return true
      }
      return false
    })
  };

  [HandleSubmit] = () => {
    const { id, readOnly } = this.props
    const { diffList = [] } = this.state

    if (readOnly) {
      this[HandleClose]()
      return
    }

    const newDiffList = diffList.map(item => {
      return {
        ...item,
        errContent: (item.errContent || '').trim(),
        correctContent: (item.correctContent || '').trim(),
        remark: (item.remark || '').trim(),
      }
    })

    if (this[HandleCheckData](newDiffList)) {
      message.error('差错公文填写不完整，请补充')
      return
    }

    this.setState({
      submiting: true,
    })

    const params = {
      id,
      errs: newDiffList,
    }
    official
      .setDocumentErrInfo(params)
      .then(() => {
        this[HandleClose](null, true)
        message.success('差错公文提交成功')
      })
      .finally(() => {
        this.setState({
          submiting: false,
        })
      })
  };

  [HandleChange] = (data, index) => {
    const { diffList = [] } = this.state
    const newDiffList = [...diffList]

    newDiffList[index] = data

    this.setState({
      diffList: newDiffList,
    })
  };

  [HandleAdd] = () => {
    const { diffList = [] } = this.state
    const newDiffList = [...diffList]

    const [firstField, subField] = this[GetDefaultField]()

    newDiffList.push({
      ...DEFAULT_DIFFITEM,
      field: firstField,
      subField,
    })

    this.setState({
      diffList: newDiffList,
    })
  };

  [HandleDelete] = index => {
    const { diffList = [] } = this.state

    if (diffList.length === 1) {
      message.warning('差错公文至少录入一条')
      return
    }

    const newDiffList = [...diffList]

    newDiffList.splice(index, 1)

    this.setState({
      diffList: newDiffList,
    })
  };

  [RenderHeader] = () => {
    const {
      fields = [],
      readOnly,
      dataSource = null,
      // readOnlyDepartmentName,
    } = this.props

    let officialTitle = '-'
    let refNo = '-'
    let firstDept = '-'
    let { officialType } = this.props
    if (readOnly) {
      if (dataSource) {
        officialTitle = dataSource.title
        refNo = dataSource.refNo
        firstDept = dataSource.deptName
        officialType = dataSource.type
      }
    } else {
      officialTitle = getFieldChild(fields, FIELD_TYPE.TITLE).value
      const refValue = getFieldChild(fields, FIELD_TYPE.REF_NO || FIELD_TYPE.RECEIPT_REF_NO)
      refNo = refValue ? getSerialNumStrFromStr(refValue.value) : ''
      const firstDeptField = getFieldChild(fields, 'fileDepartment')
      firstDept = firstDeptField.value
    }
    return (
      <div className={styles['diff-header']}>
        <div className={styles['type-icon']}>
          <img alt="" src={TYPE_IMGS[officialType]} />
        </div>
        <div className={styles['header-introduction']}>
          <div className={styles['introduction-title']}>{officialTitle}</div>
          <div className={styles['introduction-description']}>
            <span className={styles['description-item']}>文号：{refNo || '-'}</span>
            <span className={styles['description-item']}>
              类型：
              {(OFFICIAL_TYPE_SEARCH_CASCADER[officialType] &&
                OFFICIAL_TYPE_SEARCH_CASCADER[officialType].label) ||
                '-'}
            </span>
            <span className={styles['description-item']}>部门：{firstDept || '-'}</span>
          </div>
        </div>
      </div>
    )
  };

  [RenderDiffList] = () => {
    const { dataSource: dataDetail, readOnly } = this.props
    const { dataSource } = this.state

    let diffList = []
    if (readOnly) {
      if (dataDetail) {
        diffList = dataDetail.errs || []
      }
    } else {
      diffList = this.state.diffList
    }

    if (diffList.length === 0) {
      return null
    }
    return diffList.map((item, index) => {
      return (
        <DiffItem
          key={index}
          index={index}
          dataSource={dataSource}
          value={item}
          readOnly={readOnly}
          getDefaultField={this[GetDefaultField]}
          onChange={this[HandleChange]}
          onDelete={this[HandleDelete]}
          onChangeDataSource={this[HandleSubmitDataSource]}
        />
      )
    })
  }

  render() {
    const { readOnly = false } = this.props
    const { visible, loading, submiting } = this.state

    return (
      <Modal
        centered
        title={readOnly ? '公文差错详情' : '公文差错录入'}
        visible={visible}
        confirmLoading={submiting}
        width={800}
        onOk={this[HandleSubmit]}
        onCancel={this[HandleClose]}
        afterClose={this[HandleAfterClose]}
      >
        <div className={styles['diff-body']}>
          {this[RenderHeader]()}

          <div className={styles['diff-list']}>
            <Spin spinning={loading}>{!loading && this[RenderDiffList]()}</Spin>

            {!readOnly && (
              <Button
                className={styles['diff-add']}
                type="dashed"
                size="large"
                onClick={this[HandleAdd]}
              >
                <i className={cx('iconfont icon-jiahao', styles['diff-add-icon'])} />
                添加问题点
              </Button>
            )}
          </div>
        </div>
      </Modal>
    )
  }
}

export default connect(null, null, null, {
  withRef: true,
  forwardRef: true,
})(DiffCustomInput)
