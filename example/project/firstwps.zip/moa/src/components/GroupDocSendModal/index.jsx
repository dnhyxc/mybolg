import React, { useState, useEffect } from 'react'
import { Modal } from 'antd'
import SendOrgFile from 'ROOT/components/SendOrgFile'
import MainDelivery from 'ROOT/components/OfficialContent/AddDocumentComponent/MainDelivery' // 主送
import CopyDelivery from 'ROOT/components/OfficialContent/AddDocumentComponent/CopyDelivery' // 抄送
import { FIELD_TYPE } from 'ROOT/constant'
import { cloneDeep } from 'lodash'

export default props => {
  const {
    title = '集团发文',
    onClose,
    id,
    fields = [],
    renderNeedData,
    onSuccess,
    deptId,
    redheadTemplates,
    documentTemplate,
  } = props
  const {
    form: { getFieldValue, getFieldDecorator, setFieldsValue, validateFields },
  } = renderNeedData

  const [mainSendField, setMainSendField] = useState({})
  const [copySendField, setCopySendField] = useState({})
  const getFieldByFieldName = (fields = [], fieldName) => {
    let field = {}
    fields.forEach(x => {
      if (x.isCard) {
        x.children.forEach(y => {
          if (y.fieldName === fieldName) {
            field = y
          }
        })
      }
      if (x.fieldName === fieldName) {
        field = x
      }
    })
    return field
  }
  const init = () => {
    const newFields = cloneDeep(fields)
    const mainSendField = getFieldByFieldName(newFields, FIELD_TYPE.MAIN_SEND)
    const copySendField = getFieldByFieldName(newFields, FIELD_TYPE.COPY_SEND)
    setMainSendField(mainSendField)
    setCopySendField(copySendField)
  }
  useEffect(() => {
    init()
  }, [])

  const [isShow, setIshow] = useState(false)
  const handleOk = () => {
    validateFields([FIELD_TYPE.MAIN_SEND, FIELD_TYPE.COPY_SEND], (err, values) => {
      mainSendField.value = values[FIELD_TYPE.MAIN_SEND]
      copySendField.value = values[FIELD_TYPE.COPY_SEND]
      setMainSendField(mainSendField)
      setCopySendField(copySendField)
    })
    setIshow(true)
  }
  return (
    <div>
      <Modal visible onOk={handleOk} onCancel={onClose} title={title}>
        {mainSendField.fieldName && (
          <MainDelivery
            data={mainSendField}
            getFieldValue={getFieldValue}
            getFieldDecorator={getFieldDecorator}
            setFieldsValue={setFieldsValue}
            access="WRITE"
            type="ADD"
            id={documentTemplate.id}
          />
        )}
        {copySendField.fieldName && (
          <CopyDelivery
            data={copySendField}
            getFieldValue={getFieldValue}
            getFieldDecorator={getFieldDecorator}
            setFieldsValue={setFieldsValue}
            access="WRITE"
            type="ADD"
            id={documentTemplate.id}
          />
        )}
      </Modal>
      <SendOrgFile
        fields={fields}
        mainSendField={mainSendField}
        copySendField={copySendField}
        id={id}
        visible={isShow}
        deptId={deptId}
        redheadTemplates={redheadTemplates}
        onClose={() => {
          setIshow(false)
        }}
        onSuccess={onSuccess}
      />
    </div>
  )
}
