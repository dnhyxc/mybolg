import React, { useState, useCallback, useEffect } from 'react'
import { Modal, Form, Input } from 'antd'

// import usePrevious from 'ROOT/hooks/usePrevious'

const formItemLayout = {
  labelCol: { span: 4 },
  wrapperCol: { span: 18 },
}

const RenameModal = (props) => {
  const {
    visible = false,
    dataSource = null,
    onOk,
    onCancel,
  } = props
  // const prevVisible = usePrevious(visible)
  const prevVisible = visible
  const [name, setName] = useState('')
  const [suffix, setSuffix] = useState('')

  useEffect(
    () => {
      // if (visible && !prevVisible) {
      if (visible) {
        const prevName = dataSource.name || ''
        const [_, newName] = prevName.match(/([\s\S]*)\.[^.]+$/i) || []
        setName(newName || '')
        setSuffix(prevName.replace(newName || '', ''))
      }
    },
    // [dataSource, prevVisible, visible],
    [dataSource, visible],
  )

  const handleChangeName = useCallback(
    (e) => {
      setName(e.target.value)
    },[])

  const handleOk = useCallback(
    () => {
      if (!(onOk instanceof Function)) {
        return
      }

      console.log(`${name.trim()}${suffix}`, 'ppppp');

      onOk(`${name.trim()}${suffix}`)
    },
    [name, onOk, suffix],
  )

  const afterClose = useCallback(
    () => {
      setName('')
    },
    [],
  )

  return (
    <Modal
      title="重命名"
      visible={visible}
      onOk={handleOk}
      onCancel={onCancel}
      afterClose={afterClose}
      okText="确认"
      cancelText="取消"
    >
      <Form.Item
        {...formItemLayout}
        label="文件名"
      >
        <Input
          autoComplete='off'
          placeholder="请输入文件名"
          value={name}
          onChange={handleChangeName}
        />
      </Form.Item>
    </Modal>
  )
}

export default RenameModal
