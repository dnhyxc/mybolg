/*
 * @Description: 详情页
 * @Author: dnh
 * @Date: 2022-02-10 17:47:46
 * @LastEditTime: 2022-03-30 10:55:50
 * @LastEditors: dnh
 * @FilePath: \src\components\OfficialContent\index.jsx
 */
import React, { useState, useEffect, useRef } from 'react'
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import { Form, Row, Col, message, Spin, Modal } from 'antd'
import { globalStore } from '@xm/util'
import { cloneDeep } from 'lodash'
import { onFormValueChange, setDetailFields } from 'ROOT/reducer/global'
import XmiconReact from '@xm/icons-guangxicmcc-moa/dist/react'
import service from 'ROOT/service'
import PageHeader from 'ROOT/components/PageHeader'
import PageContent from 'ROOT/components/PageContent'
import { getField, downloadFile, isArray, indexOf, getSearchParam } from 'ROOT/utils'
import { getWpsFieldValue } from 'ROOT/utils/manageFieldValue'
import { FIELD_TYPE } from 'ROOT/constant'
import ClassifiedModal from 'ROOT/components/ClassifiedModal'
import RenderPdf from 'ROOT/components/RenderPdf'
// import BodyFileEmpty from 'ROOT/components/RenderPdf/BodyFileEmpty'
import DiffCustomInput from 'ROOT/components/DiffCustomInput'
import { Buttons, Steps } from 'ROOT/components/OfficialContent/Buttons'
import FileRender from 'ROOT/components/FileRender'
import OneDistribution from 'ROOT/views/CreateDocument/Components/OneDistribution' // 一键分发
import GroupDocSendModal from 'ROOT/components/GroupDocSendModal' // 集团发文
import SendOrgs from 'ROOT/components/SendOrgs' // 发送其他市公司
import DocReceiveStatusModal from 'ROOT/components/DocReceiveStatusModal' // 查看公文接受状态

import styles from './index.scss'

const formItemLayout = {
  labelCol: {
    xs: { span: 8 },
    sm: { span: 2 },
  },
  wrapperCol: {
    xs: { span: 24 },
    sm: { span: 22 },
  },
}

const MyDocument = ({
  history,
  collapsed,
  isFormValueChange,
  actions,
  detailFields,
  orgName,
  ...props
}) => {
  const [documentDetail, setDocumentDetail] = useState({})
  const [formDataSource, setFormDataSource] = useState([])
  const [access, setAccess] = useState({}) // 字段权限（只读｜可写｜隐藏）
  const [refNoDataSource, setRefNoDataSource] = useState([])
  const [bodyFileUploadUrl, setBodyFileUploadUrl] = useState('')
  const [bodyFileList, setBodyFileList] = useState([])
  const [isShowClassified, setIsShowClassified] = useState(false)
  const [oneDistribution, setOneDistribution] = useState(false) // 一键分发状态
  const [errFields, setErrFields] = useState([])
  const [mainUser, setMainUser] = useState([])
  const [otherUsers, setOtherUsers] = useState([])
  const [copyUser, setCopyUser] = useState([])
  const [userLoading, setUserLoading] = useState(false)
  const [deptData, setdeptData] = useState({})
  const [isShowGroupDocSend, setIsShowGroupDocSend] = useState(false)
  const [isShowOtherOrgsSend, setIsShowOtherOrgsSend] = useState(false)
  const [isShowDocReceive, setIsShowDocReceive] = useState(false)
  const [previewIndex, setPreviewIndex] = useState(0)
  const [backToTop, setBackToTop] = useState(false)
  // const [reflash, setReflash] = useState(false)
  const [loading, setLoading] = useState(false)
  const [headerTitle, setHeaderTitle] = useState('')
  const [redheadTemplates, setRedheadTemplates] = useState([])
  const [isOperate, setIsOperate] = useState(false)
  const [completeInfosList, setCompleteInfosList] = useState([])
  // const [secretClassStatus, setSecretClassStatus] = useState(4)
  const [fullDepartment, setFullDepartment] = useState('')
  const [formType, setFormType] = useState(1)
  const [eventTimeList, setEventTimeList] = useState([])
  const [contentWidth, setContentWidth] = useState(0)

  // const [informerInfoList, setInformerInfoList] = useState([])
  const { setFields, setFieldsValue, getFieldValue, validateFieldsAndScroll } = props.form
  const {
    match: {
      params: { id: tlpId },
    },
  } = props

  const procFormDataKey = getSearchParam('procFormDataKey') || null // 需要获取模板字段的id

  const detailId = tlpId || procFormDataKey

  const orgId = globalStore.get('orgId')
  const deptList = globalStore.get('deptList')

  const diffRef = useRef(null)
  const btnsRef = useRef(null)
  const contentRef = useRef(null)
  const renderPdfRef = useRef(null)

  useEffect(() => {
    const currentNode = btnsRef.current
    if (
      deptData.value &&
      formDataSource.length &&
      btnsRef &&
      currentNode &&
      currentNode.children &&
      currentNode.children.length &&
      currentNode.children[0] &&
      currentNode.children[0].children &&
      currentNode.children[0].children.length
    ) {
      if (collapsed) {
        btnsRef.current.children[0].children[0].classList.add('full')
      } else {
        btnsRef.current.children[0].children[0].classList.remove('full')
      }
    }
  }, [deptData.value, formDataSource.length, collapsed])

  useEffect(() => {
    getDept()
  }, [])

  useEffect(() => {
    getDocumentDetail()
  }, [detailId])

  // 监听content滚动事件
  useEffect(() => {
    if (!bodyFileUploadUrl || !contentRef.current || !renderPdfRef.current) return

    setContentWidth(contentRef.current.offsetWidth)

    contentRef.current.addEventListener('scroll', () => {
      const { scrollTop, clientHeight, scrollHeight } = contentRef.current
      const { offsetTop } = renderPdfRef.current
      if (scrollTop + clientHeight === scrollHeight) {
        setBackToTop(true)
      }
      if (scrollTop > offsetTop) {
        setBackToTop(true)
      }
      if (scrollTop < offsetTop && scrollTop + clientHeight !== scrollHeight) {
        setBackToTop(false)
      }
    })
    return () => {
      contentRef.current.removeEventListener('scroll', () => {}, false)
    }
  }, [bodyFileUploadUrl])

  // 滚动到正文
  const onScrollToBodyFileOrTop = () => {
    if (!contentRef.current || !renderPdfRef.current) return
    const { scrollTop, clientHeight, scrollHeight } = contentRef.current
    const { offsetTop } = renderPdfRef.current
    if (scrollTop + clientHeight === scrollHeight) {
      contentRef.current.scrollTop = 0
    }
    if (scrollTop > offsetTop) {
      contentRef.current.scrollTop = 0
    }
    if (scrollTop < offsetTop && scrollTop + clientHeight !== scrollHeight) {
      contentRef.current.scrollTop = renderPdfRef.current.offsetTop
    }
  }

  // 编辑表单保存
  const modDocumentFields = reload => {
    let formFieldsValue = []
    validateFieldsAndScroll((err, values) => {
      if (!err) {
        const res = getFieldsValue(values)
        formFieldsValue = res
      }
    })
    if (formFieldsValue.length === 0) return
    service
      .modDocumentFields({
        orgId,
        id: detailId,
        fields: formFieldsValue,
      })
      .then(() => {
        if (reload === 'reload') {
          window.location.reload()
        }
        // getDocumentDetail()
      })
  }

  useEffect(() => {
    window.addEventListener('process', e => {
      switch (e.detail.type) {
        case 'started': // 启动后
          break
        case 'approved': // 审批后
          // setReflash(true)
          modDocumentFields('reload')
          break
        case 'added': // 加签后
          modDocumentFields('reload')
          break
        case 'stoped': // 终止后
          modDocumentFields('reload')
          break
        case 'rejected': // 退回后
          modDocumentFields('reload')
          break
        case 'forworded': // 转交后
          modDocumentFields('reload')
          break
        case 'cced': // 抄送后
          modDocumentFields('reload')
          break
        case 'completed': // 完成
          modDocumentFields('reload')
          break
        default:
      }
    })
  }, [formDataSource])

  // 获取公文详情
  const getDocumentDetail = () => {
    setLoading(true)
    service
      .getDocumentDetail({
        orgId,
        id: detailId,
      })
      .then(res => {
        setLoading(false)
        setEventTimeList(res.info.actions)
        setRedheadTemplates(res.info.documentTemplate.redHeadFile)
        setDocumentDetail(res.info)
        setFormDataSource(res.info.fields)
        const data = getWpsFieldValue(res.info.fields)
        actions.setDetailFields(data)
        setFormType(res.info.type)
        setIsOperate(res.info.isOperate)
        const bodyFile = res.info.fields.filter(i => i.fieldName === 'bodyFile')
        const title = res.info.fields.filter(i => i.fieldName === 'title')
        if (title && title.length) {
          setHeaderTitle(title[0].value)
        }
        if (bodyFile.length && bodyFile[0].value) {
          const file = getFileListFromProps(bodyFile[0].value)
          if (Object.prototype.toString.call(file) === '[object Object]') {
            setBodyFileList([...file])
            // setBodyFileUploadUrl(file.url)
            setBodyFileUploadUrl(file.originalUrl)
          }
          if (file.length) {
            setBodyFileList(file)
            // setBodyFileUploadUrl(file[0].url)
            setBodyFileUploadUrl(file[0].originalUrl)
          }
        }
      })
  }

  // 获取正文fileList
  const getFileListFromProps = value => {
    try {
      return JSON.parse(value)
    } catch (error) {
      return []
    }
  }

  // 获取拟稿部门及后续接口获取
  const getDept = () => {
    const deptData =
      deptList && deptList.length > 0
        ? {
            value: deptList[0].id,
            label: deptList[0].name,
          }
        : {
            value: 0,
            label: 0,
          }
    getRefNoDataSource(deptData.value)
    setdeptData(deptData)
    service.getOrgDeptPath({ deptId: deptData.value }).then(res => {
      setFullDepartment(res)
      setFieldsValue({ fileDepartment: res })
    })
  }

  // 获取发文机关代字列表
  const getRefNoDataSource = deptId => {
    service
      .getRefNoListByUser({
        orgId,
        deptId: deptId || 0,
        templateId: detailId,
      })
      .then(res => {
        setRefNoDataSource(res.refNos)
      })
  }

  const handleCloseClassifiedModal = () => setIsShowClassified(false)
  const classifiedCallback = () => setIsShowClassified(true)

  // 密集清单确认
  const onChangeClassifiedValue = (value = []) => {
    const {
      secretClass = '', // 密级清单-密级
      secretTime = '', // 密级清单-保密期限
    } = value && value[0]
    let secretClassOptions = [] // 密级枚举
    let secrecyTermOptions = [] // 保密期限枚举

    // 当枚举列表没有当前value时，变换处理枚举
    const setFormat = (i, value, options, key) => {
      // 查找对应的枚举对象
      const obj = options.find(item => item.text === value)
      if (obj) {
        // 找到则直接赋值
        setFields({ [key]: { value: obj.value } })
        return i
      }
      // 找不到，则先判断是否有 -1 选项
      const obj1 = options.find(item => item.value === -1)
      if (obj1) {
        obj1.text = value
      }
      setFields({ [key]: { value: -1, text: value } })
      return {
        ...i,
        property: JSON.stringify({
          ...JSON.parse(i.property),
          // 有-1选项替换text值，没有则新增-1选项
          options: obj1 ? options : [{ value: -1, text: value }, ...options],
        }),
      }
    }

    const newData = JSON.parse(JSON.stringify(formDataSource))

    // 改变数据源
    const newFormDataSource = (newData || []).map(item => {
      // 先判断是否为分栏容器，分栏容器遍历children
      if (item.fieldName === 'rowCard') {
        // 判断是否为密级或保密期限，查找对应枚举值 setFormat
        const newChild = JSON.parse(JSON.stringify(item.children))
        const newItem = (newChild || []).map(i => {
          if (i.fieldName === 'secretClass') {
            // 密级
            secretClassOptions = JSON.parse(i.property).options
            return setFormat(i, secretClass, secretClassOptions, 'secretClass')
          }
          if (i.fieldName === 'secrecyTerm') {
            // 保密期限
            secrecyTermOptions = JSON.parse(i.property).options
            return setFormat(i, secretTime, secrecyTermOptions, 'secrecyTerm')
          }
          return i
        })
        return {
          ...item,
          children: newItem,
        }
      }
      // 不是分栏容器，直接判断是否为密级或保密期限，查找对应枚举值 setFormat
      if (item.fieldName === 'secretClass') {
        // 密级
        secretClassOptions = JSON.parse(item.property).options
        return setFormat(item, secretClass, secretClassOptions, 'secretClass')
      }
      if (item.fieldName === 'secrecyTerm') {
        // 保密期限
        secrecyTermOptions = JSON.parse(item.property).options
        return setFormat(item, secretTime, secrecyTermOptions, 'secrecyTerm')
      }
      return item
    })

    // 覆盖数据源
    setFormDataSource(newFormDataSource)
    handleCloseClassifiedModal()
  }

  const oneDistributionOk = () => {
    if (!completeInfosList.length && !otherUsers.length) {
      message.info('没有人员可进行一键分发')
      return
    }
    let complatePromise = null
    let createDocumentOutPromise = null
    if (completeInfosList.length > 0) {
      const params = {
        taskId: documentDetail.taskId,
        manualCompleteInfos: completeInfosList,
        // informerInfo: informerInfoList,
      }
      complatePromise = service.complate(params)
      // .then(() => {
      //   message.success('一键分发成功')
      //   // window.location.reload()
      //   setOneDistribution(false)
      // })
      // .finally(() => setUserLoading(false))
    }
    if (otherUsers.length > 0) {
      createDocumentOutPromise = service.createDocumentOut({
        create: {
          id: Number(detailId),
          toOrgs: otherUsers.map(x => ({
            orgId: x.orgId,
            orgName: x.orgName,
          })),
          fromOrg: { orgId, orgName },
        },
      })
    }

    if (
      Object.prototype.toString.call(complatePromise) === '[object Promise]' &&
      Object.prototype.toString.call(createDocumentOutPromise) === '[object Promise]'
    ) {
      Promise.all([complatePromise, createDocumentOutPromise])
        .then(([res1, res2]) => {
          if (res1 && res2) {
            message.success('一键分发成功')
            window.location.reload()
            setOneDistribution(false)
          }
        })
        .finally(() => setUserLoading(false))
    }
    if (
      Object.prototype.toString.call(complatePromise) === '[object Promise]' &&
      Object.prototype.toString.call(createDocumentOutPromise) === '[object Null]'
    ) {
      complatePromise
        .then(res => {
          if (res) {
            message.success('一键分发成功')
            window.location.reload()
            setOneDistribution(false)
          }
        })
        .finally(() => setUserLoading(false))
    }
    if (
      Object.prototype.toString.call(createDocumentOutPromise) === '[object Promise]' &&
      Object.prototype.toString.call(complatePromise) === '[object Null]'
    ) {
      createDocumentOutPromise
        .then(res => {
          if (res) {
            setOneDistribution(false)
            window.location.reload()
          }
        })
        .finally(() => setUserLoading(false))
    }
  }

  const oneDistributionCancel = () => {
    setOneDistribution(false)
    setUserLoading(false)
  }

  const getOneKeySenderUsers = actinstId => {
    const params = {
      orgId: globalStore.get('orgId'),
      // orgId: 10032,
      id: detailId,
    }
    service.getOneKeySenderUsers(params).then(data => {
      const { coUsers = [], hostUsers = [], otherUsers = [] } = data || {}
      const completeInfos = []
      const hostUsersList = hostUsers
        .filter(sub => !otherUsers.some(x => x.uid === sub.uid))
        .map(x => ({ id: x.uid, name: x.name, orgId: x.orgId })) // 走流程引擎时过滤掉收文登记员
      const coUsersList = coUsers
        .filter(sub => !otherUsers.some(x => x.uid === sub.uid))
        .map(x => ({ id: x.uid, name: x.name, orgId: x.orgId }))
      const obj = {}
      const newOtherUsers = otherUsers.reduce((item, next) => {
        // eslint-disable-next-line no-unused-expressions
        obj[next.orgId] ? '' : (obj[next.orgId] = true && item.push(next))
        return item
      }, [])
      actinstId.forEach(item => {
        if (item.actinstName.indexOf('主办') !== -1 || item.actinstName.indexOf('收办') !== -1) {
          const obj = {
            assigneeInfo: {
              assignees: hostUsersList,
            },
            actinstId: item.id,
          }
          if (hostUsersList.length) {
            completeInfos.push(obj)
          }
        }
        if (
          item.actinstName.indexOf('传阅') !== -1 ||
          (item.actinstName.indexOf('收阅') !== -1 && item.actinstName !== '公司领导收阅')
        ) {
          const obj = {
            assigneeInfo: {
              assignees: coUsersList,
            },
            actinstId: item.id,
          }
          if (coUsersList.length) {
            completeInfos.push(obj)
          }
        }
      })
      setCompleteInfosList(completeInfos)
      setUserLoading(false)
      setCopyUser(coUsers)
      setMainUser(hostUsers)
      setOtherUsers(newOtherUsers)
    })
  }

  const getActionList = () => {
    const params = {
      taskId: documentDetail.taskId,
      varJson: '',
    }
    service.getActionList(params).then(data => {
      const actionIdList = data.map(item => ({
        actinstName: item.actinstName,
        id: item.id,
      }))
      getOneKeySenderUsers(actionIdList)
    })
  }

  // wps编辑正文回调
  const onWpsContentChange = async fileList => {
    setFieldsValue({
      bodyFile: fileList,
    })
    // setBodyFileUploadUrl(fileList[0].url)
    setBodyFileUploadUrl(fileList[0].originalUrl)
    setBodyFileList(fileList)
  }

  // 获取正文上传的文件
  const getUploadBodyFile = fileList => {
    // setBodyFileUploadUrl(fileList.url)
    setBodyFileUploadUrl(fileList.originalUrl)
    setFieldsValue({
      bodyFile: [fileList],
    })
  }

  // 底部buttons配置，onClick回调等
  const customButtons = [
    {
      key: 'ccgw', // 差错公文
      onClick: () => {
        modDocumentFields()
        let fields = JSON.parse(JSON.stringify(formDataSource))
        const setFieldsValue = (fields, fieldName) => {
          const formFields = getFieldValue(fieldName)
          const [newField, newFieldIndex] = getField(fields, fieldName)
          newField.value = typeof formFields === 'object' ? JSON.stringify(formFields) : formFields
          fields.splice(newFieldIndex, newField)
          return fields
        }
        fields = setFieldsValue(fields, FIELD_TYPE.TITLE)
        fields = setFieldsValue(
          fields,
          FIELD_TYPE.REF_NO || item.fieldName === FIELD_TYPE.RECEIPT_REF_NO,
        )
        // fields = setFieldsValue(fields, 'fileDepartment')
        setErrFields(fields)
        diffRef.current.wrappedInstance.open()
      },
      async: false,
    },
    {
      key: 'yjxz',
      onClick: () => {
        modDocumentFields()
        // 一键下载
        service
          .downloadDocument({
            orgId,
            id: detailId,
          })
          .then(res => {
            const { url } = res
            downloadFile(url)
          })
      },
      async: false,
    },
    {
      key: 'yjff',
      onClick: () => {
        modDocumentFields()
        setOneDistribution(true)
        // getOneKeySenderUsers()
        setUserLoading(true)
        getActionList()
      },
      async: false,
    },
    {
      key: 'scgw',
      onClick: () => {
        modDocumentFields()
        // if (documentDetail.status === 0) {
        //   message.error('无法收藏公文！')
        //   return
        // }
        if (documentDetail.isCollect) {
          message.info('已收藏该公文')
          return
        }
        return new Promise(resolve => {
          service
            .collectDocument({
              orgId,
              id: detailId,
            })
            .then(() => {
              message.success('收藏成功')
              // if (onRefreshCollect instanceof Function) {
              //   onRefreshCollect(!isCollect)
              // }
            })
            .finally(() => {
              resolve()
            })
        })
      },
      async: true,
    },
    {
      key: 'jtfw',
      onClick: () => {
        // modDocumentFields()
        // setIsShowGroupDocSend(true)
        message.info('敬请期待')
      },
      async: false,
    },
    {
      key: 'fsqtsgs',
      onClick: () => {
        modDocumentFields()
        setIsShowOtherOrgsSend(true)
      },
      async: false,
    },
  ]

  const docReceiveBtn = () => {
    return documentDetail.isSendOut || documentDetail.isSendGroup
      ? [
          {
            name: '查看公文签收状态',
            onClick: () => {
              setIsShowDocReceive(true)
            },
          },
        ]
      : []
  }
  // 传入流程引擎中的公文内部按钮
  const extraButtons = docReceiveBtn()

  // 初始化获取字段限制
  const buttonsMount = ({ access, editMode, draft }) => {
    if (draft && draft.fields) {
      setFormDataSource(draft.fields)
    }

    if (editMode.indexOf('web') !== -1) {
      setAccess(access)
    }
  }

  // 创建表单值回填
  const createFormValue = (formDataSource, keys, values) => {
    formDataSource.forEach(field => {
      const newField = { ...field }
      if (field.fieldName === 'rowCard') {
        createFormValue(field.children, keys, values)
        return
      }

      if (keys.indexOf(newField.fieldName) !== -1) {
        field.value = values[field.fieldName]
      }

      if (
        (field.fieldName === 'refNo' ||
          field.fieldName === 'outsideRefNo' ||
          field.fieldName === 'receiptRefNo') &&
        isArray(field.value) &&
        field.value.length
      ) {
        const selectOption = refNoDataSource.filter(i => i.name === field.value[0])
        field.extraValue = selectOption && selectOption.length && JSON.stringify(selectOption[0])
      }
    })
  }

  // 处理表单values
  const getFieldsValue = values => {
    const fields = []
    const keys = Object.keys(values) || []
    createFormValue(formDataSource, keys, values, fields)
    return formDataSource
  }

  // 提交表单
  const onSubmit = async () => {
    // modDocumentFields(reload)
  }

  const canWrite = () => {
    if (access && access.bodyFile && access.bodyFile === 'WRITE') {
      if (isOperate) {
        return true
      }
      return false
    }
    return false
  }

  const onSubmitOpen = async () => {
    return new Promise((resolve, reject) => {
      validateFieldsAndScroll((err, values) => {
        if (!err) {
          if (
            isFormValueChange &&
            formType === 1 &&
            values.bodyFile[0].type !== 'undefined' &&
            canWrite()
          ) {
            Modal.warning({
              title: '更新正文提醒',
              content: '当前除正文外有其他字段修改，请正文编辑后保存即可生效',
              okText: '确定',
            })
            reject()
          } else {
            const allFieldKeys = Object.keys(values) || []

            let refNo1 = ''
            let refNo2 = ''
            let refNo3 = ''

            if (allFieldKeys.length && allFieldKeys.indexOf('refNo') !== -1) {
              refNo1 = values.refNo[0]
              refNo2 = values.refNo[1]
              refNo3 = values.refNo[2]
            }

            const res = getFieldsValue(values)
            resolve({
              _dept: { label: deptData.label, value: deptData.value },
              fields: res,
              refNo1,
              refNo2,
              refNo3,
              ...values,
            })
          }
        } else {
          reject()
        }
      })
    })
  }

  // 返回事件
  const goBack = () => {
    history.goBack()
  }

  // 获取点击正文列表索引
  const getPreviewIndex = index => {
    setPreviewIndex(index)
  }

  // const secretClassChange = value => {
  //   setSecretClassStatus(value)
  // }

  // FileRender 所需参数
  const renderNeedData = {
    form: props.form,
    access,
    refNoDataSource,
    classifiedCallback,
    getUploadBodyFile,
    onWpsContentChange,
    // secretClassChange,
    // secretClassStatus,
    redheadTemplates,
    docTemplate: documentDetail,
    id: detailId,
    status: documentDetail.status,
    previewIndex,
    getDocumentDetail,
    formDataSource,
    eventTimeList,
    type: 'DETAIL',
    isOperate,
    deptId: deptData.value,
    deptName: deptData.label,
    fullDepartment,
  }

  const onSuccess = type => {
    switch (type) {
      case 'out':
        setIsShowOtherOrgsSend(false)
        getDocumentDetail()
        break
      case 'group':
        setIsShowGroupDocSend(false)
        getDocumentDetail()
        break
      default:
        break
    }
  }

  return (
    <div className={styles['my-warp']}>
      <Spin spinning={loading}>
        <PageHeader
          title={headerTitle}
          icon="totheleft_line"
          type="detail"
          iconColor="#262a30"
          onTitleClick=""
          onIconClick={goBack}
        />
        <PageContent ref={contentRef}>
          <Form {...formItemLayout} className={styles.detailContent}>
            {formDataSource.map((item, i) => {
              if (item.fieldName === 'rowCard') {
                let otherProps = {}
                let colSpan = 24
                if (item.children.length === 2) {
                  otherProps = { labelCol: { span: 4 }, wrapperCol: { span: 20 } }
                  colSpan = 12
                }
                if (item.children.length === 3) {
                  otherProps = { labelCol: { span: 6 }, wrapperCol: { span: 18 } }
                  colSpan = 8
                }

                return (
                  <Row gutter={24} key={i}>
                    {item.children.map((sub, index) => (
                      <Col span={colSpan} key={index}>
                        {FileRender(sub, renderNeedData, otherProps)}
                      </Col>
                    ))}
                  </Row>
                )
              }
              return FileRender(item, renderNeedData)
            })}
          </Form>
          {bodyFileUploadUrl && (
            <RenderPdf
              setFieldsValue={setFieldsValue}
              onWpsContentChange={onWpsContentChange}
              url={bodyFileUploadUrl}
              fileList={bodyFileList}
              getPreviewIndex={getPreviewIndex}
              id={detailId}
              ref={renderPdfRef}
              redheadTemplates={redheadTemplates}
              access={access}
              isCreate={false}
              fields={formDataSource}
              deptId={deptData.value}
              deptName={deptData.label}
              form={props.form}
              type="DETAIL"
              isOperate={isOperate}
              formType={formType}
              contentWidth={contentWidth}
            />
          )}
          {documentDetail.taskId && (
            <div className={styles.buttonsWrap} ref={btnsRef}>
              <Buttons
                appId="b3b8415184344e7799733a0fd33d7221"
                // procKey="WF_DE20220302094411174152"
                userTaskId={documentDetail.taskId}
                customButtons={customButtons}
                onMount={buttonsMount}
                onSubmitOpen={onSubmitOpen}
                onSubmit={onSubmit}
                extraButtons={extraButtons}
              />
              <Steps userTaskId={documentDetail.taskId} />
            </div>
          )}
          {bodyFileUploadUrl &&
            (!backToTop ? (
              <div className={styles.scrollBtn} onClick={onScrollToBodyFileOrTop}>
                <XmiconReact name="arrowis_down_line" size={16} />
                只看正文
              </div>
            ) : (
              <div className={styles.scrollBtn} onClick={onScrollToBodyFileOrTop}>
                <XmiconReact name="arrows_up_line" size={16} />
                回到顶部
              </div>
            ))}
        </PageContent>
        {/* 差错公文 */}
        <DiffCustomInput
          ref={diffRef}
          readOnly={false}
          officialType={documentDetail.documentTemplate && documentDetail.documentTemplate.type}
          id={detailId}
          fields={errFields}
        />
        {isShowClassified && (
          <ClassifiedModal
            onChange={onChangeClassifiedValue}
            handleCloseModal={handleCloseClassifiedModal}
          />
        )}
        {oneDistribution && (
          <OneDistribution
            visible={oneDistribution}
            copyUserList={copyUser}
            mainUserList={mainUser}
            userLoading={userLoading}
            oneDistributionOk={oneDistributionOk}
            oneDistributionCancel={oneDistributionCancel}
          />
        )}
        {isShowGroupDocSend && (
          <GroupDocSendModal
            onSuccess={() => onSuccess('group')}
            onClose={() => setIsShowGroupDocSend(false)}
            id={detailId}
            renderNeedData={renderNeedData}
            fields={formDataSource}
            access={access}
            deptId={deptData.value}
            redheadTemplates={redheadTemplates}
            documentTemplate={documentDetail.documentTemplate}
          />
        )}
        {isShowOtherOrgsSend && (
          <SendOrgs
            onSuccess={() => onSuccess('out')}
            onClose={() => setIsShowOtherOrgsSend(false)}
            id={detailId}
          />
        )}
        {isShowDocReceive && (
          <DocReceiveStatusModal
            onClose={() => setIsShowDocReceive(false)}
            id={detailId}
            {...props}
            history={history}
          />
        )}
      </Spin>
    </div>
  )
}

export default connect(
  state => ({
    collapsed: state.globalInfo.collapsed,
    orgName: state.globalInfo.baseInfo.orgName,
    isFormValueChange: state.globalInfo.isFormValueChange,
    detailFields: state.globalInfo.detailFields,
  }),
  dispatch => ({
    actions: bindActionCreators(
      {
        onFormValueChange,
        setDetailFields,
      },
      dispatch,
    ),
  }),
)(
  Form.create({
    onValuesChange(props, changedValues) {
      const { detailFields } = props

      const copyCopy = cloneDeep(detailFields)

      const contrastFormValue = fieldName => {
        let isChange = false
        detailFields.forEach(i => {
          if (i.fieldName === fieldName && i.value !== changedValues[fieldName]) {
            isChange = true
          }
        })
        console.log(isChange, 'isChange')
        return isChange
      }

      const contrastFormObjValue = fieldName => {
        let isObjChange = false
        copyCopy.forEach(i => {
          if (i.fieldName === fieldName) {
            if (fieldName === 'mainSend' || fieldName === 'copySend' || fieldName === 'enclosure') {
              let value
              if (typeof i.value === 'string') {
                value = (i.value && JSON.parse(i.value)) || []
              } else {
                value = i.value
              }
              if (value && changedValues[fieldName]) {
                if (value.length !== changedValues[fieldName].length) {
                  isObjChange = true
                }
              }
            }
            if (fieldName === 'enclosure') {
              let value
              if (typeof i.value === 'string') {
                value = (i.value && JSON.parse(i.value)) || []
              } else {
                value = i.value
              }
              if (
                value &&
                changedValues[fieldName] &&
                value.fileList &&
                value.fileList.length &&
                changedValues[fieldName].fileList &&
                changedValues[fieldName].fileList.length
              ) {
                console.log(value.fileList.length, 'value && changedValues[fieldName]')
                console.log(
                  changedValues[fieldName].fileList.length,
                  'value && changedValues[fieldName]',
                )

                if (value.fileList.length !== changedValues[fieldName].fileList.length) {
                  isObjChange = true
                }
              }
            }
          }
        })
        console.log(isObjChange, 'isObjChange')
        return isObjChange
      }

      const changeKey = Object.keys(changedValues) || []
      if (
        (indexOf(changeKey, 'title') && changedValues.title && contrastFormValue('title')) ||
        (indexOf(changeKey, 'mainSend') &&
          isArray(changedValues.mainSend) &&
          contrastFormObjValue('mainSend')) ||
        (indexOf(changeKey, 'copySend') &&
          isArray(changedValues.copySend) &&
          contrastFormObjValue('copySend')) ||
        (indexOf(changeKey, 'urgencyLevel') &&
          changedValues.urgencyLevel &&
          contrastFormValue('urgencyLevel')) ||
        (indexOf(changeKey, 'secretClass') &&
          changedValues.secretClass &&
          contrastFormValue('secretClass')) ||
        (indexOf(changeKey, 'secrecyTerm') &&
          changedValues.secrecyTerm &&
          contrastFormValue('secrecyTerm')) ||
        (indexOf(changeKey, 'enclosure') && contrastFormObjValue('enclosure'))
      ) {
        console.log(changedValues, 'changedValues')
        props.actions.onFormValueChange(true)
      }
      // if (indexOf(changeKey, 'bodyFile')) {
      //   props.actions.onFormValueChange(false)
      // }
    },
    onFieldsChange(props, changedValues) {
      const { detailFields } = props

      const copyCopy = cloneDeep(detailFields)

      // 判断问号是否一直
      const contrastFormRefNo = fieldName => {
        let isRefChange = false
        copyCopy.forEach(i => {
          if (i.fieldName === fieldName && changedValues[fieldName]) {
            let refNoValue
            if (typeof i.value === 'string') {
              refNoValue = JSON.parse(i.value) || []
            } else {
              refNoValue = i.value
            }

            let changeValue
            if (typeof changedValues[fieldName].value === 'string') {
              changeValue = JSON.parse(changedValues[fieldName].value) || []
            } else {
              changeValue = changedValues[fieldName].value
            }

            if (
              refNoValue[0] !== changeValue[0] ||
              refNoValue[1] !== changeValue[1] ||
              refNoValue[2] !== changeValue[2]
            ) {
              isRefChange = true
            }
          }
        })

        console.log(isRefChange, 'isRefChange')

        return isRefChange
      }

      const changeKey = Object.keys(changedValues) || []

      if ((changeKey.length && changeKey && indexOf(changeKey, 'refNo')) || changedValues.refNo) {
        const res = contrastFormRefNo('refNo')
        if (res) {
          console.log(res, 'res=>>>>>>>>>')
          props.actions.onFormValueChange(true)
        }
      }

      // if (indexOf(changeKey, 'bodyFile')) {
      //   props.actions.onFormValueChange(false)
      // }
    },
  })(MyDocument),
)
