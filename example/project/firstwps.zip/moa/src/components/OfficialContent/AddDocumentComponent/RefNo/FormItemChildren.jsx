import React, { forwardRef } from 'react'
import { Select, Input } from 'antd'
import { DOC_NUM_YEARS } from './const'
import styles from './index.scss'

const { Option } = Select

function FormItemChildren(props, ref) {
  const {
    size,
    value,
    dataSource,
    setAfterShow,
    leftDisabled,
    rightDisabled,
    accessX = [],
    type,
    isOperate,
    fieldName,
  } = props
  // 字段1
  const handleOneChange = val => {
    triggerChange(val, 0)
  }

  // 字段2
  const handleTwoChange = val => {
    triggerChange(val, 1)
  }

  // 字段3
  const handleThreeChange = e => {
    const { value } = e.target
    // 文号后面两个字段必须是数字
    if (value) {
      const regex = /^\d{1,4}$/
      if (!regex.test(value)) return
    }
    triggerChange(value, 2)
  }

  // 字段改变
  const triggerChange = (changedValue, index) => {
    const { onChange, value } = props
    value[index] = changedValue
    if (dataSource.map(item => item.name).includes(value[0]) && value[0] && value[1]) {
      setAfterShow(true)
    } else {
      setAfterShow(false)
    }
    if (onChange) {
      onChange(value)
    }
  }

  return (
    <div ref={ref} className={styles.formItemChildren}>
      {(accessX[`${fieldName}1`] === 'WRITE' || !accessX[`${fieldName}1`]) &&
        (type === 'ADD' || isOperate ? (
          <Select
            value={value[0] || undefined}
            size={size}
            // showSearch
            allowClear
            style={{ width: '37%' }}
            onChange={handleOneChange}
            disabled={leftDisabled}
            placeholder="发文机关代字"
            filterOption={() => true}
            getPopupContainer={triggerNode => triggerNode.parentNode}
          >
            {dataSource.map(item => (
              <Option key={item.id} value={item.name}>
                {item.name}
              </Option>
            ))}
          </Select>
        ) : (
          <span>{value[0] || ''}</span>
        ))}
      {accessX[`${fieldName}1`] === 'READ' && <span>{value[0] || ''}</span>}
      〔&nbsp;
      {(accessX[`${fieldName}2`] === 'WRITE' || !accessX[`${fieldName}2`]) &&
        (type === 'ADD' || isOperate ? (
          <Select
            value={value[1] || new Date().getFullYear()}
            size={size}
            // showArrow={false}
            disabled={rightDisabled}
            placeholder="年份"
            style={{ width: '20%' }}
            onChange={handleTwoChange}
            getPopupContainer={triggerNode => triggerNode.parentNode}
          >
            {DOC_NUM_YEARS.map(item => (
              <Option key={item.value} value={item.value}>
                {item.text}
              </Option>
            ))}
          </Select>
        ) : (
          <span>{value[1] || ''}</span>
        ))}
      {accessX[`${fieldName}2`] === 'READ' && <span>{value[1] || ''}</span>}
      &nbsp;〕
      {(accessX[`${fieldName}3`] === 'WRITE' || !accessX[`${fieldName}3`]) &&
        (type === 'ADD' || isOperate ? (
          <Input
            autoComplete='off'
            type="text"
            size={size}
            value={value[2]}
            disabled={rightDisabled}
            maxLength={4}
            placeholder="序号"
            onChange={handleThreeChange}
            style={{ width: '15%', marginRight: '3%' }}
          />
        ) : (
          <span>{value[2] || ''}</span>
        ))}
      {accessX[`${fieldName}3`] === 'READ' && <span>{value[2] || ''}</span>}
      <span>号</span>
    </div>
  )
}

export default forwardRef(FormItemChildren)
