export const DOC_NUM_YEARS = []
const nowYear = new Date().getFullYear()
for (let i = nowYear - 5; i < nowYear+50; i++) {
  DOC_NUM_YEARS.push({
    text: i,
    value: i,
  })
}