/*
 * @Description:
 * @Author: dnh
 * @Date: 2022-02-24 10:16:18
 * @LastEditTime: 2022-03-23 22:55:17
 * @LastEditors: dnh
 * @FilePath: \src\components\OfficialContent\AddDocumentComponent\DocumentDate\index.jsx
 */
import React from 'react'
import { DatePicker, Form } from 'antd'
import moment from 'moment'
import { formatDate } from 'ROOT/utils'

// const { RangePicker } = DatePicker
function DocumentDate(props) {
  // todo,可编辑的流程逻辑未完成
  // const { data:{ aliasName = '收文日期', fieldName = '', property, value, isFill }, getFieldDecorator } = props
  const {
    data: { aliasName, fieldName, value, isFill, customName, property },
    getFieldDecorator,
    otherProps,
    access = 'READ',
    isOperate,
    type,
  } = props
  const { format = 'YYYY/MM/DD HH:mm' } = JSON.parse(property)
  return (
    <Form.Item label={customName || aliasName} {...otherProps}>
      {getFieldDecorator(fieldName, {
        initialValue: value ? moment(value) : '',
        rules: [{ required: isFill, message: `请输入${customName || aliasName}！` }],
      })(
        // eslint-disable-next-line no-nested-ternary
        access === 'WRITE' ? (
          type === 'ADD' || isOperate ? (
            <DatePicker
              showTime={format.indexOf('HH:mm') !== -1 ? { format: 'HH:mm' } : false}
              format={format}
              // format="YYYY-MM-DD HH:mm"
              placeholder="请选择"
              disabled={false} // todo 可编辑流程
            />
          ) : (
            <span>{formatDate(value, format) || '-'}</span>
          )
        ) : (
          <span>{formatDate(value, format) || '-'}</span>
        ),
      )}
    </Form.Item>
  )
}

export default DocumentDate
