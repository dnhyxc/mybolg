import React from 'react'
import ClassNames from 'classnames'
import styles from './index.scss'

export default ({ value, className }) => {
  return (
    <div className={ClassNames(styles.text, className, value ? '' : styles.default)}>
      {value || '-'}
    </div>
  )
}
