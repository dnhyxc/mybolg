/* eslint-disable no-nested-ternary */
import React, { useState, useEffect } from 'react'
import { Select, Button, Form } from 'antd'

import { OrgSelector } from '@xm/util'
import { isArray } from 'ROOT/utils'

import styles from './index.scss'

const JointlySign = props => {
  const {
    data: { customName, aliasName, fieldName, isFill, value = [] },
    labelsTags,
    access = 'READ',
    type,
    isOperate,
    setFieldsValue,
    otherProps,
    getFieldDecorator,
  } = props
  const [selectDataSource, setSelectDataSource] = useState([])
  const [changeData, setChangeData] = useState([])
  const [allDataList, setAllDataList] = useState([])
  const [userSelectorVisble, setUserSelectorVisble] = useState(false)
  const [dataDepts, setDataDepts] = useState([])
  const [dataOrgs, setDataOrgss] = useState([])

  const onDeselect = value => {
    const deleteChangeValue = changeData.filter(item => item.name !== value)
    const deleteTagValue = selectDataSource.filter(item => item.name !== value)

    setSelectDataSource(deleteTagValue)
    setChangeData(deleteChangeValue)
  }

  const onBlur = value => {
    if (value.length === 0) return
    const changeValue = [{ id: -1, name: value[value.length - 1] }]

    const find = changeData.filter(i => i.name === changeValue[0].name)

    const isFind = allDataList.filter(i => i === value[value.length - 1])

    if (find.length || isFind.length) return

    setChangeData(changeData.concat(changeValue))
  }

  const handleClickTag = tag => {
    const arr = [tag]
    setSelectDataSource(selectDataSource.concat(arr))
  }

  const getResult = () => {
    const sortArr = (selectDataSource.length !== 0 && selectDataSource.sort(getSort)) || []
    const tagArr = sortArr.filter(item => item.disType === 'tag') // 标签的数组
    const pickArr = sortArr.filter(item => item.disType !== 'tag') // 选人的数组
    const concatArr = pickArr.concat(tagArr)
    const dataArr = changeData.concat(concatArr).map(item => item.name) // 合并数组顺序（自定义，部门，标签）
    setFieldsValue({ countersignDepartment: changeData.concat(concatArr) })
    setAllDataList(dataArr)
  }

  const getSort = (a, b) => a.sequence - b.sequence

  // const renderSelectorTags = () => {
  //   const showTags = ['mainSend', 'copySend'].includes(fieldName)

  //   if (!showTags) {
  //     return null
  //   }

  //   return (
  //     <div className="mt-16">
  //       {labelsTags.map(x => (
  //         <Button
  //           disabled={allDataList.some(y => y === x.lnName)}
  //           onClick={() => handleClickTag({ name: x.lnName, type: 3 })}
  //           className="mr-8"
  //           key={x.nodeCode}
  //         >
  //           {x.lnName}
  //         </Button>
  //       ))}
  //     </div>
  //   )
  // }

  const handleSelect = () => {
    setUserSelectorVisble(true)
  }

  const handleConfirm = ({ depts = [], orgs = [] }) => {
    console.log(depts, 'depts')
    console.log(orgs, 'orgs')
    const deptsList = depts.map(item => ({ ...item, type: 1 }))
    const orgsList = orgs.map(item => ({ ...item, type: 2 }))
    const arr = deptsList.concat(orgsList)
    // setSelectDataSource(selectDataSource.concat(arr))
    setSelectDataSource(arr)
    setDataDepts(depts)
    setDataOrgss(orgs)
    setUserSelectorVisble(false)
  }
  const handleCancel = () => {
    setUserSelectorVisble(false)
  }

  useEffect(() => {
    getResult()
  }, [changeData, selectDataSource])

  useEffect(() => {
    let JsonValue
    if (value && isArray(value)) {
      JsonValue = value
    } else if (value) {
      JsonValue = JSON.parse(value)
    }
    if (JsonValue) {
      setChangeData(JsonValue.filter(item => item.id === -1))
      setSelectDataSource(JsonValue.filter(item => item.id !== -1))
    }
  }, [value])

  return (
    <div>
      {userSelectorVisble && (
        <OrgSelector
          visible={userSelectorVisble}
          defaultDeptList={dataDepts}
          defaultOrgList={dataOrgs}
          onConfirm={handleConfirm}
          onCancel={handleCancel}
        />
      )}
      {access === 'WRITE' ? (
        type === 'ADD' || isOperate ? (
          <Form.Item label={customName || aliasName} className={styles.aliasStyle} {...otherProps}>
            {getFieldDecorator(fieldName, {
              initialValue: value || '',
              rules: [{ required: isFill, message: `请选择${customName || aliasName}！` }],
            })(
              <div className={styles.pickStyle}>
                <Select
                  mode="tags"
                  style={{ width: '100%' }}
                  value={allDataList}
                  dropdownStyle={{ display: 'none' }}
                  onDeselect={onDeselect}
                  onBlur={onBlur}
                  getPopupContainer={triggerNode => triggerNode.parentNode}
                />
                <Button className={styles.sendSelect} onClick={handleSelect}>
                  <i className={styles.pickIcon} />
                </Button>
              </div>,
            )}
            {/* {renderSelectorTags()} */}
          </Form.Item>
        ) : (
          <Form.Item label={aliasName} {...otherProps}>
            <span> {(allDataList && allDataList.join(',')) || '-'} </span>
          </Form.Item>
        )
      ) : (
        <Form.Item label={aliasName} {...otherProps}>
          <span> {(allDataList && allDataList.join(',')) || '-'} </span>
        </Form.Item>
      )}
    </div>
  )
}

export default JointlySign
