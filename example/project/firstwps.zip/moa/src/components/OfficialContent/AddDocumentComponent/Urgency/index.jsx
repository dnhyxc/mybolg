import React from 'react'
import FormItem from 'ROOT/components/FormItem'

const Urgency = props => {

  return (
    <FormItem formDataProps={props} />
  )
}

export default Urgency
