/* eslint-disable no-nested-ternary */
import React, { useState, useEffect } from 'react'
import { Upload, message, Button, Form } from 'antd'
import { UPLOAD_URL } from 'ROOT/service/api'
import { previewFile } from '@xm/util'

import FileList from 'ROOT/components/FileList'

import styles from './index.scss'

const ReferenceInformation = props => {
  const {
    data: { aliasName, customName, property, fieldName, isFill, value },
    getFieldDecorator,
    type,
    setFieldsValue,
    fileLimit,
    otherProps,
    access = 'READ',
    isOperate,
    docTemplate,
  } = props

  const maxFile = JSON.parse(property).max
  // const maxFile = 1
  const maxSize = 50

  const [fileLists, setFileList] = useState([])
  const [isFilePermission, setIsFilePermission] = useState(false)

  const uploadImg = (res, value) => {
    const fileObj = {
      uid: value.uid,
      url: res.fileUrl,
      lastModified: value.lastModified,
      type: value.type,
      name: value.name,
      size: value.size,
    }
    if (fileLists.length < maxFile) {
      setFileList(preVal => {
        return [...preVal, fileObj]
      })
    }
  }

  useEffect(() => {
    setFieldsValue({ reference: { fileList: fileLists } })
  }, [fileLists])

  const beforeUpload = (file, fileList) => {
    if (fileList.length + fileLists.length > Number(maxFile)) {
      message.error('超出文件最大上传数量')
      return false
    }
    const fileName = file.name.split('.')[0]
    const reg = /^[\d\u4e00-\u9fa5]+$/
    if (fileLimit === 1 && !reg.test(fileName)) {
      message.error('附件命名格式不匹配')
      return false
    }
    if (file.size > maxSize * 1024 * 1024) {
      message.error('附件大小超出限制')
      return false
    }
  }

  const onDelete = data => {
    setFileList(fileLists.filter(item => item.uid !== data.uid))
  }

  const beforeDownload = () => {}

  const onFileClick = item => {
    const { response, name, url } = item
    let fileUrl = ''
    if (response) {
      fileUrl = response.fileUrl
    }
    previewFile({
      previewUrl: fileUrl || url,
      fileName: name,
    })
  }

  const onSortEnd = data => {
    setFileList(data)
  }

  const onRename = data => {
    console.log(data, 'data')
    setFileList(data)
  }

  const renderExtraActions = () => {}

  const handleOpenFilePermission = () => {
    setIsFilePermission(true)
  }

  useEffect(() => {
    // const value = "[{\"key\":\"1645493526638_0.9306541381068838\",\"name\":\"审批印章-待审核@2x.png\",\"url\":\"http://moa-dev.uban360.net:21007/sfs/file?digest=fide075445f2bc043fdc375498741feae86\",\"downloadUrl\":\"http://moa-dev.uban360.net:21007/sfs/file?digest=fide075445f2bc043fdc375498741feae86\",\"size\":28542,\"mimeType\":\"image/png\",\"type\":\"png\",\"visibleRange\":{\"depts\":[{\"id\":532706,\"name\":\"测试\",\"sequence\":26}],\"users\":[]}},{\"key\":\"1645493526638_0.9487470857204745\",\"name\":\"审批印章-待审核@2x(1).png\",\"url\":\"http://moa-dev.uban360.net:21007/sfs/file?digest=fide334cb03a7520e86cf7757be58e6e7ea\",\"downloadUrl\":\"http://moa-dev.uban360.net:21007/sfs/file?digest=fide334cb03a7520e86cf7757be58e6e7ea\",\"size\":27671,\"mimeType\":\"image/png\",\"type\":\"png\"}]"
    // console.log(JSON.parse(value), 'value')
    // if (type !== 'ADD' && value) {
    //   setFileList(JSON.parse(value).fileLists)
    // }

    let JsonValue
    if (value && typeof value === 'object') {
      JsonValue = value
    } else if (value && typeof value === 'string') {
      JsonValue = JSON.parse(value)
    }
    if (JsonValue) {
      setFileList(JsonValue.fileList)
    }
  }, [value])

  return (
    <div>
      <Form.Item label={customName || aliasName} className={styles.aliasStyle} {...otherProps}>
        {access === 'WRITE' ? (
          type === 'ADD' || isOperate ? (
            <div className={styles.aliasStyle}>
              {getFieldDecorator(fieldName, {
                initialValue: value || '',
                rules: [{ required: isFill, message: `请输入${customName || aliasName}！` }],
              })(
                <Upload
                  name="logo"
                  action={UPLOAD_URL}
                  listType="picture"
                  maxFileSize={50}
                  multiple
                  showUploadList={false}
                  onSuccess={uploadImg}
                  beforeUpload={beforeUpload}
                >
                  <Button disabled={fileLists.length >= maxFile}>上传文件</Button>
                </Upload>,
              )}
            </div>
          ) : (
            '-'
          )
        ) : (
          '-'
        )}
        {fileLists && fileLists.length > 0 && (
          <FileList
            enableSort={fileLists.length > 1}
            dataSource={fileLists}
            onDelete={onDelete}
            beforeDownload={beforeDownload}
            downloadable
            onClick={onFileClick}
            onSortEnd={onSortEnd}
            onRename={onRename}
            renderExtraActions={renderExtraActions}
            docTemplate={docTemplate}
            type={type}
          />
        )}
      </Form.Item>

      {isFilePermission && (
        <PermissionAssignment
          visible={isFilePermission}
          // id={id}
          // isCreate={isCreate}
          dataList={fileLists}
          // onClose={this.handleCloseFilePermission}
          // onOk={this.handleFilePermissionOk}
        />
      )}
    </div>
  )
}

export default ReferenceInformation
