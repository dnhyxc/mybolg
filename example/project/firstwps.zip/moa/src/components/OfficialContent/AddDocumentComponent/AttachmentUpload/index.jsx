/* eslint-disable no-nested-ternary */
import React, { useState, useEffect } from 'react'
import { Upload, message, Button, Form } from 'antd'
import { UPLOAD_URL } from 'ROOT/service/api'
// import { request, globalStore } from '@xm/util'
import axios from 'axios'
import { previewFile } from '@xm/util'
import FileList from 'ROOT/components/FileList'

import PermissionAssignment from '../PermissionAssignment'

import styles from './index.scss'

const AttachmentUpload = props => {
  const {
    data: { aliasName, fieldName, property, isFill, value, customName },
    getFieldDecorator,
    access = 'READ',
    type,
    fileLimit,
    setFieldsValue,
    otherProps,
    isOperate,
    secretClassStatus,
    deptId,
    status,
    docTemplate,
  } = props
  // console.log(deptId, 'deptId')
  const maxFile = JSON.parse(property).max
  const maxSize = 50

  const [fileLists, setFileList] = useState([])
  const [isFilePermission, setIsFilePermission] = useState(false)

  // const uploadSuccess = (res, value) => {
  //   // console.log(value, 'value')

  //   const fileObj = {
  //     uid: value.uid,
  //     url: res.fileUrl,
  //     lastModified: value.lastModified,
  //     type: value.type,
  //     name: value.name,
  //     size: value.size,
  //   }
  //   if (fileLists.length < maxFile) {
  //     setFileList(preVal => {
  //       return [...preVal, fileObj]
  //     })
  //   }
  // }

  const beforeUpload = (file, fileList) => {
    // const { file } = e
    if (fileList.length + fileLists.length > Number(maxFile)) {
      message.error('超出文件最大上传数量')
      return false
    }
    const fileName = file.name.split('.')[0]
    const reg = /^[\d\u4e00-\u9fa5]+$/
    if (fileLimit === 1 && !reg.test(fileName)) {
      message.error('附件命名格式不匹配')
      return false
    }
    if (file.size > maxSize * 1024 * 1024) {
      message.error('附件大小超出限制')
      return false
    }
    getUploadData(file)
  }

  const getUploadData = async file => {
    const fd = new FormData()

    fd.append('file', file)

    const {
      status,
      data: { fileUrl },
    } = await axios.post(UPLOAD_URL, fd)
    if (status === 200) {
      const fileObj = {
        uid: file.uid,
        url: fileUrl,
        lastModified: file.lastModified,
        type: file.type,
        name: file.name,
        size: file.size,
      }
      if (fileLists.length < maxFile) {
        console.log(fileObj, 'fileObj')
        setFileList(preVal => {
          return [...preVal, fileObj]
        })
      }
    }
  }

  const onDelete = data => {
    setFileList(fileLists.filter(item => item.uid !== data.uid))
  }

  const onFileClick = item => {
    console.log(item, 'item')
    const { url, name } = item
    previewFile({
      previewUrl: url,
      fileName: name,
    })
  }

  const onSortEnd = data => {
    setFileList(data)
  }

  const onRename = data => {
    console.log(data, 'data')
    setFileList(data)
  }

  const handleOpenFilePermission = () => setIsFilePermission(true)

  const renderMiddleOption = () => {
    if (fileLists.length === 0) {
      return null
    }

    return (
      <div className={styles['action-list']}>
        <a onClick={handleOpenFilePermission}>附件权限设置</a>
      </div>
    )
  }

  const handleCloseFilePermissionClose = () => setIsFilePermission(false)

  const handleFilePermissionOk = data => {
    // console.log(data, 'dataoooooo')
    setIsFilePermission(false)
    setFileList(data)
  }

  useEffect(() => {
    setFieldsValue({ enclosure: { fileList: fileLists } })
  }, [fileLists])

  useEffect(() => {
    // if (type !== 'ADD' && value) {
    //   setFileList(JSON.parse(value).fileList)
    // }
    let JsonValue
    if (value && typeof value === 'object') {
      JsonValue = value
    } else if (value && typeof value === 'string') {
      JsonValue = JSON.parse(value)
    }

    // console.log(JsonValue, 'pppppppp')
    if (JsonValue && JsonValue.fileList) {
      setFileList(JsonValue.fileList)
    } else if (JsonValue) {
      setFileList(JsonValue)
    }
  }, [value])

  return (
    <div>
      <Form.Item label={customName || aliasName} {...otherProps}>
        {access !== 'READ' ? (
          type === 'ADD' || isOperate ? (
            <div className={styles.aliasStyle}>
              {getFieldDecorator(fieldName, {
                initialValue: value || '',
                rules: [{ required: isFill, message: `请输入${customName || aliasName}！` }],
              })(
                <Upload
                  name="logo"
                  // action={UPLOAD_URL}
                  listType="picture"
                  maxFileSize={50}
                  multiple
                  fileList={fileLists}
                  beforeUpload={beforeUpload}
                  showUploadList={false}
                  // onSuccess={uploadSuccess}
                >
                  <Button disabled={fileLists.length >= maxFile}>上传文件</Button>
                </Upload>,
              )}
              {renderMiddleOption()}
            </div>
          ) : (
            '-'
          )
        ) : (
          '-'
        )}

        { fileLists.length > 0 && (
          <FileList
            enableSort={fileLists.length > 1}
            dataSource={fileLists}
            onDelete={onDelete}
            type={type}
            deptId={deptId}
            secretClassStatus={secretClassStatus}
            downloadable
            status={status}
            access={access}
            onClick={onFileClick}
            onSortEnd={onSortEnd}
            onRename={onRename}
            docTemplate={docTemplate}
          />
        )}
      </Form.Item>

      {/* {isFilePermission && ( */}
      <PermissionAssignment
        visible={isFilePermission}
        // id={id}
        // isCreate={isCreate}
        type={type}
        dataList={fileLists}
        permissionClose={handleCloseFilePermissionClose}
        permissionOk={handleFilePermissionOk}
      />
      {/* )} */}
    </div>
  )
}

export default AttachmentUpload
