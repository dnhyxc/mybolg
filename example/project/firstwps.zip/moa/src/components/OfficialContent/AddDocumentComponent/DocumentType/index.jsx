import React from 'react'
import FormItem from 'ROOT/components/FormItem'

const DocumentType = props => {

  return (
    <FormItem formDataProps={props} />
  )
}

export default DocumentType
