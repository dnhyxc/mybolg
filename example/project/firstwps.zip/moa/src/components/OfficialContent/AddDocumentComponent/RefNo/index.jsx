import React, { useState, useEffect } from 'react'
import { Form, message, Modal, Button, Table } from 'antd'
import { globalStore } from '@xm/util'
import service from 'ROOT/service'
import { getSerialNumStr, getSerialNumStrFromStr } from 'ROOT/utils'
import FormItemChildren from './FormItemChildren'
import styles from './index.scss'

function RefNo(props) {
  // todo,可编辑的流程逻辑未完成
  const {
    data: { aliasName, fieldName, isFill, value, customName },
    getFieldDecorator,
    getFieldValue,
    setFieldsValue,
    dataSource,
    // readOnly = false,
    access,
    accessX,
    otherProps,
    isOperate,
    type,
  } = props
  const readOnly = access === 'READ'
  const orgId = globalStore.get('orgId')
  const [afterShow, setAfterShow] = useState(false)
  const [isHistoryShow, setIsHistoryShow] = useState(false)
  const [histories, setHistories] = useState([])

  useEffect(() => {
    // value 为空会赋予初始值
    if (!value || (value[0] && dataSource.map(item => item.name).includes(value[0]))) {
      setAfterShow(true)
    } else {
      setAfterShow(false)
    }
  }, [])

  const handleClose = () => {
    setIsHistoryShow(false)
  }

  // 查看历史
  const showHistory = () => {
    const serialNum = getFieldValue(fieldName)
    console.log('serialNum', serialNum)
    const { id } = dataSource.find(item => item.name === serialNum[0])
    service
      .getHisDocumentListByRefNo({
        orgId,
        id,
        year: serialNum[1],
      })
      .then(res => {
        setHistories(res.infos)
      })
    setIsHistoryShow(true)
  }

  const generateNum = () => {
    const value = getFieldValue(fieldName)
    const { id } = value && dataSource.find(item => item.name === value[0])
    if (!value[0] || !value[1]) {
      message.error('发文机关带字不存在或者没有年份')
      return
    }

    service
      .genRefNo({
        orgId,
        id,
        year: value[1],
      })
      .then(res => {
        const newSerialNum = [...value]
        newSerialNum[2] = res.refNo
        setFieldsValue({ [fieldName]: newSerialNum })
        // setAfterShow(false)
      })
  }

  // 查看历史列表格式
  const getColumns = () => {
    return [
      {
        title: '时间',
        dataIndex: 'endTime',
        // width: 200,
        render: data => {
          return !data ? '-' : moment(data).format('YYYY/MM/DD HH:mm')
        },
      },
      {
        title: '文号',
        // width: 560,
        render: data => {
          return (
            <div className={styles['history-item-content']}>
              <div>{getSerialNumStrFromStr(data.refNo)}</div>
              <div>{data.title}</div>
            </div>
          )
        },
      },
    ]
  }

  const getInitData = data => {
    if (!data) {
      return null
    }
    if (typeof data === 'string') {
      return JSON.parse(data)
    }
    return data
  }

  return (
    <Form.Item
      label={customName || aliasName}
      extra={
        dataSource.length > 1 &&
        isOperate &&
        (accessX[`${fieldName}1`] === 'WRITE' || !accessX[`${fieldName}1`])
          ? '您当前有多个发文机关代字可使用，请谨慎选择'
          : ''
      }
      {...otherProps}
    >
      {getFieldDecorator(fieldName, {
        initialValue: getInitData(value) || [
          dataSource[0] ? dataSource[0].name : '',
          new Date().getFullYear(),
          '',
        ],
        rules: [{ required: isFill, message: `请输入${customName || aliasName}！` }],
      })(
        // readOnly ? (
        //   <div>{getSerialNumStr(getInitData(value) || [])}</div>
        // ) : (
        //   <FormItemChildren
        //     setAfterShow={setAfterShow}
        //     dataSource={dataSource}
        //     leftDisabled={false}
        //     rightDisabled={false}
        //     accessX={accessX}
        //     fieldName={fieldName}
        //   />
        // ),

        // eslint-disable-next-line no-nested-ternary
        readOnly ? (
          <div>{getSerialNumStr(getInitData(value) || [])}</div>
        ) : type === 'ADD' || isOperate ? (
          <FormItemChildren
            setAfterShow={setAfterShow}
            dataSource={dataSource}
            leftDisabled={false}
            rightDisabled={false}
            accessX={accessX}
            type={type}
            isOperate={isOperate}
            fieldName={fieldName}
          />
        ) : (
          <div>{getSerialNumStr(getInitData(value) || [])}</div>
        ),
      )}
      {afterShow &&
        !readOnly &&
        accessX[`${fieldName}3`] === 'WRITE' &&
        (type === 'ADD' || isOperate ? (
          <div className={styles['docnum-auto']}>
            <span className={styles['auto-num']} onClick={generateNum}>
              自动编号
            </span>
            <span className={styles['num-history']} onClick={showHistory}>
              查看历史
            </span>
          </div>
        ) : (
          ''
        ))}
      <Modal
        title="历史公文"
        onCancel={handleClose}
        visible={isHistoryShow}
        style={{ maxHeight: window.innerHeight - 200 }}
        footer={
          <div className={styles['history-close']}>
            <Button type="danger" onClick={handleClose}>
              关闭
            </Button>
          </div>
        }
      >
        <div
          className={styles['history-box']}
          style={{ maxHeight: `${window.innerHeight - 200}px` }}
        >
          <Table
            columns={getColumns()}
            dataSource={histories}
            rowKey="id"
            showHeader
            // scroll={{
            //   x: true,
            //   scrollToFirstRowOnChange: true,
            // }}
            pagination={false}
          />
        </div>
      </Modal>
    </Form.Item>
  )
}

export default RefNo
