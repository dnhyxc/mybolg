import React from 'react'
import { Input, Form } from 'antd'

const { TextArea } = Input
function InputRender(props) {
  // todo,可编辑的流程逻辑未完成
  const {
    data: { aliasName, fieldName, property, value, isFill, customName },
    getFieldDecorator,
    // readOnly = false, // todo 是否只读
    access = 'READ',
    otherProps,
    isOperate,
    type,
  } = props
  // const propertyS = JSON.parse(property)
  // const readOnly = access === 'READ'

  const propertyOptions = JSON.parse(property) || {}
  const render = () => {
    if (access === 'READ') {
      return <span>{value || '-'}</span>
    }
    if (access === 'WRITE' || !access) {
      // return propertyOptions.inputType === 0 ? (
      //   <Input maxLength={propertyOptions.max} placeholder="请输入" disabled={false} />
      // ) : (
      //   <TextArea maxLength={propertyOptions.max} placeholder="请输入" rows={1} disabled={false} />
      // )
      if (type === 'ADD' || isOperate) {
        return propertyOptions.inputType === 0 ? (
          <Input autoComplete='off' maxLength={propertyOptions.max} placeholder="请输入" disabled={false} />
        ) : (
          <TextArea maxLength={propertyOptions.max} placeholder="请输入" rows={1} disabled={false} />
        )
      }
      return <span>{value || '-'}</span>
    }
    return <span>{}</span>
  }

  return (
    <Form.Item label={customName || aliasName} {...otherProps}>
      {getFieldDecorator(fieldName, {
        initialValue: value || '',
        rules: [{ required: isFill, message: `请输入${customName || aliasName}！` }],
      })(render())}
    </Form.Item>
  )
}

export default InputRender
