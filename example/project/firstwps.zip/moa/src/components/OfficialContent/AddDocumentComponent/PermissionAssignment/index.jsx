import React, { useState, useEffect } from 'react'
import { Table, Modal } from 'antd'
import PermissionSetting from '../PermissionSetting'

import styles from './index.scss'

const PermissionAssignment = props => {
  const { permissionClose, visible, permissionOk, dataList, type } = props

  // console.log(dataList, '附件详情获取为空')

  const columns = [
    {
      title: '文件标题',
      width: 450,
      dataIndex: 'name',
      // render: this.renderTitle,
    },
    {
      title: '操作',
      render: record => renderOperate(record),
    },
  ]

  const [loading, setLoading] = useState(false)
  const [settingVisible, setSettingVisible] = useState(false)
  const [changeDeptsList, setChangeDeptsList] = useState([])
  const [chengeDeptType, setChengeDeptType] = useState('0')
  const [chnangeIndex, setChnangeIndex] = useState()
  const [fileList, setFileList] = useState([])

  const handleOpenPermission = data => {
    // console.log(data, 'index')
    const indexx = dataList.findIndex(item => item.uid === data.uid)
    setChnangeIndex(indexx)
    setSettingVisible(true)
  }

  const renderOperate = (record, index) => {
    return (
      <div className={styles['actions-list']}>
        {!record.visibleRange || record.visibleRange.depts.length === 0 ? (
          <a className={styles['action-item']} onClick={() => handleOpenPermission(record)}>
            设置权限
          </a>
        ) : (
          <a className={styles['action-item']} onClick={() => handleOpenPermission(record)}>
            {/* 设置权限 */}
            {record.visibleRange && record.visibleRange.depts.map(item => item.name).join(',')}
          </a>
        )}
      </div>
    )
  }

  const handlePermissionOk = (data, type) => {
    console.log(data, 'data')
    // const visibleRange = {
    //   depts: data,
    // }

    fileList.forEach((item, index) => {
      if (index === chnangeIndex) {
        item.visibleRange = { depts: data }
      }

      // if (index === chnangeIndex) {
      //   item.visibleRange = visibleRange
      // } else {

      // }
    })
    console.log(fileList, 'ppppppppp')
    setFileList(fileList.concat([]))

    setChangeDeptsList(fileList.concat([]))
    setChengeDeptType(type)
    setSettingVisible(false)
  }

  const handlePermissionClose = () => setSettingVisible(false)

  const handleCancel = () => permissionClose && permissionClose()

  const handleSubmitPermission = () => {
    if (permissionOk) permissionOk(fileList)
  }

  useEffect(() => {
    // if (type !== 'ADD') return
    setFileList(
      dataList.map(item => ({
        ...item,
        visibleRange:
          item.visibleRange && item.visibleRange.depts.length !== 0
            ? { depts: item.visibleRange.depts }
            : { depts: [] },
      })),
    )
  }, [dataList, type])

  return (
    <Modal
      className={styles['permission-modal']}
      title="权限分配"
      width={800}
      visible={visible}
      // confirmLoading={isSetting}
      onOk={handleSubmitPermission}
      onCancel={handleCancel}
      // afterClose={this.handleAfterClose}
    >
      <Table
        loading={loading}
        pagination={false}
        scroll={{ y: 300 }}
        columns={columns}
        dataSource={fileList}
      />
      {settingVisible && (
        <PermissionSetting
          // ref={this.premissionRef}
          chnangeIndex={chnangeIndex}
          changeDeptsList={changeDeptsList}
          settingVisible={settingVisible}
          settingOk={handlePermissionOk}
          settingClose={handlePermissionClose}
        />
      )}
    </Modal>
  )
}

export default PermissionAssignment
