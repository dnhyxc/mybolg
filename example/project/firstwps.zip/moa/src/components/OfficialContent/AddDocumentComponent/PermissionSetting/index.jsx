
import React, { useState, useEffect } from 'react'
import { Table, message, Button, Form, Modal, Radio } from 'antd'
// import UserSelector from "@xm/user-selector"
import { OrgSelector } from "@xm/util";

import styles from './index.scss'

const formItemLayout = {
  labelCol: { span: 6 },
  wrapperCol: { span: 18 },
}

const PermissionSetting = (props) => {

  const { settingVisible, changeDeptsList, settingClose, settingOk, chnangeIndex } = props
  const [isDepAll, setIsDepAll] = useState('0')
  const [selector, setSelector] = useState(false)
  const [selectorList, setSelectorList] = useState([])

  const permissionSettingOk = () => {
    if(settingOk) settingOk(selectorList, isDepAll)
  }

  const permissionSettingCancel = () => settingClose && settingClose()

  const departmentChange = e => {
    console.log(e, 'value')
    const { value } = e.target
    setIsDepAll(value)
  }

  const handleConfirm = ({ depts = [], orgs = [] }) => {
    console.log(depts,'depts')
    console.log(orgs,'orgs')
    const deptsOrgs = depts.concat(orgs)
    setSelectorList(selectorList.concat(deptsOrgs))
    setSelector(false)
  }
  const handleCancel = () => { setSelector(false) }

  const addDepts = () => setSelector(true)

  const closeDepts = (id) => {
    console.log(id,'id')
    setSelectorList(selectorList.filter(item => item.id !== id))
  }

  useEffect(()=>{
    if (changeDeptsList.length > 0) {
      console.log(changeDeptsList[chnangeIndex], 'changeDeptsList[chnangeIndex]')
      if (changeDeptsList[chnangeIndex] && changeDeptsList[chnangeIndex].visibleRange && changeDeptsList[chnangeIndex].visibleRange.depts) {
        setSelectorList(changeDeptsList[chnangeIndex].visibleRange.depts)
        setIsDepAll(changeDeptsList[chnangeIndex].visibleRange.depts.length > 0 ? '1' : '0')
      }
    }
  },[changeDeptsList])

  return (
    <Modal
        title="权限设置-谁可以看"
        width={600}
        visible={settingVisible}
        onOk={permissionSettingOk}
        onCancel={permissionSettingCancel}
      >
        <Form {...formItemLayout}>
          <Form.Item label="部门选择">
            <Radio.Group
              value={isDepAll}
              onChange={departmentChange}
            >
              <Radio value="0">全部部门</Radio>
              <Radio value="1">部分部门</Radio>
            </Radio.Group>
            {isDepAll === '1' &&
            <Button
              onClick={addDepts}
              className="mr-8">
              添加部门 +
            </Button>}
          </Form.Item>

          <Form.Item label={`${selectorList.length > 0 ? '已选择部门' : ''}`}>
          <div>
            {selectorList && selectorList.map((item, index) => {
              return (<div
                className={styles.selectedStyle}
                key={index}>
                <span>{item.name}</span>
                <span className={styles.closeSelector} onClick={()=>closeDepts(item.id)}>x</span>
              </div>)
            })}
          </div>
          </Form.Item>
        </Form>
        {selector && <OrgSelector
          visible={selector}
          range={500}
          onConfirm={handleConfirm}
          onCancel={handleCancel}
        />}

      </Modal>
  )
}

export default PermissionSetting
