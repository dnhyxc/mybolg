import React from 'react'
import FormItem from 'ROOT/components/FormItem'

const UseSeal = props => {
  return (
    <FormItem formDataProps={props} />
  )
}

export default UseSeal
