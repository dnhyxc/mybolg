import React from 'react'
import FormItem from 'ROOT/components/FormItem'

const ConfidentialityPeriod = props => {

  return (
    <FormItem formDataProps={props} />
  )
}

export default ConfidentialityPeriod
