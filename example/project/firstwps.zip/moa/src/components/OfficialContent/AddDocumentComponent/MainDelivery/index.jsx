/* eslint-disable no-nested-ternary */
import React, { useState, useEffect } from 'react'
import { Select, Button, Form, message } from 'antd'
import { isArray } from 'ROOT/utils'
import { OrgSelector } from '@xm/util'
import service from 'ROOT/service'

import styles from './index.scss'

const MainDelivery = props => {
  const {
    data: { aliasName, customName, fieldName, property, isFill, value = [] },
    access = 'READ',
    setFieldsValue,
    getFieldDecorator,
    otherProps,
    type,
    isOperate,
    id,
    docTemplate: { documentTemplate = {} } = {},
  } = props
  const labelsTags =
    property &&
    JSON.parse(property).options &&
    JSON.parse(property).options.map(item => ({ ...item, type: 3 }))
  const [allDataList, setAllDataList] = useState([])
  const [userSelectorVisble, setUserSelectorVisble] = useState(false)
  const [dataDepts, setDataDepts] = useState([])
  const [dataOrgs, setDataOrgss] = useState([])

  const [customArr, setCustomArr] = useState([]) // 自定义数据
  const [orgsArr, setOrgs] = useState([]) // 选人组件数据 需要调接口排序
  const [tagArr, setTagArr] = useState([]) // 管理后台配置的标签

  const onDeselect = value => {
    const { key } = value
    setDataDepts(dataDepts.filter(x => x.id !== key))
    setDataOrgss(dataOrgs.filter(x => x.id !== key))
    setCustomArr(customArr.filter(x => x.id !== key))
    setOrgs(orgsArr.filter(x => x.id !== key))
    setTagArr(tagArr.filter(x => x.id !== key))
  }
  const onBlur = value => {
    const addValue = value[value.length - 1]
    let isPass = true
    const list = [...customArr, ...orgsArr, ...tagArr]
    list.forEach(x => {
      if (x.key === addValue.key) {
        isPass = false
      }
    })

    if (isPass) {
      const changeValue = [
        {
          id: -1 * new Date().valueOf(),
          name: addValue.label,
          type: -1,
          key: addValue.key,
        },
      ]
      setCustomArr([...customArr, ...changeValue])
    }
  }

  const handleClickTag = tag => {
    service
      .batchGetOrgDepts({
        lnCodes: [tag.id],
        flag: 3,
      })
      .then(res => {
        const { orgs: orgsByTag, depts: deptsByTag } = res
        const orgsArrByTag = orgsArr.filter(
          x => orgsByTag.every(y => y.orgId !== x.id) && deptsByTag.every(y => y.deptId !== x.id),
        )
        setOrgs(orgsArrByTag)
        const depts = []
        const orgs = []
        orgsArrByTag.forEach(x => {
          if (x.type === 1) {
            orgs.push(x)
          }
          if (x.type === 2) {
            depts.push(x)
          }
        })
        setDataDepts(depts)
        setDataOrgss(orgs)
      })
    const arr = [tag]
    setTagArr([...tagArr, ...arr])
  }

  const getResult = list => {
    setFieldsValue({ mainSend: list })
    setAllDataList(list.map(x => ({ key: x.id, label: x.label, name: x.name })))
  }

  const renderSelectorTags = () => {
    const showTags = ['mainSend', 'copySend'].includes(fieldName)

    if (!showTags) {
      return null
    }
    return (
      <div className="mt-16">
        {labelsTags.map(x => (
          <Button
            disabled={allDataList.some(y => y.key === x.nodeCode)}
            onClick={() =>
              handleClickTag({
                name: x.lnName,
                id: x.nodeCode,
                type: x.type,
                disType: 'tag',
                key: x.nodeCode,
              })
            }
            className="mr-8"
            key={x.id}
          >
            {x.lnName}
          </Button>
        ))}
      </div>
    )
  }

  const handleSelect = () => {
    setUserSelectorVisble(true)
  }

  const handleChangeUi = () => {
    const list = [...customArr, ...orgsArr, ...tagArr] // 合并数组顺序（自定义，部门，标签）
    const result = []

    // list.forEach((x, i) => {
    //   let n
    //   let isDifType
    //   let isFirst
    //   const isEnd = !list[i + 1]
    //   if (x.type === -1 || x.type === 3) {
    //     result.push({
    //       ...x,
    //       label: (
    //         <span id={x.id}>
    //           {x.name}
    //           <s>{isEnd ? '' : '，'} </s>
    //         </span>
    //       ),
    //     })
    //   } else if (x.type === 1) {
    //     isDifType = !list[i + 1] || list[i + 1].type !== 1
    //     n = isDifType ? (isEnd ? '' : '，') : '、'
    //     result.push({
    //       ...x,
    //       label: (
    //         <span id={x.id}>
    //           {x.name.split('公司')[0]}
    //           {isDifType ? '市公司' : ''}
    //           <s>{n}</s>
    //         </span>
    //       ),
    //     })
    //   } else if (x.type === 2) {
    //     isFirst = !list[i - 1] || list[i - 1].type !== 2
    //     isDifType = !list[i + 1] || list[i + 1].type !== 2
    //     n = isDifType ? (isEnd ? '' : '，') : '、'
    //     result.push({
    //       ...x,
    //       label: (
    //         <span id={x.id}>
    //           {isFirst ? '区公司' : ''}
    //           {x.name}
    //           <s>{n}</s>
    //         </span>
    //       ),
    //     })
    //   }
    // })
    list.forEach((x, i) => {
      let n
      let isDifType
      let isFirst
      const isEnd = !list[i + 1]
      if (x.type === -1 || x.type === 3) {
        result.push({
          ...x,
          label: isEnd ? `${x.name}` : `${x.name}，`,
        })
      } else if (x.type === 1 && x.name !== '区公司') {
        isDifType = !list[i + 1] || list[i + 1].type !== 1
        n = isDifType ? (isEnd ? '' : '，') : '、'
        result.push({
          ...x,
          label: `${x.name.split('公司')[0] + (isDifType ? '市公司' : '') + n}`,
        })
      } else if (x.type === 2) {
        isFirst = !list[i - 1] || list[i - 1].type !== 2
        isDifType = !list[i + 1] || list[i + 1].type !== 2
        n = isDifType ? (isEnd ? '' : '，') : '、'
        result.push({
          ...x,
          label: `${(isFirst ? `区公司${x.name}` : `${x.name}`) + n}`,
        })
      } else if (x.name === '区公司') {
        result.push({
          ...x,
          label: isEnd ? `${x.name}` : `${x.name}，`,
        })
      }
    })
    return result
  }
  const handleConfirm = ({ depts = [], orgs = [] }) => {
    service
      .batchGetOrgDepts({
        lnCodes: tagArr.map(x => x.id),
        flag: 3,
      })
      .then(res => {
        const { orgs: orgsByTag, depts: deptsByTag } = res

        let deptsList = depts.map(item => ({ id: item.id, name: item.name, type: 2 }))

        deptsList = deptsList.filter(x => deptsByTag.every(y => y.deptId !== x.id))

        let orgsList = orgs.map(item => ({
          id: item.id,
          name: item.name,
          type: 1,
          orgType: item.orgType,
        }))

        orgsList = orgsList.filter(x => orgsByTag.every(y => y.orgId !== x.id))
        service
          .sortSendUserList({
            templateId: type === 'ADD' ? id : documentTemplate.id,
            hostSource: [...deptsList, ...orgsList],
          })
          .then(res => {
            const { hostSort = [] } = res
            setOrgs(hostSort.map(x => ({ ...x, key: x.id })))
          })
        if ((orgsByTag.length || deptsByTag.length) && (depts.length || orgs.length)) {
          message.info('系统已自动过滤重复内容')
        }
        setDataDepts(deptsList)
        setDataOrgss(orgsList)
        setUserSelectorVisble(false)
      })
  }
  const handleCancel = () => {
    setUserSelectorVisble(false)
  }
  useEffect(() => {
    getResult(handleChangeUi())
  }, [orgsArr, customArr, tagArr])

  useEffect(() => {
    let JsonValue
    if (value && isArray(value)) {
      JsonValue = value
    } else if (value) {
      JsonValue = JSON.parse(value)
    }
    if (JsonValue) {
      const customs = []
      const orgss = []
      const depts = []
      const tags = []
      JsonValue.forEach(x => {
        switch (x.type) {
          case -1:
            customs.push(x)
            break
          case 1:
            orgss.push(x)
            break
          case 2:
            depts.push(x)
            break
          case 3:
            tags.push(x)
            break

          default:
            break
        }
      })
      setCustomArr(customs)
      setOrgs([...orgss, ...depts])
      setTagArr(tags)
      setDataDepts(depts)
      setDataOrgss(orgss)
    }
  }, [value])
  return (
    <div className={styles.detail}>
      {userSelectorVisble && (
        <OrgSelector
          visible={userSelectorVisble}
          defaultDeptList={dataDepts}
          defaultOrgList={dataOrgs}
          onConfirm={handleConfirm}
          onCancel={handleCancel}
        />
      )}
      {access !== 'READ' ? (
        type === 'ADD' || isOperate ? (
          <Form.Item label={customName || aliasName} className={styles.aliasStyle} {...otherProps}>
            {getFieldDecorator(fieldName, {
              initialValue: value || [],
              rules: [{ required: isFill, message: `请选择${customName || aliasName}！` }],
            })(
              <div className={styles.pickStyle}>
                <Select
                  labelInValue
                  mode="tags"
                  style={{ width: '100%' }}
                  value={allDataList}
                  dropdownStyle={{ display: 'none' }}
                  onDeselect={onDeselect}
                  onBlur={onBlur}
                  getPopupContainer={triggerNode => triggerNode.parentNode}
                />
                <Button className={styles.sendSelect} onClick={handleSelect}>
                  <i className={styles.pickIcon} />
                </Button>
              </div>,
            )}
            {renderSelectorTags()}
          </Form.Item>
        ) : (
          <Form.Item label={aliasName} {...otherProps}>
            {(allDataList.length > 0 &&
              allDataList.map(x => (
                <span className={styles.text} key={x.key}>
                  {x.label}
                </span>
              ))) ||
              '-'}
          </Form.Item>
        )
      ) : (
        <Form.Item label={aliasName} {...otherProps}>
          {(allDataList.length > 0 &&
            allDataList.map(x => (
              <span className={styles.text} key={x.key}>
                {x.label}
              </span>
            ))) ||
            '-'}
        </Form.Item>
      )}
    </div>
  )
}

export default MainDelivery
