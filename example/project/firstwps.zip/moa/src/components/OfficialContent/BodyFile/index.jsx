/*
 * @Description: 详情/正文
 * @Author: dnh
 * @Date: 2022-02-21 15:23:27
 * @LastEditTime: 2022-04-02 18:44:52
 * @LastEditors: dnh
 * @FilePath: \src\components\OfficialContent\BodyFile\index.jsx
 */

import React, { useCallback, useEffect, useRef, useState } from 'react'
import { Button, Form, message } from 'antd'
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import { onFormValueChange } from 'ROOT/reducer/global'
import { outWpsEdit, outTaohong } from 'ROOT/wpsutils/wps'
import { OFFICIAL_TYPE, UPLOAD_FILE_TYPE } from 'ROOT/constant'
import { getFileObjValue, getWpsFieldValue, getFieldsValue } from 'ROOT/utils/manageFieldValue'
import official from 'ROOT/service/official'
import ParagraphPermissionsModal from 'ROOT/components/ParagraphModal'
import BodyFileUploader from './BodyFileUploader'
import TemplateModal from './TemplateModal'
import styles from './index.scss'

const BodyFile = ({
  formProps: { getFieldDecorator, setFieldsValue, validateFieldsAndScroll },
  id, // 模板id
  isCreate = true,
  redheadTemplates = [], // 保存自动套红头的模板
  onChange = () => {},
  data: { aliasName, customName, fieldName, value, isFill },
  // data: { aliasName, customName, fieldName, value, isFill, property },
  formDataSource = [],
  eventTimeList,
  otherProps,
  documentFlowData: { type: officialType }, // officialType = 2, // 1: 发文，2：收文
  getUploadBodyFile,
  previewIndex = 0,
  access = 'READ',
  paragraphPermissionsAccess,
  getDocumentDetail = () => {},
  deptId,
  fullDepartment,
  actions: { onFormValueChange },
  isOperate,
  isFormValueChange,
  type,
}) => {
  const [bodyFileTplList, setBodyFileTplList] = useState([])
  const [isShowTpl, setIsShowTpl] = useState(false)
  const [isChooseBodyFileTpl, setIsChooseBodyFileTpl] = useState(false)
  const [fileList, setFileList] = useState([])
  const [backDoorCount, setBackDoorCount] = useState(0)
  const [fileListData, setFileListData] = useState([])

  const getFileListFromProps = useCallback(() => {
    try {
      return JSON.parse(value)
    } catch (error) {
      return []
    }
  }, [value])

  useEffect(() => {
    if (value) {
      let list
      if (typeof value === 'string') {
        list = getFileListFromProps()
      } else {
        list = value
      }
      setFileList(list)
      setFieldsValue({
        bodyFile: list,
      })
      onFormValueChange(false)
      console.log('正文更新了>>>>>useEffect', isFormValueChange)
    }
  }, [value])

  const ref = useRef()

  useEffect(() => {
    return () => {
      if (ref.current) {
        ref.current.destroy()
      }
    }
  }, [])

  const isReceive = officialType === OFFICIAL_TYPE.RECEIVE

  const isUploaderShow = access === 'WRITE' && fileList.length < 1 && (type === 'ADD' || isOperate)
  // access === 'WRITE' && fileList.length < max && (type === 'ADD' || isOperate)

  // const isUploaderShow = !readonly && fileList.length < maxFileNum && !isHuiQian

  const isReceiveUploaderShow = access === 'WRITE' && (type === 'ADD' || isOperate)
  // const isReceiveUploaderShow = !readonly && !isHuiQian

  const isEditShow = fileList.length > 0 && access === 'WRITE' && (type === 'ADD' || isOperate)

  let btnsShow = true
  let uploadShow = false
  if (isReceive) {
    btnsShow = isReceiveUploaderShow
    uploadShow = isReceiveUploaderShow
  } else {
    btnsShow = isUploaderShow || isEditShow
    uploadShow = isUploaderShow
  }

  // 打开wps创建正文/编辑正文：index:0编辑/-1:创建
  const onWpsEdit = (index = -1, bodyTemplateUrl = '') => {
    let fieldObj = {}
    validateFieldsAndScroll((err, values) => {
      const res = getFieldsValue(formDataSource, values)
      const allFields = getWpsFieldValue(res)
      fieldObj = getFileObjValue(allFields, deptId, fullDepartment, eventTimeList)
    })

    const chooseTemplate =
      redheadTemplates.length && redheadTemplates.filter(i => i.file.childType === 1)

    const fileInfo = chooseTemplate[0] ? chooseTemplate[0].file : ''

    const params = {
      fileList,
      index,
      id,
      isCreate,
      fieldObj,
      isNew: isCreate,
      insertFileUrl: fileInfo.url,
      bodyTemplateUrl,
    }

    outWpsEdit(params, fileChange)
  }

  // wps 保存回调
  const fileChange = (gId, newList = []) => {
    const newFileList = []
    if (gId !== id) {
      message.warning('当前WPS中编辑文档不属于当前公文！')
      return
    }
    if (newList.length) {
      newFileList.push(...newList)
      setFieldsValue({
        bodyFile: newFileList,
      })
      setFileList(newFileList)
    }
    if (onChange) {
      onChange(newFileList)
    }
    message.success('WPS保存成功！')
    onFormValueChange(false)
    console.log('正文更新了>>>>>', isFormValueChange)
  }

  // 选择模板wps编辑正文
  const chooseBodyFileTplConfirm = async file => {
    const tplUrl = file.file.url
    if (!tplUrl) {
      message.error('只支持上传模板')
      return
    }
    const filename = file.file.name
    if (!['doc', 'docx'].includes(filename.split('.').slice(-1).join(''))) {
      message.error('只支持doc、docx文件')
      return
    }

    try {
      await fetch(tplUrl)
    } catch (err) {
      message.error('当前公文模板不可用！')
      return
    }

    setIsShowTpl(false)
    setIsChooseBodyFileTpl(false)
    onWpsEdit(-1, tplUrl)
  }

  // 套红
  const chooseTpl = useCallback(
    file => {
      setIsShowTpl(false)

      const tplUrl = file.file.url
      if (!tplUrl) {
        message.error('只支持上传模板套红')
        return
      }
      message.info('正在套红')

      outTaohong(tplUrl, fileList, previewIndex, id, (index, newFile) => {
        const newFileList = JSON.parse(JSON.stringify(fileList)) || []
        console.log(newFileList, 'newFileList>>>>>>>>>>>>>>>>桃红和')
        // newFileList[index] = {
        //   ...newFile,
        // }
        // this.dealBodyFile(JSON.stringify(fileList), OPER_TYPE.TAOHONG, `套红${newFile.name}文件`)
        // onChange && onChange(JSON.stringify(newFileList))

        console.log(index, newFile, '刷新详情页')
        getDocumentDetail()
        // onRefresh && onRefresh()
      })
    },
    [fileList, id],
  )

  // 获取模板
  const getBodyFileList = async (isChooseBodyFileTpl = false) => {
    const isChooseTpl = isChooseBodyFileTpl ? UPLOAD_FILE_TYPE.BODY_FILE : UPLOAD_FILE_TYPE.TAOHONG
    // isChooseTpl: 1 选择正文模板，2 选择红头模板
    if (isChooseTpl === 1) {
      const res = await official.getBodyFileList()
      setBodyFileTplList(res.files)
    } else {
      const res = await official.getRedHeadList({
        type: 0,
      })
      setBodyFileTplList(res.files)
    }
    setIsShowTpl(true)
    setIsChooseBodyFileTpl(isChooseBodyFileTpl)
  }

  // 选择模板
  const onSelectFile = () => {
    getBodyFileList(true)
  }

  // 选中模板
  const onSelectTemplate = file => {
    if (isChooseBodyFileTpl) {
      chooseBodyFileTplConfirm(file)
    } else {
      chooseTpl(file)
    }
  }

  // 关闭模板弹窗
  const onCloseTmpModal = () => {
    setIsShowTpl(false)
  }

  // 获取设置完成的段落数据
  const onSuccess = data => {
    if (fileList.length) {
      const withParagraphFileList = [...fileList]

      withParagraphFileList[0].paragraph = data.fileListData
      setFileList(withParagraphFileList)

      console.log(withParagraphFileList, '权限列表')

      setFieldsValue({
        bodyFile: withParagraphFileList,
      })
    }
    setFileListData(data.fileListData)
  }

  // 开启段落权限
  const onSetParagraphAuth = () => {
    // ref.current = ParagraphPermissionsModal({
    //   url: 'http://moa-dev.uban360.net:21007/sfs/file?digest=fid28c09294a8ab9aba6cf0ad06ca43dd66',
    //   name: '正文.docx',
    //   fileListData,
    //   callback: onSuccess,
    // })

    if (fileList && fileList.length) {
      const { originalUrl, name } = fileList[previewIndex]

      ref.current = ParagraphPermissionsModal({
        url: originalUrl,
        name,
        fileListData,
        callback: onSuccess,
      })
    } else {
      message.info('未设置正文！')
    }
  }

  // 获取上传的正文word文件
  const getFileList = fileList => {
    if (getUploadBodyFile) {
      getUploadBodyFile(fileList)
    }
  }

  // 正文操作按钮配置
  const actionBtns = [
    {
      show: isUploaderShow,
      name: '创建正文',
      handler: () => onWpsEdit(),
    },
    {
      show: isEditShow,
      name: '编辑正文',
      handler: () => onWpsEdit(previewIndex),
    },
    {
      show: isUploaderShow,
      name: '选择模板',
      handler: onSelectFile,
    },
  ]

  // 开启正文后门
  const openBackDoor = () => {
    // if (backDoorCount >= 6) {
    //   setBackDoorCount(0)
    // } else {
    //   setBackDoorCount(backDoorCount + 1)
    // }
  }

  return (
    <div>
      <TemplateModal
        visible={isShowTpl}
        handleClose={onCloseTmpModal}
        bodyFileTplList={bodyFileTplList}
        onSelectTemplate={onSelectTemplate}
      />
      <Form.Item label={customName || aliasName} {...otherProps}>
        {getFieldDecorator(fieldName, {
          rules: [
            {
              required: isFill,
              message: '请先设置正文',
            },
          ],
        })(
          <div>
            <div
              className={styles.actionList}
              style={{
                display: !btnsShow && !uploadShow ? 'none' : 'flex',
              }}
            >
              {!isReceive && backDoorCount !== 6 ? (
                <div className={styles.actionItem}>
                  {actionBtns.map(
                    i =>
                      i.show && (
                        <Button key={i.name} className={styles.actionBtn} onClick={i.handler}>
                          {i.name}
                        </Button>
                      ),
                  )}
                  <span
                    onClick={onSetParagraphAuth}
                    className={styles.paragraph}
                    style={
                      paragraphPermissionsAccess && paragraphPermissionsAccess === 'WRITE'
                        ? { display: 'inline-block' }
                        : { display: 'none' }
                    }
                  >
                    段落权限设置
                  </span>
                </div>
              ) : (
                <div className={styles.actionItem}>
                  <BodyFileUploader
                    isReceive={isReceive}
                    fileList={fileList}
                    getFileList={getFileList}
                  />
                </div>
              )}
            </div>
            <div className={styles.bodyInfo} onClick={openBackDoor}>
              提示：1. 文件正文一般不超过2500字，签报正文一般不超过1500字；2.
              请严格控制附件的数量和篇幅。
            </div>
          </div>,
        )}
      </Form.Item>
    </div>
  )
}

export default connect(
  state => ({
    isFormValueChange: state.globalInfo.isFormValueChange,
  }),
  dispatch => ({
    actions: bindActionCreators(
      {
        onFormValueChange,
      },
      dispatch,
    ),
  }),
)(Form.create({})(BodyFile))
