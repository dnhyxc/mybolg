/*
 * @Description: 模板弹窗
 * @Author: dnh
 * @Date: 2022-02-23 11:08:51
 * @LastEditTime: 2022-03-07 12:03:35
 * @LastEditors: dnh
 * @FilePath: \src\components\OfficialContent\BodyFile\TemplateModal\index.jsx
 */

import React from 'react'
import { Modal } from 'antd'
import styles from './index.scss'

const TemplateModal = ({ visible, bodyFileTplList = [], handleClose, onSelectTemplate }) => {
  const onClickTemplate = item => {
    onSelectTemplate(item)
  }

  return (
    <Modal visible={visible} title="选择正文" footer={null} width={600} onCancel={handleClose}>
      <div className={styles.wrap}>
        {bodyFileTplList.length > 0 &&
          bodyFileTplList.map(i => (
            <div key={i.id} className={styles.file} onClick={() => onClickTemplate(i)}>
              {i.file.name}
            </div>
          ))}
      </div>
    </Modal>
  )
}

export default TemplateModal
