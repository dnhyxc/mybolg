/*
 * @Description: 正文上传
 * @Author: dnh
 * @Date: 2022-03-01 14:59:55
 * @LastEditTime: 2022-03-24 23:51:59
 * @LastEditors: dnh
 * @FilePath: \src\components\OfficialContent\BodyFile\BodyFileUploader\index.js
 */
import React, { useState } from 'react'
import { Upload, Button, message } from 'antd'
import { UPLOAD_URL } from 'ROOT/service/api'
import { UPLOAD_LIMIT_DOC_TYPE, BODY_FILE_ACCEPT_LIST } from 'ROOT/constant'
import official from 'ROOT/service/official'

const BodyFileUploader = ({
  fileList,
  isReceive,
  getFileList,
}) => {
  const [uploadFiles, setUploadFiles] = useState([])
  // 将文件转为pdf
  const onDoc2Pdf = ({ fileName, srcUrl }) => {
    return official
      .doc2pdf({
        fileName,
        srcUrl,
      })
      .then((res) => {
        const pdfUrl = res.descUrl
        if (getFileList) {
          getFileList({
            url: pdfUrl,
            downloadUrl: pdfUrl,
            noMarksPdfUrl: pdfUrl,
            originalUrl: pdfUrl,
            actionType: 'upload',
            name: fileName,
          })
        }
      })
  }

  // 选择文件上传
  const onChooseFile = ({ file }) => {
    if (file.status === 'done') {
      uploadFiles.push(file.response.fileUrl)
      setUploadFiles([...uploadFiles])
      onDoc2Pdf({
        fileName: file.name,
        srcUrl: file.response.fileUrl,
      })
    } else if (file.status === 'error') {
      message.error(file.response.msg)
    }
  }

  const beforeUpload = (file) => {
    const fileType = file.name.split('.').slice(-1)[0] || ''
    if (UPLOAD_LIMIT_DOC_TYPE.indexOf(fileType) < 0) {
      message.error('仅支持word')
      return false
    }
  }

  return (
    <Upload
      action={UPLOAD_URL}
      accept={BODY_FILE_ACCEPT_LIST}
      showUploadList={false}
      onChange={onChooseFile}
      beforeUpload={beforeUpload}
    >
      <Button>{(isReceive && uploadFiles.length > 0) || fileList.length > 0 ? '重新上传' : '上传文件'}</Button>
    </Upload>
  )
}

export default BodyFileUploader
