/*
 * @Description: 正文空页面
 * @Author: dnh
 * @Date: 2022-03-01 17:52:47
 * @LastEditTime: 2022-03-01 18:05:21
 * @LastEditors: dnh
 * @FilePath: \src\components\RenderPdf\BodyFileEmpty\index.js
 */

import React from 'react'
import { Empty } from 'antd'
import EMPTY_IMG from 'ROOT/assets/images/empty.png'
import styles from './index.scss'

const EmptyBodyFile = () => {
  return (
    <div className={styles['empty-body']}>
      <Empty
        image={EMPTY_IMG}
        imageStyle={{
          width: 155,
          display: 'inline-block',
        }}
        description={
          <span className={styles.hint}>
            <span className={styles['hint-1']}>暂未创建正文</span>
            <span className={styles['hint-2']}>可在上方详细信息区域创建正文</span>
          </span>
        }
      />
    </div>
  )
}

export default EmptyBodyFile
