import React from 'react'
import ClassNames from 'classnames'
import styles from './index.scss'
import TipWrapper from '../../TipWrapper'

export default class IconsControl extends React.Component {
  constructor() {
    super()
    this.state = {}
  }

  print = () => {
    const { onPrint } = this.props
    if (onPrint) onPrint()
  }

  render() {
    const { className, isControlShow, controlIcons } = this.props

    return (
      <div className={ClassNames(className, styles['resize-control'])}>
        <div
          className={ClassNames(styles['resize-control-icons'], {
            [styles.hide]: !isControlShow,
          })}
        >
          <div
            className={styles['resize-control-icon-box']}
            onClick={this.print}
          >
            <TipWrapper
              className={styles['op-tip']}
              tipCls={styles.tip}
              tip="打印"
              direction="up"
            >
              <i className={ClassNames('iconfont icon-dayin', styles['resize-control-icon'])} />
            </TipWrapper>
          </div>
          {!!controlIcons && <div className={styles.splitor} />}
          {controlIcons}
        </div>
      </div>
    )
  }
}
