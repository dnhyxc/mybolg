/*
 * @Description: 渲染pdf
 * @Author: dnh
 * @Date: 2022-02-24 11:44:27
 * @LastEditTime: 2022-03-30 10:41:05
 * @LastEditors: dnh
 * @FilePath: \src\components\RenderPdf\index.jsx
 */
import React, { useEffect, useState, useRef, forwardRef } from 'react'
import { Spin, message } from 'antd'
import pdfjsLib from 'pdfjs-dist-show-signature/webpack'
// import Mark from '../PdfPreview/Mark'
import ClassNames from 'classnames'
import BodyFileImg from 'ROOT/assets/images/bodyfile.png'
import BodyFileImg2 from 'ROOT/assets/images/bodyfile2.png'
import { outWpsEdit } from 'ROOT/wpsutils/wps'
import FileTabIcon from 'ROOT/components/FileTabIcon'
import { BODY_FILE_OPERATION, UPLOAD_LIMIT_DOC_TYPE } from 'ROOT/constant'
import {
  getBodyFilePdfUrl,
  getPreviewOriginUrl,
  getWaterMask,
  getWaterMarkConfig,
  downloadBodyFileOriginal,
  downloadBodyFileWithWaterMarks,
  downloadBodyFilePdf,
} from 'ROOT/wpsutils'
import { getFileObjValue, getWpsFieldValue, getFieldsValue } from 'ROOT/utils/manageFieldValue'
import IconsControl from './IconsControl'
import styles from './index.scss'

const RENDER_TYPE = {
  CANVAS: 'canvas',
  SVG: 'svg',
}

const ROTATE_DEGREES = [0, 90, 180, 270]

const RenderPdf = forwardRef(
  (
    {
      url,
      // marks = [],
      id,
      controlIcons,
      // setFieldsValue,
      onWpsContentChange,
      fileList = [],
      redheadTemplates = [],
      getPreviewIndex,
      fields = [],
      access = 'READ',
      type,
      isOperate,
      deptId = '',
      formType,
      contentWidth = 1000,
      ...props
    },
    ref,
  ) => {
    const [isShow, setIsShow] = useState(false)
    const [isWaterMaskShow, setIsWaterMaskShow] = useState(false)
    const [scale] = useState(2)
    const [rotateIndex] = useState(0)
    const [pageNum, setPageNum] = useState(1)
    const [pageHeight, setPageHeight] = useState(1)
    const [cacheUrl, setCacheUrl] = useState('')
    const [waterMarkUrl, setWaterMarkUrl] = useState('')
    const [isControlShow, setIsControlShow] = useState(true)
    const [cachePdfDocument, setCachePdfDocument] = useState('')
    const [previewUrl, setPreviewUrl] = useState('')
    const [previewIndex, setPreviewIndex] = useState(0)
    const [actionList, setActionList] = useState([])

    const { validateFieldsAndScroll, setFieldsValue } = props.form

    const INITIAL_WIDTH = 793
    // const INITIAL_WIDTH = contentWidth - 90
    // const INITIAL_HEIGHT = INITIAL_WIDTH * 1.414

    // pdf 渲染容器
    const pagesContainer = useRef()

    useEffect(() => {
      getPreviewUrl()
    }, [fileList])

    useEffect(() => {
      if (pagesContainer && previewUrl) {
        renderPdf(previewUrl, pagesContainer)
      }
    }, [previewUrl, pagesContainer])

    useEffect(() => {
      onGetWaterMarkConfig()
    }, [])

    useEffect(() => {
      if (fileList.length) {
        const operations = getActions(fileList[previewIndex], access, formType)
        setActionList(operations)
      }
    }, [fileList, access, formType])

    // 获取水印url
    const onGetWaterMarkConfig = () => {
      getWaterMarkConfig().then(({ isOpen, text }) => {
        setIsWaterMaskShow(isOpen)
        setWaterMarkUrl(getWaterMask({ text }))
      })
    }

    // 获取wps预览url
    const getPreviewUrl = () => {
      const bodyFile = fileList[previewIndex]

      // 创建页编辑正文
      if (type === 'ADD' && formType !== 2 && bodyFile && bodyFile.type) {
        console.log('创建预览>>>>>>>>>>>>>>>>>', bodyFile)
        setPreviewUrl(bodyFile.url)
      }

      // 编辑页编辑正文
      if (type !== 'ADD' && formType !== 2 && bodyFile && bodyFile.type) {
        // 如果设置了段落权限，则走doc2pdf
        if (bodyFile.paragraph && bodyFile.paragraph.length) {
          const list = bodyFile.paragraph.filter(i => i.list.length)
          if (list.length) {
            console.log('权限详情预览>>>>>>>>>>>>>>>>>', bodyFile)
            getPreviewOriginUrl(bodyFile).then(url => {
              setPreviewUrl(url)
            })
          } else {
            console.log('权限设置为空详情预览>>>>>>>>>>>>>>>>>', bodyFile)
            setPreviewUrl(bodyFile.url)
          }
        } else {
          console.log('没设权限详情预览>>>>>>>>>>>>>>>>>', bodyFile)
          setPreviewUrl(bodyFile.url)
        }
      }

      // 收文创建
      if (type === 'ADD' && formType === 2 && bodyFile && !bodyFile.type) {
        console.log('收文创建>>>>>>>>>>>>>>>>>', bodyFile)
        setPreviewUrl(bodyFile.url)
        // setPreviewUrl(url)
      }

      // 收文详情
      if (type !== 'ADD' && formType === 2 && bodyFile && !bodyFile.type) {
        console.log('收文详情>>>>>>>>>>>>>>>>>', bodyFile)
        setPreviewUrl(bodyFile.url)
        // setPreviewUrl(url)
      }

      // 后门装用上传
      if (type === 'ADD' && formType !== 2 && bodyFile && !bodyFile.type) {
        console.log('后门创建专用>>>>>>>>>>>>>>>>>', bodyFile)
        setPreviewUrl(bodyFile.url)
        // setPreviewUrl(url)
      }

      // 后门装用上传
      if (type !== 'ADD' && formType !== 2 && bodyFile && !bodyFile.type) {
        console.log('后门详情专用>>>>>>>>>>>>>>>>>', bodyFile)
        setPreviewUrl(bodyFile.url)
        // setPreviewUrl(url)
      }
    }

    // pdf渲染方法
    const renderPdf = (url, pagesContainer) => {
      // const isPdfChanged = cacheUrl !== url
      getPdfDocument(url).then(pdfDocument => {
        if (!pdfDocument) return
        pdfDocument.getPage(1).then(page => {
          const { width, height } = page.getViewport(1)
          const viewportScale = (scale * INITIAL_WIDTH) / width
          const pageNum = pdfDocument.numPages
          setPageNum(pageNum)
          setIsShow(true)
          setPageHeight(height * viewportScale)
          const renderdPages = new Array(pageNum).fill(1).map((_, index) => index + 1)
          renderdPages.forEach((_, index) => {
            renderPage({
              pdfDocument,
              pageIndex: index + 1,
              scale,
              rotateDegree: ROTATE_DEGREES[rotateIndex],
              pageContainer: pagesContainer.current.children[index],
            })
          })
        })
      })
    }

    // 获取pdf元素
    const getPdfDocument = url => {
      if (cacheUrl === url) {
        return Promise.resolve(cachePdfDocument)
      }
      setCacheUrl(url)
      return pdfjsLib
        .getDocument({
          url,
          cMapUrl: CMAPS_URL,
          cMapPacked: true,
        })
        .promise.then(pdfDocument => {
          setCachePdfDocument(pdfDocument)
          return pdfDocument
          // if (cacheUrl !== url) {
          //   throw new Error('url已改变，丢弃getDocument结果')
          // } else {
          //   // this.cachePdfDocument = pdfDocument
          // }
        })
    }

    // 渲染pdf的方式：svg/canvas
    const renderPage = ({
      pdfDocument,
      pageIndex,
      scale = 1,
      rotateDegree,
      type,
      pageContainer,
    }) => {
      // pageIndex 从1 开始
      return pdfDocument.getPage(pageIndex).then(page => {
        const { width, height } = page.getViewport({ scale: 1 })
        const viewportScale = (scale * INITIAL_WIDTH) / width
        const pageHeight = height * viewportScale

        const viewport = page.getViewport({
          scale: viewportScale,
          rotation: (rotateDegree + page.rotate) % 360,
        })
        const renderType = type || RENDER_TYPE.CANVAS

        const params = {
          page,
          viewport,
          container: pageContainer,
          pageWidth: scale * INITIAL_WIDTH,
          pageHeight,
          rotateDegree,
        }

        // 部分pdf渲染翻转，无法解决，修改为canvas模式渲染
        // 正常pdf的width应该是594，对于正常的pdf，使用svg方式渲染，清晰度更高，如果宽度不正常，svg渲染可能会导致布局混乱，采用canvas
        const renderMethods = {
          [RENDER_TYPE.SVG]: renderPageBySvg,
          [RENDER_TYPE.CANVAS]: renderPageByCanvas,
        }
        return renderMethods[renderType](params)
      })
    }

    // 使用canvas渲染
    const renderPageByCanvas = ({
      page,
      container,
      viewport,
      pageWidth,
      pageHeight,
      rotateDegree,
    }) => {
      const canvas = document.createElement('canvas')
      canvas.width = rotateDegree === 90 || rotateDegree === 270 ? pageHeight : pageWidth
      canvas.height = rotateDegree === 90 || rotateDegree === 270 ? pageWidth : pageHeight
      container.textContent = ''
      container.appendChild(canvas)
      return page.render({
        canvasContext: canvas.getContext('2d'),
        viewport,
      })
    }

    // 使用svg渲染
    const renderPageBySvg = ({ page, container, viewport }) => {
      return page.getOperatorList().then(opList => {
        const svgGfx = new pdfjsLib.SVGGraphics(page.commonObjs, page.objs)
        return svgGfx.getSVG(opList, viewport).then(svg => {
          container.textContent = ''
          container.appendChild(svg)
        })
      })
    }

    // 鼠标移动控制正文悬浮操作条的显示隐藏（打印/下载/编辑）
    const onMouseMove = () => {
      if (isControlShow) {
        setIsControlShow(true)
      }
      // startHide()
    }

    // let timeout = null
    // const startHide = () => {
    //   if (timeout) clearTimeout(timeout)
    //   timeout = setTimeout(() => {
    //     setIsControlShow(false)
    //   }, 3000)
    // }

    // 打印操作
    const onPrintPdf = () => {
      getPdfDocument(cacheUrl).then(async pdfDocument => {
        const printContainer = document.createElement('printContainer')
        for (let i = 0; i < pdfDocument.numPages; i++) {
          const pageContainer = document.createElement('div')
          printContainer.appendChild(pageContainer)
        }

        const { width, height } = await pdfDocument.getPage(1).then(page => {
          const { width, height } = page.getViewport(1)
          return { width, height }
        })

        const pageStyle = document.createElement('style')
        pageStyle.textContent =
          `${
            // eslint-disable-next-line no-useless-concat
            '@supports ((size:A4) and (size:1pt 1pt)) {' + '@page { size: '
            // eslint-disable-next-line no-useless-concat
          }${width}pt ${height}pt;}` + '}'
        Promise.all(
          new Array(pdfDocument.numPages).fill(1).map((it, index) => {
            return renderPage({
              pdfDocument,
              pageIndex: index + 1,
              pageContainer: printContainer.children[index],
            })
          }),
        ).then(() => {
          const iframe = document.createElement('iframe')
          document.body.appendChild(iframe)
          iframe.contentDocument.head.appendChild(pageStyle)
          iframe.contentDocument.body.appendChild(printContainer)
          const afterPrintHandler = () => {
            document.body.removeChild(iframe)
            iframe.contentWindow.removeEventListener('afterprint', afterPrintHandler)
            document.body.removeChild(iframe)
          }
          iframe.contentWindow.addEventListener('afterprint', afterPrintHandler)
          iframe.contentWindow.print()
        })
      })
    }

    // 下载word文件
    const downloadOriginalFile = () => {
      const item = fileList[previewIndex]
      downloadBodyFileOriginal(item)
    }

    // 下载pdf/下载带水印的pdf
    const download = withMarks => {
      const item = fileList[previewIndex]
      if (withMarks) {
        downloadBodyFileWithWaterMarks(item)
      } else {
        downloadBodyFilePdf(item)
      }
    }

    // wps 保存回调
    const fileChange = (gId, newList = []) => {
      if (gId !== id) {
        message.warning('当前WPS中编辑文档不属于当前公文！')
        return
      }
      if (newList.length) {
        setFieldsValue({
          bodyFile: newList,
        })
      }
      if (onWpsContentChange) {
        onWpsContentChange(newList)
      }
      message.success('WPS保存成功！')
    }

    // 编辑
    const onWpsEdit = async (index = -1, bodyTemplateUrl = '') => {
      const chooseTemplate =
        redheadTemplates.length && redheadTemplates.filter(i => i.file.childType === 1)

      const fileUrl = chooseTemplate[0] ? chooseTemplate[0].file.url : ''

      let fieldObj = {}

      validateFieldsAndScroll((err, values) => {
        if (!err) {
          const res = getFieldsValue(fields, values)
          const allFields = getWpsFieldValue(res)
          fieldObj = getFileObjValue(allFields, deptId)
        }
      })

      const params = {
        fileList,
        index,
        id,
        isCreate: false,
        fieldObj,
        isNew: true,
        insertFileUrl: fileUrl,
        bodyTemplateUrl,
      }

      outWpsEdit(params, fileChange)
    }

    const getActions = (item, access, formType) => {
      let downloadOperation
      if (UPLOAD_LIMIT_DOC_TYPE.includes(item.type)) {
        downloadOperation = {
          type: BODY_FILE_OPERATION.DOWNLOAD,
          icon: 'icon-xiazai',
          children: [
            {
              type: 'download_original',
              name: '下载word文件',
              handler: downloadOriginalFile,
            },
            {
              type: 'download_pdf',
              name: '下载pdf',
              handler: download,
            },
            {
              type: 'download_watermark',
              name: '下载pdf(带水印)',
              handler: () => download(true),
            },
          ],
        }
      } else {
        downloadOperation = {
          type: BODY_FILE_OPERATION.DOWNLOAD,
          icon: 'icon-xiazai',
          children: [
            {
              type: 'download_pdf',
              name: '下载pdf',
              handler: download,
            },
            {
              type: 'download_watermark',
              name: '下载pdf(带水印)',
              handler: () => download(true),
            },
          ],
        }
      }
      const downLoadAction = [downloadOperation]

      const editAction = [
        {
          type: BODY_FILE_OPERATION.EDIT,
          handler: () => onWpsEdit(previewIndex),
          icon: 'icon-gongzuobianji',
          name: '编辑',
        },
      ]

      if (access.bodyFile === 'WRITE') {
        if ((type === 'ADD' || isOperate) && formType !== 2) {
          return [...downLoadAction, ...editAction]
        }
        return [...downLoadAction]
      }
      return [...downLoadAction]
    }

    // 切换预览的pdf
    const onPreviewIndexChange = index => {
      setPreviewIndex(index)
      getPreviewIndex(index)
      const bodyFile = fileList[index]
      if (bodyFile) {
        getBodyFilePdfUrl(bodyFile).then(url => {
          setPreviewUrl(url)
        })
      }
    }

    // const operations = getFileOperations(fileList[previewIndex])

    const pages = new Array(pageNum).fill(1)
    const originalPageWidth = INITIAL_WIDTH * scale
    const transformWidthHeight = rotateIndex === 1 || rotateIndex === 3
    const pdfWidth = transformWidthHeight ? pageHeight : originalPageWidth
    const pdfHeight = transformWidthHeight ? originalPageWidth : pageHeight

    return (
      <div className={styles.container} ref={ref}>
        <Spin spinning={!isShow} style={{ height: '300px' }}>
          <div
            className={styles.preview}
            style={{
              display: isShow ? 'block' : 'none',
            }}
            onMouseMove={onMouseMove}
          >
            {fileList.length > 1 && (
              <div className={ClassNames(styles['filelist-box'])}>
                {fileList.map((item, index) => (
                  <div
                    key={index}
                    className={ClassNames(
                      styles.bodyfile,
                      index === previewIndex ? styles.bodyfile_active : '',
                    )}
                    onClick={() => onPreviewIndexChange(index)}
                  >
                    <div className={styles['bodyfile-icon']}>
                      <i className={ClassNames('iconfont icon-duigou', styles.icon)} />
                    </div>
                    <img
                      className={styles['copyfile-img']}
                      src={item.isSealed ? BodyFileImg2 : BodyFileImg}
                      alt=""
                    />
                    <div className={styles['bodyfile-name']}>
                      <div className={styles['name-ellipsis']} title={item.name}>
                        {item.name}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
            {isWaterMaskShow && (
              <div
                className={styles.watermark}
                style={{ backgroundImage: `url(${waterMarkUrl})` }}
              />
            )}
            <IconsControl
              isControlShow={isControlShow}
              size={scale}
              controlIcons={
                <div className={ClassNames(styles.opBox)}>
                  {actionList &&
                    actionList.length &&
                    actionList.map(item => <FileTabIcon key={item.name} data={item} />)}
                </div>
              }
              onPrint={onPrintPdf}
            />
            <div ref={pagesContainer} className={styles.pagesContainer}>
              {pages.map((_, index) => (
                <div
                  key={index}
                  className={styles.page} // 793/1121
                  style={{
                    width: pdfWidth,
                    height: pdfHeight,
                  }}
                />
              ))}
            </div>
          </div>
        </Spin>
      </div>
    )
  },
)

export default RenderPdf
