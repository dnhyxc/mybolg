import React, { useState, useEffect, useRef } from 'react'
import { Modal, message, Tree, Radio, Spin } from 'antd'
import ClassNames from 'classnames'
import service from 'ROOT/service'
import { FIELD_TYPE } from 'ROOT/constant'
import { cloneDeep } from 'lodash'
import { outWpsEdit } from 'ROOT/wpsutils/wps'
import { getWpsFieldValue, getFileObjValue } from 'ROOT/utils/manageFieldValue'
import styles from './index.scss'

const { TreeNode } = Tree
const SendOrgFile = props => {
  const {
    visible,
    onClose,
    onSuccess,
    emptyText = '请从左侧选择组织或部门',
    id,
    fields,
    mainSendField,
    copySendField,
    deptId,
    redheadTemplates,
  } = props
  const [allOrgData, setAllOrgData] = useState([])
  const [checkedKeys, setCheckedKeys] = useState([])
  const [selectUsers, setSelectUsers] = useState([])
  const [OrgUserList, setOrgUserList] = useState([])
  const [UPOrgList, setUPOrgList] = useState([]) // 上行文
  const [PARALLELOrgList, setPARALLELOrgList] = useState([]) // 平行文
  const [value, setValue] = useState(undefined)
  const [loading, setLoading] = useState(false)

  const fieldsRef = useRef(null)

  const onCheck = (checkedKeysValue, { node }) => {
    const { props: { eventKey = '' } = {} } = node
    const selectKeys = []
    const arr = [...checkedKeys]
    const index = arr.findIndex(x => x === eventKey)
    if (index !== -1) {
      arr.splice(index, 1)
    } else {
      arr.push(eventKey)
    }

    setCheckedKeys(arr)
    for (let i = 0; i < arr.length; i++) {
      selectKeys.push(allOrgData.find(item => item.orgCode === arr[i]))
    }
    setSelectUsers(selectKeys)
  }

  const initState = () => {
    setCheckedKeys([])
    setSelectUsers([])
  }
  const handleCancelSecretSend = () => {
    setOrgUserList(Array.from(new Set([...UPOrgList, ...PARALLELOrgList])))
    setValue(undefined)
    initState()
    onClose && onClose()
  }

  const onWpsEdit = async (index = -1, bodyTemplateUrl = '', values) => {
    let filterRedheadTemplate = []

    if (value === 1 && redheadTemplates && redheadTemplates.length) {
      filterRedheadTemplate = redheadTemplates.filter(i => i.file.childType === 2)
    } else if (value === 2) {
      filterRedheadTemplate = redheadTemplates.filter(i => i.file.childType === 3)
    }

    const fileUrl = filterRedheadTemplate[0] ? filterRedheadTemplate[0].file.url : ''

    const allFields = getWpsFieldValue(values)

    const bodyFile = allFields.filter(i => i.fieldName === 'bodyFile')

    const fileList = bodyFile && bodyFile.length && bodyFile[0].value

    const fieldObj = getFileObjValue(allFields, deptId)

    const params = {
      fileList: JSON.parse(fileList) || [],
      index,
      id,
      isCreate: false,
      fieldObj,
      isNew: true,
      insertFileUrl: fileUrl,
      bodyTemplateUrl,
    }

    outWpsEdit(params, fileChange)
  }

  // wps 保存回调
  const fileChange = (gId, newList = []) => {
    if (gId !== id) {
      message.warning('当前WPS中编辑文档不属于当前公文！')
      return
    }
    sendGroupDocument(newList)
  }

  // 集团发文接口
  const sendGroupDocument = newField => {
    if (fieldsRef.current) {
      fieldsRef.current.forEach(i => {
        if (i.fieldName === 'bodyFile') {
          i.value = newField
        }
      })

      service.sendGroupDocument({ id, orgs: selectUsers, fields: fieldsRef.current }).then(() => {
        message.success('集团发文成功')
        initState()
        // eslint-disable-next-line no-unused-expressions
        onSuccess && onSuccess()
      })
    }
  }

  const handleOkSecretSend = () => {
    if (selectUsers.length === 0) return message.error('请选择需要发文的集团或公司')

    const cpFields = cloneDeep(fields)

    cpFields.forEach(x => {
      if (x.children && x.children.length > 0) {
        x.children.forEach((y, i) => {
          if (y.fieldName === FIELD_TYPE.MAIN_SEND) {
            x.children[i] = mainSendField
          }

          if (y.fieldName === FIELD_TYPE.COPY_SEND) {
            x.children[i] = copySendField
          }
        })
      }

      if (x.fieldName === FIELD_TYPE.MAIN_SEND) {
        x = mainSendField
      }

      if (x.fieldName === FIELD_TYPE.COPY_SEND) {
        x = copySendField
      }
    })

    fieldsRef.current = cpFields

    const withTemplates = []

    if (redheadTemplates && redheadTemplates.length) {
      redheadTemplates.forEach(i => {
        if (i.file.childType === 2 || i.file.childType === 3) {
          withTemplates.push(i)
        }
      })
    }

    if (!withTemplates.length) {
      service.sendGroupDocument({ id, orgs: selectUsers, fields: cpFields }).then(() => {
        message.success('集团发文成功')
        initState()
        // eslint-disable-next-line no-unused-expressions
        onSuccess && onSuccess()
      })
      return
    }

    onWpsEdit(0, '', cpFields)
  }

  const handleDeleteUser = orgCode => {
    const newSelect = checkedKeys.filter(i => i !== orgCode)
    const delSelectusers = selectUsers.filter(d => d.orgCode !== orgCode)
    setCheckedKeys(newSelect)
    setSelectUsers(delSelectusers)
  }

  const handleDelAllUser = () => {
    initState()
  }

  const initOrgListData = () => {
    setLoading(true)
    service
      .getGroupOrgList({})
      .then(res => {
        setLoading(false)
        const { orgs = [] } = res
        orgs.forEach(x => {
          if (x.orgStyle === 'org' && x.permittedDocType.indexOf('UP') !== -1) {
            UPOrgList.push(x)
          }
          if (x.orgStyle === 'org' && x.permittedDocType.indexOf('PARALLEL') !== -1) {
            PARALLELOrgList.push(x)
          }
        })
        setUPOrgList(UPOrgList)
        setPARALLELOrgList(PARALLELOrgList)
        setOrgUserList(Array.from(new Set([...UPOrgList, ...PARALLELOrgList])))
        setAllOrgData(orgs)
      })
      .finally(() => {
        setLoading(false)
      })
  }
  const handleClick = () => {
    if (!value) {
      message.error('请选择公文类型')
    }
  }
  const handleRenderOrgTree = list => {
    if (Array.isArray(list) && list.length > 0) {
      return list.map(l => {
        return (
          <TreeNode
            disableCheckbox={!value}
            checkable={l.level !== 0}
            key={l.orgCode}
            icon={
              l.level === 2 ? (
                <span
                  className={ClassNames('iconfont icon-CombinedShape1', styles['tree-icon'])}
                  style={{ color: '#ffa400' }}
                />
              ) : (
                <span
                  className={ClassNames('iconfont icon-qiye1', styles['tree-icon'])}
                  style={{ color: l.level < 1 ? '#4f84d2' : '#23c172' }}
                />
              )
            }
            title={l.shortOrgName}
          >
            {l.children && l.children.length > 0 && handleRenderOrgTree(l.children)}
          </TreeNode>
        )
      })
    }
    return []
  }

  const handleChangeRadio = e => {
    initState()
    setValue(e.target.value)
    const map = {
      1: UPOrgList,
      2: PARALLELOrgList,
    }
    setOrgUserList(map[e.target.value])
  }
  useEffect(() => {
    initOrgListData()
  }, [])
  return (
    <Modal
      title="选择组织"
      visible={visible}
      onOk={handleOkSecretSend}
      onCancel={handleCancelSecretSend}
      width="750px"
      okText="确认"
      cancelText="取消"
      bodyStyle={{ padding: 0 }}
    >
      <div className={styles['selelct-warp']}>
        <div className={styles.tree}>
          <div className={styles.type}>
            <div className={styles.label}>行文类型：</div>
            <Radio.Group onChange={handleChangeRadio} value={value} disabled={loading}>
              <Radio value={1}>上行文</Radio>
              <Radio value={2}>平行文</Radio>
            </Radio.Group>
          </div>
          {loading ? (
            <Spin className={styles.spin} />
          ) : (
            <Tree
              className={styles['user-tree']}
              checkable
              showIcon
              selectable={false}
              onCheck={onCheck}
              checkedKeys={checkedKeys}
              onClick={handleClick}
            >
              {OrgUserList.length > 0 ? handleRenderOrgTree(OrgUserList) : null}
            </Tree>
          )}
        </div>
        <div className={styles.users}>
          <div className={styles['user-top']}>
            <div className="text">已选择的：</div>
            <div className={styles['all-clear']} onClick={handleDelAllUser}>
              清除
            </div>
          </div>
          <div className={styles['user-list']}>
            {selectUsers.length > 0 &&
              selectUsers.map(item => (
                <div className={styles['user-item']} key={item.orgCode}>
                  {item.level === 2 ? (
                    <span
                      className={ClassNames('iconfont icon-CombinedShape1', styles['user-icon'])}
                      style={{ color: '#ffa400' }}
                    />
                  ) : (
                    <span
                      className={ClassNames('iconfont icon-qiye1', styles['user-icon'])}
                      style={{ color: item.level < 1 ? '#4f84d2' : '#23c172' }}
                    />
                  )}
                  <div className={styles['user-info']}>
                    <div className={styles.name}>{item.shortOrgName}</div>
                  </div>
                  <span
                    className={ClassNames('iconfont icon-shanchu1', styles.close)}
                    onClick={() => {
                      handleDeleteUser(item.orgCode)
                    }}
                  />
                </div>
              ))}
            {selectUsers.length === 0 && <div className={styles.empty}>{emptyText}</div>}
          </div>
        </div>
      </div>
    </Modal>
  )
}
export default SendOrgFile
