/*
 * @Description:
 * @Author: dnh
 * @Date: 2022-03-08 15:55:41
 * @LastEditTime: 2022-03-09 18:11:25
 * @LastEditors: dnh
 * @FilePath: \src\layout\SiderBar\index.jsx
 */
import React, { useState, useEffect, useRef } from 'react'
import { bindActionCreators } from 'redux'
import { connect } from 'react-redux'
import { Sidebar, RootPath, globalStore } from '@xm/util'
import XmiconReact from '@xm/icons-guangxicmcc-moa/dist/react'
import { routersArr } from 'ROOT/router/config'
import { setCollapsed } from 'ROOT/reducer/global'
import service from 'ROOT/service'
import styles from './index.scss'

const { Context, Consumer } = RootPath

const SiderBar = props => {
  const { getPath, actions } = props
  const [menuList, setMenuList] = useState([])

  const siderbarRef = useRef()

  const renderIcon = (item, isActive, collaps) => {
    actions.setCollapsed({
      collapsed: collaps,
    })
    return (
      <XmiconReact
        name={item}
        size={16}
        style={{ verticalAlign: 'baseline', marginRight: collaps ? 0 : 10 }}
      />
    )
  }
  const renderMenus = () => {
    service.getUserDocumentRoleInfo({ uid: globalStore.get('uid') }).then(res => {
      const { roles = [] } = res.info
      const authRouter = routersArr.filter(x => {
        // x.path = getPath(x.path)
        return roles.indexOf(x.role) !== -1 || !x.isHide
      })
      setMenuList(authRouter)
    })
  }
  useEffect(() => {
    renderMenus()
  }, [])

  return (
    <div className={styles['siderbar-warp']} ref={siderbarRef}>
      <Sidebar
        className={styles.sidebar}
        title="公文管理"
        menus={menuList}
        needCollapsed
        renderIcon={renderIcon}
      />
    </div>
  )
}

const mapActions = dispatch => ({
  actions: bindActionCreators(
    {
      setCollapsed,
    },
    dispatch,
  ),
})

export default Consumer(Context)(
  connect(
    ({ globalInfo }) => ({
      orgId: globalInfo.baseInfo.orgId,
      collapsed: globalInfo.collapsed,
    }),
    mapActions,
  )(SiderBar),
)
