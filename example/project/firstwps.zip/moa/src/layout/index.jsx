import React, { useEffect, useState } from 'react'
import _ from 'lodash'
import { connect } from 'react-redux'
import { bindActionCreators } from 'redux'
import { globalStore } from '@xm/util'
import { Spin } from 'antd'
import { setBaseInfo } from 'ROOT/reducer/global'
import { routersArr } from 'ROOT/router/config'
import SiderBar from './SiderBar'
import styles from './index.scss'

const mapActions = dispatch => ({
  actions: bindActionCreators(
    {
      setBaseInfo,
    },
    dispatch,
  ),
})

const App = ({ actions, children }) => {
  const [loading, setLoading] = useState(true)
  const [isShow, setIsShow] = useState(true)
  useEffect(() => {
    const list = [...routersArr,{ path: 'mydocument.?create=true' },{ path: 'watermark-service.*' }]
    const isShowList = list.map(x => {
      return location.href.search(`${x.path}$`) !== -1
    })
    setIsShow(isShowList.some(x => x))
  }, [location.href])

  useEffect(() => {
    globalStore.getAsyncs(
      ['orgId', 'orgName', 'uid', 'name'],
      (err, result) => {
        if (!err) {
          setLoading(false)

          actions.setBaseInfo({
            ...result,
          })
        }
      },
      false,
    )
  }, [])

  return (
    <div className={styles['app-warp']}>
      <Spin spinning={loading} style={{ maxHeight: '100vh' }}>
        {isShow && <SiderBar />}
        <div className={styles['content-warp']}>{children}</div>
      </Spin>
    </div>
  )
}

export default _.flowRight([connect(null, mapActions)])(App)
