const path = require('path')
const webpack = require('webpack')
const HtmlWebpackBeforeCompilerPlugin = require('@xm/webpack-html-before-compiler-plugin')
const CopyWebpackPlugin = require('copy-webpack-plugin')
const RuntimePublicPathPlugin = require('webpack-runtime-public-path-plugin')
const pkg = require('./package.json')
const getRuntimeEnv = require('./config/config.dev')

const { version } = pkg
const PORT = 8080
const isDev = process.env.NODE_ENV === 'development'
const externals = require(`./config/externals`)

const toCamelCase = str =>
  str.replace(/^-/, '').replace(/-(\w)(\w+)/g, (a, b, c) => b.toUpperCase() + c.toLowerCase())

const devEnv = process.env.NODE_ENV
const runtimeEnv = getRuntimeEnv(devEnv)

const isTest = process.env.NODE_ENV === 'test'
const entry = path.resolve(__dirname, isDev || isTest ? './src/index.js' : './src/app.js')

const output = {
  path: path.resolve(__dirname, './dist'),
  filename: '[name].js',
}

const babelOptions = {}
const appName = pkg.name

const plugins = [
  new CopyWebpackPlugin([
    {
      from: 'node_modules/pdfjs-dist-show-signature/cmaps/',
      to: 'cmaps/',
    },
    {
      from: 'lib/WpsOAAssist',
      to: 'WpsOAAssist/',
    },
  ]),
]

let host = 'sub.moa-dev.uban360.net'
let proxyUrl = 'http://moa-dev.uban360.net:21007'

if (isTest) {
  host = 'sub.moa-test.uban360.net'
  proxyUrl = 'http://moa-test.uban360.net:21007'
}

if (!isDev && !isTest) {
  output.library = toCamelCase(appName)
  output.libraryTarget = 'var'
  plugins.push(
    ...[
      new RuntimePublicPathPlugin({
        runtimePublicPath: `"//" + window._APP_CONFIG.domain + "/web/new-web/${appName}/${version}/"`,
      }),
      new webpack.DefinePlugin({
        CMAPS_URL: `"//" + window._APP_CONFIG.domain + "/web/new-web/${appName}/${version}/cmaps/"`,
        APP_NAME: `'${appName}'`,
        STATIC_PREFIX: `"//" + window._APP_CONFIG.domain + "/web/new-web/${appName}/${version}/"`,
      }),
    ],
  )
} else {
  plugins.push(
    ...[
      new HtmlWebpackBeforeCompilerPlugin({
        isBaas: true,
      }),
      new webpack.DefinePlugin({
        CMAPS_URL: '/cmaps/',
        APP_NAME: `'${appName}'`,
        STATIC_PREFIX: `'//${runtimeEnv.devHostname}:${PORT}/'`,
      }),
    ],
  )
}

babelOptions.plugins = [
  [require.resolve('babel-plugin-const-replace-import'), { libraries: externals }],
]


module.exports = {
  compileDependencies: ['@xm_icon', 'icons-guangxicmcc-moa'],
  host,
  htmlTemplateUrl: path.resolve(__dirname, './public/index.html'),
  port: '8080',
  buildByVersion: {
    enable: true,
    version: isDev ? '0.0.1' : pkg.version,
  },
  entry: {
    index: entry,
  },
  plugins,
  output,
  alias: {
    ROOT: path.resolve(__dirname, './src'),
  },
  staticPath: path.resolve('src/assets'),
  isExtractCss: false,
  babelOptions,
  externals,
  cssModule: {
    enable: true,
    localIdentName: '[local]-[hash:base64:5]',
  },
  proxy: {
    '/access': {
      target: proxyUrl,
      secure: false,
      changeOrigin: true,
      timeout: 360000,
    },
    '/webadmin': {
      target: 'http://moa-dev.uban360.net:21007',
      secure: false,
      changeOrigin: true,
    },
    '/web-search/': {
      target: proxyUrl,
      secure: false,
      changeOrigin: true,
    },
    '/sm-supervision': {
      target: proxyUrl,
      secure: false,
      changeOrigin: true,
    },
    '/sfs/file': {
      target: 'http://moa-dev.uban360.net:21007',
      secure: false,
      changeOrigin: true,
    },
    '/sfs/webUpload/file': {
      target: proxyUrl,
      secure: false,
      changeOrigin: true,
    },
    '/web/filepreview': {
      target: proxyUrl,
      secure: false,
      changeOrigin: true,
    },
    '/doconline': {
      target: proxyUrl,
      secure: false,
      changeOrigin: true,
    },
    '/web-office': {
      target: proxyUrl,
      secure: false,
      changeOrigin: true,
    },
    '/pdfgenerator': {
      target: proxyUrl,
      secure: false,
      changeOrigin: true,
    },
    '/baas-contact': {
      target: proxyUrl,
      secure: false,
      changeOrigin: true,
    },
    '/baas': {
      target: proxyUrl,
      secure: false,
      changeOrigin: true,
    },
    '/baas-easylabel': {
      target: proxyUrl,
      secure: false,
      changeOrigin: true,
    },
    '/baas-admin': {
      target: proxyUrl,
      secure: false,
      changeOrigin: true,
    },
    // 批语接口代理
    '/user-comment': {
      target: proxyUrl,
      secure: false,
      changeOrigin: true,
    },
    '/baas-moa-document-split': {
      target: proxyUrl,
      secure: false,
      changeOrigin: true,
    },
    '/webaace': {
      target: proxyUrl,
      secure: false,
      changeOrigin: true,
    },
    '/baas-wf-portal': {
      target: proxyUrl,
      secure: false,
      changeOrigin: true,
    },
  },
  htmlWebpackPluginOptions: {
    minify: {
      removeComments: true,
      collapseWhitespace: !isDev,
      useShortDoctype: true,
    },
    template: path.resolve(__dirname, './public/index.html'),
  },
  env: {
    development: {
      rules: [
        {
          test: /\.less$/,
          include: /entadmin-main|antd|@ant-design|rc-lance/,
          use: [
            'style',
            'css',
            {
              loader: 'less',
              options: {
                javascriptEnabled: true,
              },
            },
          ],
        },
        {
          test: /\.(ttc)(\?.*)?$/,
          use: ['url-loader'],
        },
      ],
    },
    production: {
      devtool: 'none',
      rules: [
        {
          test: /\.(ttc)(\?.*)?$/,
          use: ['url-loader'],
        },
      ],
    },
  },
  buildNotifier: {
    title: 'abc build',
    show: true,
    timeout: 2,
  },
}
