/**
 * 获取公共配置
 */

const HOST_PRESET = {
  dev: {
    hostname: 'baas.uban360.net',
    protocol: 'http:',
    port: 21006,
  },
  test: {
    hostname: 'moa-test.uban360.net',
    protocol: 'http:',
    port: 21007,
  },
  'moa-dev': {
    hostname: 'moa-dev.uban360.net',
    protocol: 'http:',
    port: 21007,
  },
  'moa-test': {
    hostname: 'moa-test.uban360.net',
    protocol: 'http:',
    port: 21007,
  },
}

module.exports = (devenv = 'dev') => {
  const currentHostPreset = HOST_PRESET[devenv] || HOST_PRESET.dev;

  return {
    ...currentHostPreset,
    proxyUrl: `${currentHostPreset.protocol}//${currentHostPreset.hostname}:${currentHostPreset.port}`,
    devHostname: `sub.${currentHostPreset.hostname}`,
  }
}
