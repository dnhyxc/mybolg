const config = {
  antd: 'antd',
  // axios: 'axios',
  classnames: 'classNames',
  lodash: '_',
  moment: 'moment',
  // react: 'React',
  redux: 'Redux',
  'js-cookie': 'Cookies',
  'prop-types': 'PropTypes',
  // 'react-dom': 'ReactDOM',
  // 'react-loadable': 'ReactLoadable',
  'react-redux': 'ReactRedux',
  'react-router-dom': 'ReactRouterDOM',
  'redux-actions': 'ReduxActions',
}
config['@xm/util'] = 'WEB_UTIL'

module.exports = config