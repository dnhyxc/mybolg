import React from 'react'
import _ from 'lodash'
import { css } from 'emotion'

const Loading = ({ type, width = 60 }) => {
	const staticStyle = css`margin: 30px auto;`
	const absStyle = css`
	position: absolute;
	top: 50%;
	left: 50%;
	transform: translate(-50%, -50%);
`

	return (
		<div className={type === 'static' ? staticStyle : absStyle}>
			<img
				src={_.get(window, '_APP_CONFIG.loading', '//statics.jituancaiyun.com/config/loading.gif')}
				style={{ width }}
				alt=""
			/>
		</div>
	)
}

export default Loading
