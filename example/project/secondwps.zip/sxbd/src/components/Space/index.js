import React from 'react'

export default (x) => {
    return <div {...x} />
}