import React, { memo } from 'react'
import { cx } from 'emotion'

const Icon = memo(({ type, ...restProps }) => {
	return <i className={cx('iconfont', type)} {...restProps} />
})

export default Icon
