import React from 'react'
import { Input } from 'antd'

export default (data) => {
  const { name, value, editable } = data
  return (
    <div style={{ width: '100%' }}>
      {editable ?
        <Input value={name === '_dept' ? (value && value.label) : value} disabled />
        :
        <div>{value || '-'}</div>
      }
    </div>
  )
}
