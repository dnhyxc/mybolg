import React, { useState, useEffect } from 'react'
import {
  Upload,
  Button,
  Space,
} from 'antd'
import { UploadOutlined, PaperClipOutlined } from '@ant-design/icons'
import { downloadUrl } from 'ROOT/utils'

let first = true

export default itemProps => {
  const { value, mutators, props, editable, schema, form } = itemProps
  const xComponentProps = schema['x-component-props'] || {}
  const [fileList, setFileList] = useState(value)

  useEffect(() => {
    if (first && value) {
      setFileList(value)
      first = false
    }
	}, [value])

  const handleChange = (info = {}) => {
    try {
      console.log(info, 222)
      const singleFile = info.file || {}
      let fileList = [...(info.fileList || []) ]
      fileList = fileList.map((file) => {
        if (file.response) {
          file.fileUrl = file.response.fileUrl
        }
        return file
      })
      console.log('fileList', fileList);
      setFileList(fileList)
      if (singleFile.status === 'done' && singleFile.response.code === 200) {
        mutators.change(fileList.map(item => ({
          name: item.name,
          fileUrl: item.fileUrl,
          uid: item.uid,
          // code, status
        })))
      }
    } catch (error) {
      console.log('报错', error);
    }
  }

  return 0
    ? <Upload {...xComponentProps} fileList={fileList} onChange={handleChange}>
        <Button icon={<UploadOutlined />}>上传文件</Button>
      </Upload>
    : <div>
      <Space wrap>
        123
        {value && value.length > 0 && value.map(item => {
          return (
            <Button key={item.uid} type="link" href={downloadUrl(item.fileUrl, item.name)}>
              <PaperClipOutlined style={{ color: 'rgba(0,0,0,.45)' }} />{item.name}
            </Button>
          )
        })}
      </Space>
    </div> 
}