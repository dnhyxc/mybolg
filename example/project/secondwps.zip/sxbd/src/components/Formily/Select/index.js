import React, { useState } from 'react'
import { Input, Modal } from 'antd'
import { PreviewText } from '@formily/react-shared-components'
import SelectOrg from './SelectOrg'

export default itemProps => {
  const [visible, setVisible] = useState(false) 
  const { value, mutators, props, editable, schema } = itemProps
  const xComponentProps = schema['x-component-props'] || {}
  const {
    placeholder = '请选择',
    listAllAction,
    myListAction,
    searchAction,
    isWidth,
    isRit,
    type,
    parentOrgId,
  } = xComponentProps

  const adapterValue = val =>
    Array.isArray(val)
      ? val.map(item => ({
        id: +(item.departmentId || item.id),
        name: item.name,
        type: 'DEPT',
        // _raw: item._data || item,
      }))
      : val

  let names = ''
  if (Array.isArray(value)) {
    names =
      value.length > 0
        ? value.map(x => x.showPath).join('，')
        : ''
  }

  const combineDeptList = (list) => {
    const deleteName = ['active', 'avatar', 'checked', 'children', 'description', 
    'dragOver', 'dragOverGapBottom', 'dragOverGapTop', 'expanded', 'externalId', 'halfChecked', 'icon', 'isDeleted', 'isLeaf', 'judgeExist', 'loaded', 'loading', 'lower']
    list.forEach(item => {
      deleteName.map(key => {
        item.hasOwnProperty(key) && delete item[key]
      })
    })
    return list
  }

  return editable ? (
    <div  style={{width:isWidth?'200px':'100%'}}>
      <Input
        readOnly
        value={names}
        onClick={() => setVisible(true)}
        placeholder={placeholder}
      />
      {visible && (<SelectOrg
        visible
        API_GET_ROOT_ORG={myListAction}
        API_GET_LIST_ALL={listAllAction}
        API_SEARCH_LIST={searchAction}
        type={type}
        parentOrgId={parentOrgId}
        orgList={value}
        isRit={isRit}
        onCancel={() => setVisible(false)}
        onSubmit={(selectedDept) => {
          mutators.change(combineDeptList(selectedDept))
        }}
       />
      )}
    </div>
  ) : (
    <PreviewText value={names} />
  )
}
{/* <XmTree 
  visible 
  type="multiDept" 
  ableChooseRoot={false} 
  ableChooseOrg={false} 
  ableChooseUser={false} 
  API_GET_ROOT_ORG={myListAction}
  API_GET_LIST_ALL={listAllAction}
  API_SEARCH_LIST={searchAction}
  deptList={value}
  treeCancelCallback={() => setVisible(false)} 
  treeCallback={({deptList}) => {
    mutators.change(adapterValue(deptList))
    setVisible(false) 
  }} 
/>  */}
