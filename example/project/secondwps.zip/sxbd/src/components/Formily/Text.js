import React from 'react'

const Text = ({ children }) => {
  return (
    <div style={{ color: 'red' }}>
      <span>1、请上传公司OA外单位来文单，及外单位会议通知作为附件。</span>
      <br />
      <span>2、参会人员为“其他”抽调或借调人员时，会议通知将由起草人通知本人参会。</span>
    </div>
  )
}

export default Text