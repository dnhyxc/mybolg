export default [
	{
		key: 'web',
		title: 'web容器',
		path: '/web',
		visible: true,
		children: [
			{
				key: 'home',
				title: '首页',
				path: '/home',
				visible: true,
				children: [
					{
						key: 'test',
						title: '测试页面',
						path: '/test',
						visible: true,
					},
				],
			},

			{
				key: 'web/WorkLetter',
				title: '工作协调函',
				path: '/workletter',
				visible: true,
				children: [
					{
						key: 'web/WorkLetter/area/index',
						title: '区公司工作协调函',
						path: '/area/start',
						visible: true,
					},
					{
						key: 'web/WorkLetter/area/process',
						title: '区公司工作协调函',
						path: '/area/approve',
						visible: true,
					},
					{
						key: 'web/WorkLetter/area/feedback',
						title: '区公司工作协调函',
						path: '/area/feedback',
						visible: true,
					},
					{
						key: 'web/WorkLetter/citydept/index',
						title: '市公司上传部门工作协调函',
						path: '/citydept/start',
						visible: true,
					},
					{
						key: 'web/WorkLetter/citydept/process',
						title: '市公司上传部门工作协调函',
						path: '/citydept/approve',
						visible: true,
					},
					{
						key: 'web/WorkLetter/citydept/feedback',
						title: '区公司工作协调函',
						path: '/citydept/feedback',
						visible: true,
					},
					{
						key: 'web/WorkLetter/city/index',
						title: '市公司工作协调函',
						path: '/city/start',
						visible: true,
					},
					{
						key: 'web/WorkLetter/city/process',
						title: '市公司工作协调函',
						path: '/city/approve',
						visible: true,
					},
					{
						key: 'web/WorkLetter/profession/index',
						title: '专业公司工作协调函',
						path: '/profession/start',
						visible: true,
					},
					{
						key: 'web/WorkLetter/profession/process',
						title: '专业公司工作协调函',
						path: '/profession/approve',
						visible: true,
					},
					{
						key: 'web/WorkLetter/profession/feedback',
						title: '专业公司工作协调函',
						path: '/profession/feedback',
						visible: true,
					},
				],
			},
			{
				key: 'web/MeetNotice',
				title: '会议通知',
				path: '/meetNotice',
				visible: true,
				children: [
					{
						key: 'web/MeetNotice/infomanagedp/index',
						title: '信息技术管理部会议通知',
						path: '/infomanagedp/start',
						visible: true,
					},
					{
						key: 'web/MeetNotice/infomanagedp/process',
						title: '信息技术管理部会议通知',
						path: '/infomanagedp/approve',
						visible: true,
					},
					{
						key: 'web/MeetNotice/foreignunit/index',
						title: '外单位会议通知',
						path: '/foreignunit/start',
						visible: true,
					},
					{
						key: 'web/MeetNotice/foreignunit/process',
						title: '外单位会议通知',
						path: '/foreignunit/approve',
						visible: true,
					},
					{
						key: 'web/MeetNotice/PC/index',
						title: '党委会议通知',
						path: '/PC/start',
						visible: true,
					},
					{
						key: 'web/MeetNotice/PC/process',
						title: '党委会议通知',
						path: '/PC/approve',
						visible: true,
					},
					{
						key: 'web/MeetNotice/directlyPC/index',
						title: '直属机关党委会议通知',
						path: '/directlyPC/start',
						visible: true,
					},
					{
						key: 'web/MeetNotice/directlyPC/process',
						title: '直属机关党委会议通知',
						path: '/directlyPC/approve',
						visible: true,
					},
					{
						key: 'web/MeetNotice/DI/index',
						title: '纪委会议通知',
						path: '/DI/start',
						visible: true,
					},
					{
						key: 'web/MeetNotice/DI/process',
						title: '纪委会议通知',
						path: '/DI/approve',
						visible: true,
					},
					{
						key: 'web/MeetNotice/directlyDI/index',
						title: '直属机关纪委会议通知',
						path: '/directlyDI/start',
						visible: true,
					},
					{
						key: 'web/MeetNotice/directlyDI/process',
						title: '直属机关纪委会议通知',
						path: '/directlyDI/approve',
						visible: true,
					},

				],
			},
			{
				key: 'web/RuleOfficial',
				title: '规章制度',
				path: '/ruleOfficial',
				visible: true,
				children: [
					{
						key: 'web/RuleOfficial/RuleOfficialReport/index',
						title: '规章制度发文',
						path: '/RuleOfficialReport/start',
						visible: true,
					},
					{
						key: 'web/RuleOfficial/RuleOfficialReport/detail',
						title: '规章制度发文',
						path: '/RuleOfficialReport/approve',
						visible: true,
					},
					{
						key: 'web/RuleOfficial/PartyReport/index',
						title: '党委规章制度发文',
						path: '/PartyReport/start',
						visible: true,
					},
					{
						key: 'web/RuleOfficial/PartyReport/detail',
						title: '党委规章制度发文',
						path: '/PartyReport/approve',
						visible: true,
					},
				],
			},
			{
				key: 'web/Home',
				title: 'test',
				path: '/home',
				visible: true,
			},
			{
				key: 'web/Bus',
				title: '用车申请',
				path: '/bus',
				visible: true,
				children: [
					{
						key: 'web/Bus/pc/index',
						title: '用车申请',
						path: '/pc/index',
						visible: true,
					},
					{
						key: 'web/Bus/pc/process',
						title: '用车申请',
						path: '/pc/process',
						visible: true,
					},
					{
						key: 'web/Bus/h5/index',
						title: '用车申请',
						path: '/h5/index',
						visible: true,
					},
					{
						key: 'web/Bus/h5/process',
						title: '用车申请',
						path: '/h5/process',
						visible: true,
					},
				]
			},
		],
	},
]
