import { init } from '@rematch/core'
import loadingPlugin from '@rematch/loading'
import immerPlugin from '@rematch/immer'

import myStore from './myStore'

const immer = immerPlugin()
const loading = loadingPlugin({})

const store = init({
	plugins: [ immer, loading ],
	models: {
		myStore,
	},
})

export default store
