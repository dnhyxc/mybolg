import React, { useState, useEffect } from 'react'
import service from 'ROOT/service'
import { message } from 'antd'

const useMyInfo = (params) => {
  const isSetStorage = params && params.isSetStorage ? params.isSetStorage : false // 兼容水印需要存储到localstorage读取
  const [myInfo, setMyInfo] = useState({})

  const fetchData = async () => {
    const res = await service.getMyself()
    if (res.success) {
      setMyInfo(res.data)
      if (isSetStorage) {
        localStorage.setItem('userInfo',JSON.stringify(res.data))
      }
    } else {
      message.error(res.msg || '网络错误')
    }
  }

  useEffect( () => {
    fetchData()
  }, [])

  return myInfo
}

export default useMyInfo