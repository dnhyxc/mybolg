import React, { useState, useEffect } from 'react'
import service from 'ROOT/service'

export default () => {
  const [list, setList] = useState();
  useEffect(() => {
    service
    .getCurrentUserOrgType({

    })
    .then(data => {
      if(data.success) {
        setList(data.data)
      }
    })
    
  }, [])
  return list
}