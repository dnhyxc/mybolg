import React, { useEffect } from 'react'
import _ from 'lodash'
import { connect } from 'react-redux'

const mapState = ({ myStore }) => ({
	myInfo: myStore.myInfo,
})

const mapActions = ({ myStore }) => ({
	actions: { getMyInfo: myStore.getMyInfo },
})

const Home = ({ myInfo, actions, children }) => {
	/* 测试代码，请移除 start */

	console.log(myInfo, 222)

	useEffect(() => {
		actions.getMyInfo()
	}, [])

	/* 测试代码，请移除 end */

	return <div>hello, home, <h3>{children}</h3></div>
}

export default _.flowRight([ connect(mapState, mapActions) ])(Home)
