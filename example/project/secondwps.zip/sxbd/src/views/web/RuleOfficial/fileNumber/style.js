import {css} from 'emotion'
 
export const fileStyle =css`
    display:flex;
    .input-text{
        width:240px;
        .options {
        display: none;
        &.active {
            display: block;
        }
}
    }
    .ant-form-item .ant-select{
        width:200px !important;
    }
    .select{
        width:200px !important;
    }
    .sort{
        width:160px;
    }
`