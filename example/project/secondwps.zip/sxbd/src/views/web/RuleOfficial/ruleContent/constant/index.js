export const urgencyOptions = [
  { label: '特级', value: 1 },
  { label: '急件', value: 2 },
  { label: '一般', value: 3 },
]
export const secretOptions = [
  { label: '一般', value: 1 },
  { label: '内部信息', value: 2 },
  { label: '普通商密', value: 3 },
  { label: '核心商密', value: 4 },
]

export const typeRule = [
  { label: '制定', value: 1 },
  { label: '修订', value: 2 },
  { label: '废止', value: 3 },
  { label: '上级制度转发', value: 4 },
]
export const ruleLevel = [
  { label: '重大制度', value: 1 },
  { label: '基础制度', value: 2 },
  { label: '专项制度', value: 3 },
]
