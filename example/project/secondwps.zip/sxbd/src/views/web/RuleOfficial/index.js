import React from 'react'
import 'ROOT/styles/iconfont/index.css'

const RuleOfficialReport = ({ children }) => {
	return children
}

export default RuleOfficialReport
