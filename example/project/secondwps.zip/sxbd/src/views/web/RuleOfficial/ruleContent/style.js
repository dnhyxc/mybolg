import { css} from 'emotion'

export const  ruleContent=css`
    .text_area{
        width:560px;
        height: 82px !important;
        background: #FFFFFF;
        border: 1px solid #CBCFD6;
        border-radius: 2px;
    }
    .button{
    box-shadow: 0 -2px 3px 0 rgb(0 0 0 / 10%);
    background-color:#fff; 
    }
`
