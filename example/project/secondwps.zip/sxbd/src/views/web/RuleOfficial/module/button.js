export const saveBtn = (callback) => commonBtn({
    name: '保存',
    type: 'primary',
    callback,
  })


  const commonBtn = ({ name, type, callback}) => ({
    name,
    type,
    onClick: () => {
      if (typeof callback === 'function') callback()
    },
  })