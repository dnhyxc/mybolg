import React, { useState, useEffect } from 'react'
import { Modal, Divider, Descriptions } from 'antd'
import { SchemaMarkupForm, FormButtonGroup, Submit, Reset, createAsyncFormActions, createFormActions, FormEffectHooks } from '@formily/antd'
import { Input, NumberPicker, FormMegaLayout, Select, Radio, FormItemGrid, DatePicker, FormBlock } from '@formily/antd-components'
import Editor from 'ROOT/components/Formily/Editor'
import onSiteSchema from '../common/onSiteSchema'
import onVidioSchema from '../common/onVidioSchema'
import siteVidioSchema from '../common/siteVidioSchema'
import previewSchame from '../common/previewSchame'

export default ({
  onCancel,
  schame,
  actions,
  type,
  meetTitle
}) => {
  const [defaultValue, setDefaultValue] = useState()
  const [signer, setSigner] = useState()
  const [schema, setSchema] = useState()
  Editor.isFieldComponent = true

  actions.getFormState().then((data) => {
    setDefaultValue(data.values)
    const { signer } = data.values || {};
    setSigner(signer)
  })

  useEffect(() => {
    if (type) {
      setSchema(previewSchame)
    } else {
      const meetingAategory = actions.getFieldValue('meetingAategory')
      const meetingForm = actions.getFieldValue('meetingForm')
      Promise.all([meetingAategory, meetingForm]).then(res => {
        if (res[0] != 3) {
          setSchema(onSiteSchema)
        } else if (res[1] == 1) {
          setSchema(onSiteSchema)
        } else if (res[1] == 2) {
          setSchema(onVidioSchema)
        } else if (res[1] == 3) {
          setSchema(siteVidioSchema)
        }
      })
    }

  })

  const components = {
    TextArea: Input.TextArea,
    Input,
    NumberPicker,
    FormMegaLayout,
    Select,
    Radio,
    RadioGroup: Radio.Group,
    RangePicker: DatePicker.RangePicker,
    Editor

  }

  return (
    <div
      // visible={true}
      // onCancel={onCancel}
      // footer={null}
      // width={1000}
    >
      <h1 style={{ textAlign: 'center' }}>{meetTitle || '-'}</h1>
      <div style={{ textAlign: 'end', marginBottom: -20 + 'px', marginRight: 10 + 'px  ' }}>签发人: {signer || '-'}</div>
      <Divider />
      <SchemaMarkupForm
        schema={schema}
        components={components}
        editable={false}
        previewPlaceholder='-'
        value={defaultValue}
      >
      </SchemaMarkupForm>
      {/* <div style={{ display: 'flex', justifyContent: 'space-between', padding: ' 0 30px' }}>
        <div>起草人: {user || '-'}</div>
        <div>联系电话: {phone || '-'}</div>
      </div> */}
    </div>
  )
}
