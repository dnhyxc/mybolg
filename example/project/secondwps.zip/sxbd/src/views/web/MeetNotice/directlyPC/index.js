import React, { useEffect, useState, useMemo, useRef } from 'react'
import { SchemaMarkupForm, FormButtonGroup, Submit, Reset, createAsyncFormActions, createFormActions, FormEffectHooks } from '@formily/antd'
import { Input, NumberPicker, FormMegaLayout, Select, Radio, FormItemGrid, DatePicker } from '@formily/antd-components'
import { Button, message, Modal, Space } from 'antd'
import { getQueryString, closeTheWindow } from 'ROOT/utils'
import getUserOrgType from 'ROOT/hooks/getUserOrgType'
import SelectDept from 'ROOT/components/Formily/SelectDept'
import Upload from 'ROOT/components/Formily/Upload'
import SelectMember from 'ROOT/components/Formily/SelectMember'
import PersonalInfo from 'ROOT/components/Formily/PersonalInfo'
import Text from 'ROOT/components/Formily/Text'
import Dept from 'ROOT/components/Formily/Dept'
import { Buttons } from 'ROOT/components/Process'
import Editor from 'ROOT/components/Formily/Editor'
import service from 'ROOT/service'
import { getLocalTime } from 'ROOT/constants/index'
import { closeBtn, deleteBtn, saveAndExit } from '../module/buttons'
import { formConfig, getMeetingSerialNumber } from '../common/PCDIconfig'
import { meetingType } from '../module/config'
import schema from './schema'
import useMyInfo from 'ROOT/hooks/useMyInfo'
import PreviewModal from '../module/previewModal'
import EditableInput from 'ROOT/components/Formily/Editable'
import WpsEditor from 'ROOT/components/Formily/WpsEditor'
import moment from 'moment'
const { confirm } = Modal
const { onFieldValueChange$, onFieldInputChange$ } = FormEffectHooks

export default (props) => {
  const typeIndex = 3
  const meetTitle = `中国移动通信集团广西有限公司${meetingType[typeIndex].name}`
  const [initValue, setInitValue] = useState({});
  const [editable, setEditable] = useState(true);
  const [showPreviewModal, setShowPreviewModal] = useState(false)
  const actions = useMemo(() => createAsyncFormActions(), []);
  const userOrgList = getUserOrgType()
  const { userTaskId, procKey, appId, procFormDataKey } = useMemo(() => getQueryString(props.location.search), []);
  // const myInfo = useMyInfo({ isRequest: !procFormDataKey })
  const myInfo = useMyInfo({ isSetStorage: true })
  const formId = useRef(+procFormDataKey)

  SelectDept.isFieldComponent = true;
  PersonalInfo.isFieldComponent = true;
  Dept.isFieldComponent = true;
  Upload.isFieldComponent = true
  SelectMember.isFieldComponent = true
  Text.isFieldComponent = true
  Editor.isFieldComponent = true
  EditableInput.isFieldComponent = true
  WpsEditor.isFieldComponent = true

  useEffect(() => {
    const { loginOrgId, cityOrgName, loginOrgName } = myInfo
    if (userOrgList && loginOrgId) {
      // _meetTitle.current = getMeetingTitle(userOrgList, loginOrgId, cityOrgName, loginOrgName)
      actions.setFieldValue('serialNumber', getMeetingSerialNumber(userOrgList, loginOrgId, cityOrgName))
    }
  }, [myInfo, userOrgList])

  //  数据回填
  useEffect(() => {
    actions.setFieldValue('formTitle', meetTitle)
    if (procFormDataKey) {
      service.getFormData({
        reportId: procFormDataKey, // 获取详情，也就是初始值
      }).then((res) => {
        if (res && res.data) {
          let data = res.data.data;
          setInitValue(data)
          resetContentProps(procFormDataKey)
          actions.setFormState(state => {
            state.values = data
          });
        }
      })
    }
  }, []);

  useEffect(() => {
    if (!procFormDataKey) {
      actions.setFieldState('rangePicker', state => {
        state.value = [moment().format('YYYY-MM-DD HH:mm'), moment().add(1, 'days').format('YYYY-MM-DD HH:mm')]
      })
      service.saveForm({
        type: meetingType[typeIndex].type,
        classify: {
          name: meetingType[typeIndex].name,
          englishName: meetingType[typeIndex].englishName,
        },
        config: formConfig,
        data: {
          _taskLevel: '3',
          isFeedback: '2',
          draftDate: moment().format('YYYY年MM月DD日'),
        },
      }).then(res => {
        const { data } = res
        resetContentProps(data)
        formId.current = data
      })
    }
  }, [])

  const resetUserInfo = () => {
    const { linkPath, loginName, loginOrgName, loginMobile } = myInfo
    // setMeetTitle(`${loginOrgName}会议通知`) // 不清楚结构，只能先mock，申请表单走个人信息接口
    actions.setFieldState('user', state => {
      state.value = loginName
    })
    actions.setFieldState('phone', state => {
      state.value = loginMobile
    })
    actions.setFieldState('_dept', state => {
      // const org = orgList.map(i => i.name).join('\\')
      state.routDeptId = 'test'
      state.props.enum = linkPath && linkPath.length > 0 ? linkPath.map(item => ({
        value: item.deptId,
        label: item.linkPath,
      })) : []
      if (initValue._dept && initValue._dept.value) {
        state.value = initValue._dept
      } else {
        state.value = linkPath && linkPath.length > 0 ? {
          value: linkPath[0].deptId,
          label: linkPath[0].linkPath,

        } : { value: '', label: '' }
      }
    })
  }
  useEffect(() => {
    resetUserInfo()
  }, [myInfo])

  const onMount = ({ access, editMode }) => {
    if (access && Object.keys(access).length > 0 && editMode && editMode.includes('web')) {
      Object.keys(access).forEach(key => {
        actions.setFieldState(key, state => {
          switch (access[key]) {
            case 'NONE':
              state.display = false
              break
            case 'READ':
              state.editable = false
              break
            case 'WRITE':
              state.editable = true
              state.display = true
              break
            default: break
          }
        })
      })
    } else {
      // actions.setFormState((state) => {
      //   state.editable = false
      // })
    }
  }


  useEffect(() => {
    window.addEventListener('process', () => finishSubmit())
  }, [])

  const finishSubmit = () => {
    deleteDraft()
  }

  const commonCommit = async () => {
    // todo 需要判断是新建表单的保存还是二次编辑表单的保存，走的接口不一样
    const data = await actions.submit()
    let values = data.values;
    const res = service.upDateForm({
      config: formConfig,
      data: values,
      reportId: formId.current,
    })
    // const res = await procFormDataKey ? service.upDateForm({
    //   config: formConfig,
    //   data: values,
    //   reportId: procFormDataKey,
    // }) : service.saveForm({
    //   type: meetingType[typeIndex].type,
    //   classify: {
    //     name: meetingType[typeIndex].name,
    //     englishName: meetingType[typeIndex].englishName,
    //   },
    //   config: formConfig,
    //   data: values,
    // })
    return res
  }


  const resetContentProps = (procFormDataKey) => {
    actions.setFieldState('fileList', (state) => {
      state.props['x-component-props'] = {
        ...state.props['x-component-props'],
        reportId: procFormDataKey,
        type: meetingType[typeIndex].type,
        config: formConfig,
      }
    })
  }

  const submitForm = async () => {
    const res = await commonCommit()
    const data = await actions.submit()
    let values = data.values;
    if (res.success) {
      // return { id: +formId.current || res.data, values: values }
      return +formId.current
    }
    throw new Error('保存出错')
  }

  const saveDraft = async (callback) => {
    const info = localStorage.getItem('userInfo') ? JSON.parse(localStorage.getItem('userInfo')) : {}

    const data = await actions.submit()
    const res = await service.saveDraft({
      appId,
      appTasks: [{
        appTaskId: formId.current.toString(),
        businessType: 2,
        emergencyLevel: +data.values._taskLevel,
        handleEntry: [{
          handleType: 0, // 草稿
          handlerId: info.loginUid,
        }],
        processType: meetingType[typeIndex].name,
        sponsorId: info.loginUid,
        jumpToDetail: 1,
        title: meetTitle,
        detailUrl: decodeURIComponent(procFormDataKey ? `${location.href.replace('/extra-forms/', '/extra-forms-h5/').replace(/backurl=.*?&|backurl=.*?$/, '')}` : `${location.href.replace('/extra-forms/', '/extra-forms-h5/').replace(/backurl=.*?&|backurl=.*?$/, '')}&procFormDataKey=${formId.current}`),
        webDetailUrl: decodeURIComponent(procFormDataKey ? `${location.href.replace(/backurl=.*?&|backurl=.*?$/, '')}` : `${location.href.replace(/backurl=.*?&|backurl=.*?$/, '')}&procFormDataKey=${formId.current}`),
        // detailUrl: decodeURIComponent(procFormDataKey ? `${location.href.replace('/extra-forms/', '/extra-forms-h5/')}` : `${location.href.replace('/extra-forms/', '/extra-forms-h5/')}&procFormDataKey=${formId.current}`),
        // webDetailUrl: decodeURIComponent(procFormDataKey ? `${location.href}` : `${location.href}&procFormDataKey=${formId.current}`),
      }],
    })
    if (res.success) {
      message.success('操作成功', () => {
        if (typeof callback === 'function') callback(res)
      })
    }
  }

  const saveForm = async (callback, isDraft) => {
    const res = await commonCommit()
    if (res.success) {
      if (isDraft) {
        saveDraft(callback)
      } else {
        message.success('操作成功', () => {
          if (typeof callback === 'function') callback(res)
        })
      }
    }
  }

  const deleteDraft = async () => {
    const info = localStorage.getItem('userInfo') ? JSON.parse(localStorage.getItem('userInfo')) : {}

    const res = await service.deleteDraft({
      appId,
      appTasks: [{
        appTaskId: formId.current.toString(),
        handlerIds: [info.loginUid],
      }],
    })
    if (res.success) {
      message.success('操作成功', () => {
        closeTheWindow(props.location.search)
      })
    }
  }

  const preview = () => {
    setShowPreviewModal(true)
  }

  const cancelPreview = () => {
    setEditable(true);
    actions.getFieldValue('meetingAategory').then(data => {
      if (data === '2') {
        actions.setFieldState('meetingName', state => {
          state.props.editable = false;
        });
      } else {
        actions.setFieldState('meetingName', state => {
          state.props.editable = true;
        });
      }
    })
  }

  const deleteForm = async () => {
    confirm({
      content: '你选择了注销当前文档，系统将删除该文档，是否继续？',
      onOk: async () => {
        const res = await service.deleteForm({
          reportId: procFormDataKey,
        })
        if (res.success) {
          deleteDraft()
        } else {
          message.error(data.msg)
        }
      },
    })
  }

  const buttonGroup = () => {
    const array = [
      {
        name: '保存退出',
        async: false,
        onClick: () => {
          saveForm(() => {
            closeTheWindow(props.location.search)
          }, true)
        }
      },
      {
        name: '保存',
        async: false,
        onClick: () => {
          saveForm('', true)
        }
      }
    ]
    if (procFormDataKey) {
      array.push({
        name: '注销文档',
        async: false,
        onClick: () => {
          deleteForm()
        }
      })
    }
    // const array = [closeBtn, saveAndExit(() => {
    //   saveForm(() => {
    //     closeTheWindow(props.location.search)
    //   }, true)
    // })];
    // if (procFormDataKey) {
    //   array.push(deleteBtn(() => {
    //     deleteForm()
    //   }))
    // }
    return array
  }
  const expressionScope = {
    getColor: (text, color) => { return <div style={{ color: `${color}` }}>{text}</div> },
    labelAlign: 'top',
    disabledDate: (current) => { return current && current <= moment().subtract(1, 'days').endOf('day') },

  }
  const uesEffects = () => {
    onFieldInputChange$('rangePicker').subscribe(date => {
      if (date.value && date.value.length > 0) {
        const checkDate = moment(date.value[0]).unix()
        const currnetDate = moment().unix()
        if (checkDate < currnetDate) {
          actions.setFieldValue('rangePicker', null)
          message.warn('会议开始时间不能小于当前时间')
        }
      }
    })
  }
  const components = {
    TextArea: Input.TextArea,
    Input,
    NumberPicker,
    FormMegaLayout,
    Upload,
    Select,
    Radio,
    RadioGroup: Radio.Group,
    RangePicker: DatePicker.RangePicker,
    SelectDept,
    PersonalInfo,
    Dept,
    Upload,
    SelectMember,
    Text,
    Editor,
    EditableInput,
    WpsEditor
  }
  return (
    <div>
      <h1 className='form-title'>{meetTitle}</h1>
      <SchemaMarkupForm
        schema={schema}
        components={components}
        actions={actions}
        initialValues={initValue}
        expressionScope={{ ...expressionScope }}
        previewPlaceholder='-'
        editable={editable}
        effects={() => {
          uesEffects()
        }}
      >
        <div className='button-group'>
          {/* <Button onClick={() => { preview() }} >预览</Button>
            <div style={{marginRight: 10 +'px'}}></div>
            <Button onClick={() => { cancelPreview() }}>取消预览</Button>
            <div style={{marginRight: 10 +'px'}}></div> */}

          {editable &&
            <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
              <Space>
                {/* <Button onClick={() => preview()}>预览</Button> */}
                {/* {buttonGroup().map(item => <Button key={item.name} type={item.type} onClick={item.onClick}>{item.name}</Button>)} */}
                <Buttons
                  procKey={procKey}
                  appId={appId}
                  onMount={onMount}
                  onSubmit={submitForm}
                  onSubmitOpen={async () => {
                    const data = await actions.submit()
                    return data.values
                  }}
                  extraButtons={buttonGroup()}
                // onFinish={finishSubmit}
                />
              </Space>
            </div>
          }
        </div>
      </SchemaMarkupForm>
      {showPreviewModal &&
        <PreviewModal
          onCancel={() => setShowPreviewModal(false)}
          schame={''}
          actions={actions}
          type='common'
        />
      }
    </div>
  )
}