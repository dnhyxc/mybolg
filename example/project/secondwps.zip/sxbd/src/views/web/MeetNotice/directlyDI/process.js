import React, { useEffect, useState, useMemo } from 'react';
import { SchemaMarkupForm, FormButtonGroup, createAsyncFormActions, createFormActions, FormEffectHooks } from '@formily/antd'
import { Input, NumberPicker, FormMegaLayout, Select, Radio, FormItemGrid, DatePicker } from '@formily/antd-components'
import schema from './schema'
import {
  Tabs,
} from 'antd'
import { Buttons, Steps } from 'ROOT/components/Process'
import { getQueryString, closeTheWindow } from 'ROOT/utils'
import useSigner from 'ROOT/hooks/useSigner'
import service from 'ROOT/service';
import { getLocalTime } from 'ROOT/constants/index'
import { meetingType } from '../module/config'
import SelectDept from 'ROOT/components/Formily/SelectDept'
import PersonalInfo from 'ROOT/components/Formily/PersonalInfo'
import Upload from 'ROOT/components/Formily/Upload'
import Dept from 'ROOT/components/Formily/Dept'
import SelectMember from 'ROOT/components/Formily/SelectMember'
import Text from 'ROOT/components/Formily/Text'
import Editor from 'ROOT/components/Formily/Editor'
import { formConfig } from '../common/PCDIconfig'
import EditableInput from 'ROOT/components/Formily/Editable'
import WpsEditor from 'ROOT/components/Formily/WpsEditor'
import moment from 'moment'

const { TabPane } = Tabs

export default (props) => {
  const typeIndex = 5;
  const [initValue, setInitValue] = useState({});
  const [draftValue, setDraftValue] = useState({})
  const [meetTitle, setMeetTitle] = useState('')
  const actions = useMemo(() => createAsyncFormActions(), []);
  const { userTaskId, userTaskStutus, appId, procFormDataKey, userTaskFlags } = useMemo(() => getQueryString(props.location.search), []);
  const { signer, date } = useSigner({
    userTaskId,
    nodeName: meetingType[typeIndex].signerNodeName,
  });

  SelectDept.isFieldComponent = true;
  PersonalInfo.isFieldComponent = true;
  Dept.isFieldComponent = true;
  Upload.isFieldComponent = true
  SelectMember.isFieldComponent = true
  Text.isFieldComponent = true
  Editor.isFieldComponent = true
  EditableInput.isFieldComponent = true
  WpsEditor.isFieldComponent = true

  useEffect(() => {
    if (Object.keys(initValue).length > 0) {
      actions.setFormState(state => {
        state.values = (signer || date) ? { ...initValue, signer, issuanceTime: getLocalTime(date) } : initValue
      })
    }
  }, [initValue])

  // 判断是否有签发人以及签发时间
  useEffect(() => {
    console.log(signer);
    actions.setFieldState('*(signer)', state => {
      state.value = signer || '-'
    })
    actions.setFieldState('*(issuanceTime)', state => {
      state.value = getLocalTime(date) || '-'
    })
  }, [signer, date])

  //  数据回填
  useEffect(() => {
    actions.setFieldState('*', state => {
      state.props.description = null;
    });
    if (procFormDataKey) {
      service.getFormData({
        reportId: procFormDataKey,
      }).then((res) => {
        if (res && res.data) {
          let data = res.data.data;
          let operator = res.data.operator;
          actions.setFormState(state => {
            state.values = { ...data }
          })
          setInitValue({...data})
          const { formTitle, meetingCount } = data || {}
          const { orgId = '' } = operator || {}
          setMeetTitle(formTitle) // 审批表单走 详情数据
          // actions.setFormState(state => {
          //   state.values = signer ? { ...data, signer } : data
          // })
          if (meetingCount) {
            actions.getFieldValue('serialNumber').then(data => {
              actions.setFieldValue('serialNumber', data.replace(' ', `${meetingCount > 9 ? meetingCount : "0" + meetingCount}`))
            })
            // actions.setFieldValue('serialNumber', `${meetingType[typeIndex].name}(${new Date().getFullYear()})${orgId}-${meetingCount || '-'}号`);
          }
        }
      })
    }
  }, [])

  const commonCommit = async () => {
    const data = await actions.submit()
    const res = await service.upDateForm({
      config: formConfig,
      data: data.values,
      reportId: procFormDataKey,
    })
    return res
  }

  useEffect(() => {
    window.addEventListener('process', () => finishSubmit())
  }, [])

  const finishSubmit = () => {
    closeTheWindow(props.location.search)
  }

  const submitForm = async () => {
    const res = await commonCommit()
    const data = await actions.submit()
    let values = data.values;
    if (res.success) {
      // return { id: procFormDataKey || res.data, values: values }
      return Promise.resolve()
    }
    throw new Error('保存出错')
  }

  const onMount = ({ access, editMode, draft }) => {
    if (access && Object.keys(access).length > 0 && editMode && editMode.includes('web')) {
      Object.keys(access).forEach(key => {
        if (key === 'isEditable' && access[key] === 'WRITE') {
          setShowSaveBtn(true)
          resetFormState()
          return
        }
        actions.setFieldState(key, state => {
          switch (access[key]) {
            case 'NONE':
              state.display = false
              break
            case 'READ':
              state.editable = false
              break
            case 'WRITE':
              state.editable = true
              state.display = true
              break
            default: break
          }
        })
      })
    } else {
      // actions.setFormState((state) => {
      //   state.editable = false
      // })
    }

    if(draft) {
      actions.setFormState(state => {
        state.values = draft
      })
      // setDraftValue(draft)
    }
  }


  const expressionScope = {
    getColor: (text, color) => { return <div style={{ color: `${color}` }}>{text}</div> },
    labelAlign: 'left',
    disabledDate: (current) => { return current && current <= moment().subtract(1, 'days').endOf('day') },

  }
  const components = {
    TextArea: Input.TextArea,
    Input,
    NumberPicker,
    FormMegaLayout,
    Upload,
    Select,
    Radio,
    RadioGroup: Radio.Group,
    RangePicker: DatePicker.RangePicker,
    SelectDept,
    PersonalInfo,
    Dept,
    SelectMember,
    Text,
    Editor,
    EditableInput,
    WpsEditor

  }
  return (
    <div>
      <h1 className='form-title'>{meetTitle}</h1>
      <SchemaMarkupForm
        schema={schema}
        components={components}
        actions={actions}
        // initialValues={draftValue && Object.keys(draftValue).length > 0 ? draftValue : initValue}
        expressionScope={{ ...expressionScope }}
        previewPlaceholder='-'
        editable={false}
      >
        <div className='button-group'>
          <Buttons
            userTaskId={userTaskId}
            // onFinish={finishSubmit}
            onMount={onMount}
            onSubmitOpen={async () => {
              const data = await actions.submit()
              return data.values
            }}
            onSubmit={submitForm}
          />
        </div>
      </SchemaMarkupForm>
      <Tabs defaultActiveKey="1">
        <TabPane tab="审批流程" key="1">
          <Steps
            userTaskId={userTaskId}
          />
        </TabPane>
      </Tabs>
    </div>
  )
}