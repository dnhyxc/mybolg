import React, { useEffect, useState, useMemo } from 'react';
import { SchemaMarkupForm, FormButtonGroup, createAsyncFormActions, createFormActions, FormEffectHooks } from '@formily/antd'
import { Input, NumberPicker, FormMegaLayout, Select, Radio, FormItemGrid, DatePicker } from '@formily/antd-components'
import schema from './schema'
import {
  Tabs,
  Button,
  Space,
  Spin
} from 'antd'
import { Buttons, Steps } from 'ROOT/components/Process'
import { getQueryString, closeTheWindow } from 'ROOT/utils'
import useSigner from 'ROOT/hooks/useSigner'
import SelectDept from 'ROOT/components/Formily/deptSelect'
import service from 'ROOT/service';
import PersonalInfo from 'ROOT/components/Formily/PersonalInfo'
import Upload from 'ROOT/components/Formily/Upload'
import Editor from 'ROOT/components/Formily/Editor'
import SelectMember from 'ROOT/components/Formily/SelectMember'
import EditableInput from 'ROOT/components/Formily/Editable'
import { getDiffMeetType, diffMeetLimit, getLimitDays, formConfig } from './config'
import { meetingType } from '../module/config'
import { getLocalTime } from 'ROOT/constants/index'
import WpsEditor from 'ROOT/components/Formily/WpsEditor'
import { closeBtn, deleteBtn, setWpsPermissionBtn } from '../module/buttons'
import PermissionModal from '../module/permissionModal'
import moment from 'moment'


import Dept from 'ROOT/components/Formily/Dept'
const { TabPane } = Tabs
const { onFieldValueChange$, onFieldInputChange$, onFormSubmitValidateStart$ } = FormEffectHooks

export default (props) => {
  const typeIndex = 0;
  const [initValue, setInitValue] = useState({});
  const [draftValue, setDraftValue] = useState({})
  const [meetTitle, setMeetTitle] = useState('')
  const [showPermissionModal, setPermissionModal] = useState(false)
  const [backFillDataSouce, setBackFillDataSouce] = useState([])
  const [wpsFile, setWpsFile] = useState({})
  const [permissionObj, setPermissionObj] = useState({})
  const [loading, setLoading] = useState(true)
  const [isShowPermissionBtnShow, setIsShowPermissionBtnShow] = useState(false)
  const actions = useMemo(() => createAsyncFormActions(), []);
  const { userTaskId, procFormDataKey } = useMemo(() => getQueryString(props.location.search), []);
  const { signer, date, originData, isShowPermissionBtn } = useSigner({
    userTaskId,
    nodeName: meetingType[typeIndex].signerNodeName,
    permissionNodeName: meetingType[typeIndex].permissionNodeName,
  });

  SelectDept.isFieldComponent = true;
  PersonalInfo.isFieldComponent = true;
  Dept.isFieldComponent = true;
  Upload.isFieldComponent = true
  Editor.isFieldComponent = true
  SelectMember.isFieldComponent = true
  EditableInput.isFieldComponent = true
  WpsEditor.isFieldComponent = true

  useEffect(() => {
    if (Object.keys(initValue).length > 0) {
      actions.setFormState(state => {
        state.values = (signer || date) ? { ...initValue, signer, issuanceTime: getLocalTime(date) } : initValue
      })
    }
  }, [initValue])

  useEffect(() => {
    actions.setFieldState('fileList', state => { 
      state.props['x-component-props'].meetTitle = meetTitle
    })
  }, [meetTitle])


  // 判断是否有签发人以及签发时间
  useEffect(() => {
    actions.setFieldState('*(signer)', state => {
      state.value = signer || '-'
    })
    actions.setFieldState('*(issuanceTime)', state => {
      state.value = getLocalTime(date) || '-'
    })
  }, [signer, date])

  // 判断当前进入表单的 是否有权限去编辑正文段落
  useEffect(() => {
    console.log('出发', isShowPermissionBtn);
    if(isShowPermissionBtn) {
      setIsShowPermissionBtnShow(true)
    }
  }, [isShowPermissionBtn])

  const getPermissionDetail = async () => {
    const res = await service.getParagraphDetail({ formId: procFormDataKey });
    if (res && res.success) {
      const { data = {}, fileId, id, isSetting = false} = res.data || {}
      const { list = []} = data || {}
      setPermissionObj({list,fileId, id})
      const ids = list.map(item => item.id)
      if (ids && ids.length > 0 && isSetting ) {
        const data = await service.getParagraphContent({ ids: [...ids] })
        if (data && data.success ) {
          actions.setFieldValue('fileList', [{ html: data.data }])
          setLoading(false)
        }
      } else {
        setLoading(false)
      }
    }
  }

  //  数据回填
  useEffect(() => {
    actions.setFieldState('*', state => {
      state.props.description = null;
    });
    if (procFormDataKey) {
      service.getFormData({
        reportId: procFormDataKey, // 获取详情，也就是初始值
      }).then((res) => {
        if (res && res.data) {
          getPermissionDetail()
          let data = res.data.data;
          let operator = res.data.operator;
          setInitValue({ ...data })
          actions.setFormState(state => {
            state.values = { ...data }
          })
          const { formTitle, specialCount, meetingCount, meetingAategory, fileList = [] } = data || {};
          const { orgId = '' } = operator || {};
          setMeetTitle(formTitle) // 审批表单走 详情数据
          setWpsFile(fileList[0])
          // actions.setFormState(state => {
          //   state.values = signer ? { ...data, signer } : data
          // })
          if (meetingCount) {
            actions.getFieldValue('serialNumber').then(data => {
              actions.setFieldValue('serialNumber', data.replace(' ', `${meetingCount > 9 ? meetingCount : "0" + meetingCount}`))
            })
          }
          if (specialCount && meetingAategory == '2') {
            actions.setFieldValue('meetingName', `中国移动广西公司2021年第（${specialCount}）次公司领导专题办公会议`);
          }
        }
      })
    }
  }, [])

  const commonCommit = async () => {
    // todo 需要判断是新建表单的保存还是二次编辑表单的保存，走的接口不一样
    const data = await actions.submit()
    console.log(data)
    // return
    const res = await procFormDataKey ? service.upDateForm({
      config: formConfig,
      data: data.values,
      reportId: procFormDataKey,
    }) : service.saveForm({
      type: meetingType[typeIndex].type,
      classify: {
        name: meetingType[typeIndex].name,
        englishName: meetingType[typeIndex].englishName,
      },
      config: formConfig,
      data: data.values,
    })
    return res
  }

  const submitForm = async () => {
    const res = await commonCommit()
    const data = await actions.submit()
    let values = data.values;
    if (res.success) {
      // return { id: procFormDataKey || res.data, values: values }
      return Promise.resolve()
    }
    throw new Error('保存出错')
  }

  const onMount = ({ access, editMode, draft }) => {
    console.log('draft', draft);
    if (access && Object.keys(access).length > 0 && editMode && editMode.includes('web')) {
      Object.keys(access).forEach(key => {
        if (key === 'isEditable' && access[key] === 'WRITE') {
          setShowSaveBtn(true)
          resetFormState()
          return
        }
        actions.setFieldState(key, state => {
          switch (access[key]) {
            case 'NONE':
              state.display = false
              break
            case 'READ':
              state.editable = false
              break
            case 'WRITE':
              state.editable = true
              state.display = true
              break
            default: break
          }
        })
      })
    } else {
      // actions.setFormState((state) => {
      //   state.editable = false
      // })
    }

    if (draft) {
      console.log('draft', draft);
      actions.setFormState(state => {
        state.values = draft
      })
      // setDraftValue(draft)
    }
  }

  const buttonGroup = () => {
    const array = [];
    if (isShowPermissionBtnShow) {
      
      array.push({
        name: '设置正文段落权限',
        async: false,
        onClick: () => {
          setPermissionModal(true)
        }
      })
    }
    // const array = [];
    // if (isShowPermissionBtnShow) {
    //   array.push(setWpsPermissionBtn(() => {
    //     setPermissionModal(true)
    //   }))
    // }
    return array
  }

  useEffect(() => {
    window.addEventListener('process', () => finishSubmit())
  }, [])

  const finishSubmit = () => {
    closeTheWindow(props.location.search)
  }

  const onOKPromission = (dataSource) => {
    console.log('存储', dataSource);
    setPermissionModal(false)
    setBackFillDataSouce(dataSource)
  }


  const expressionScope = {
    getColor: (text, color) => { return <div style={{ color: `${color}` }}>{text}</div> },
    getDiffMeetType: (type) => { return getDiffMeetType(type) },
    labelAlign: 'left',
    getActions: actions,
    meetTitle: meetTitle,
    disabledDate: (current) => { return current && current <= moment().subtract(1, 'days').endOf('day') },
  }

  const uesEffects = () => {

    onFieldValueChange$('.*(meetingAategory, isProduceMeetingFee)').subscribe(data => {
      const meetingAategory = actions.getFieldValue('meetingAategory')
      const isProduceMeetingFee = actions.getFieldValue('isProduceMeetingFee')
      Promise.all([meetingAategory, isProduceMeetingFee]).then(values => {
        actions.setFieldState('meetingPersonNumber', state => {
          if (values[0] == '1' || values[0] == '3') {
            if (values[1] == '1') {
              state.visible = true
            } else {
              state.visible = false
            }
          } else {
            state.visible = false
          }
        })
      })
    })

    onFieldValueChange$('.*(isProduceMeetingFee, meetingForm)').subscribe(data => {
      const isProduceMeetingFee = actions.getFieldValue('isProduceMeetingFee')
      const meetingForm = actions.getFieldValue('meetingForm')
      Promise.all([meetingForm, isProduceMeetingFee]).then(values => {
        actions.setFieldState('meetingDays', state => {
          if (values[0] == '1' || values[0] == '3') {
            if (values[1] == '1') {
              state.visible = true
            } else {
              state.visible = false
            }
          } else {
            state.visible = false
          }
        })
      })
    })

  }
  const components = {
    TextArea: Input.TextArea,
    Input,
    NumberPicker,
    FormMegaLayout,
    Upload,
    Select,
    Radio,
    RadioGroup: Radio.Group,
    RangePicker: DatePicker.RangePicker,
    SelectDept,
    PersonalInfo,
    Dept,
    Upload,
    Editor,
    SelectMember,
    EditableInput,
    WpsEditor
  }
  return (
    <div >
      <Spin spinning={loading}>
        <h1 className='form-title'>{meetTitle}</h1>
        <SchemaMarkupForm
          schema={schema}
          components={components}
          actions={actions}
          // initialValues={draftValue && Object.keys(draftValue).length > 0 ? draftValue : initValue}
          // initialValues={draftValue}
          effects={() => {
            uesEffects()
          }}
          expressionScope={{ ...expressionScope }}
          previewPlaceholder='-'
          editable={false}
        >
          <div className='button-group'>
            <Space>
              {/* {buttonGroup().map(item => <Button key={item.name} type={item.type} onClick={item.onClick}>{item.name}</Button>)} */}
              <Buttons
                userTaskId={userTaskId}
                // onFinish={finishSubmit}
                onMount={onMount}
                onSubmitOpen={async () => {
                  const data = await actions.submit()
                  return data.values
                }}
                onSubmit={submitForm}
                extraButtons={buttonGroup()}
              />
            </Space>
          </div>
        </SchemaMarkupForm>
        <Tabs defaultActiveKey="1">
          <TabPane tab="审批流程" key="1">
            <Steps
              userTaskId={userTaskId}
            />
          </TabPane>
        </Tabs>
        {showPermissionModal &&
          <PermissionModal
            onCancel={() => setPermissionModal(false)}
            onOk={onOKPromission}
            actions={actions}
            backFillDataSouce={backFillDataSouce}
            fileList={wpsFile}
            procFormDataKey={procFormDataKey}
            permissionObj={permissionObj}
          />
        }
      </Spin>
    </div>
  )
}