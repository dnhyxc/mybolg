import React, { useEffect, useMemo } from 'react';
import { UPLOAD_URL } from 'ROOT/constants'
import PCDIschame from '../common/PCDIschame';
const shcemaParmas = {
  listAllAction:'/baas-admin/web/listAll',
  myListAction: '/baas-admin/web/org/myList?flag=1',
  searchAction: 'web-search/web/search',
}
export default {
  ...PCDIschame(shcemaParmas)
}