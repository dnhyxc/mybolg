import React from 'react'
import './index.css'

const MeetNotice = ({ children }) => {
	return (
		<div>
			{children}
		</div>
	)
}

export default MeetNotice