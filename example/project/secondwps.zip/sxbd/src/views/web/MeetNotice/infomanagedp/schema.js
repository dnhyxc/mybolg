import React, { useEffect, useMemo } from 'react';
import { UPLOAD_URL } from 'ROOT/constants'
import locale from 'antd/lib/date-picker/locale/zh_CN';
import moment from 'moment'
import Cookies from 'js-cookie'

export default {
  type: "object",
  properties: {
    layout: {
      "x-component": "mega-layout",
      type: 'object',
      "x-component-props": {
        autoRow: true,
        grid: true,
        // labelWidth: 130,
        labelAlign: '{{labelAlign}}',
        full: true,
        // labelCol: 24
      },
      properties: {
        formTitle: {
          key: 'formTitle',
          name: 'formTitle',
          display: false,
          default: '会议通知',
          'x-component': 'Input',
        },
        _dept: {
          type: "string",
          title: '起草单位',
          'x-component': 'Dept',
          'x-component-props': {
            labelInValue: true,
          },
          // editable: false
        },
        time: {
          type: "string",
          title: '拟稿时间',
          'x-component': 'EditableInput',
          default: moment().format('YYYY年MM月DD日'),
          // editable: false
        },
        user: {
          type: "string",
          title: '会议经办人',
          'x-component': 'EditableInput',
          // editable: false,
        },

        signer: {
          type: "string",
          title: '签发人',
          'x-component': 'EditableInput',
          // default: '',
          // editable: false
        },
        issuanceTime: {
          type: "string",
          title: '签发时间',
          'x-component': 'EditableInput',
          // editable: false
        },
        phone: {
          type: "string",
          title: '联系电话',
          'x-component': 'EditableInput',
          "x-rules": [{ format: "phone", message: "手机格式不正确" }],
          // editable: false,
        },
        serialNumber: {
          type: "string",
          title: '编号',
          'x-component': 'EditableInput',
          // editable: false
        },
        _taskLevel: {
          type: "string",
          title: '缓急程度',
          'x-component': 'Select',
          default: '3',
          enum: [
            { label: '一般', value: '3' },
            { label: '急件', value: '2' },
            { label: '特急', value: '1' },
          ],
          'x-component-props': {
            style: {
              // width: 100
            }
          }

        },
        meetingAategory: {
          type: "string",
          title: '会议类别',
          'x-component': 'Select',
          // default: '1',
          required: true,
          enum: [
            { label: '公司决策会议', value: '1' },
            { label: '公司领导专题办公会议', value: '2' },
            { label: '其他', value: '3' }
          ],
          'x-linkages': [
            {
              type: "value:visible",
              target: '*(meetingForm, isNeedOtherDptAttend, isProduceMeetingFee)',
              condition: '{{$self.value == 3}}'
            },
          ]
        },
        meetingForm: {
          type: "string",
          title: '会议形式',
          'x-component': 'RadioGroup',
          default: '1',
          enum: [
            { label: '现场会议', value: '1' },
            { label: '视频会议', value: '2' },
            { label: '现场+视频会议', value: '3' },
          ],
          'x-linkages': [
            // {
            //   type: "value:visible",
            //   target: '.meetingPlace',
            //   condition: '{{$self.value == 1}}'
            // },
            {
              type: "value:visible",
              target: '*(isProduceMeetingFee)',
              condition: '{{$self.value == 3 || $self.value == 1}}'
            },
            {
              type: "value:visible",
              target: '*(mainVenueLocation,videoBranchVenueLocation,videoBranchVenuePerson,isNeedPutCards,isNeedProjectionEquipment,isNeedElectronicScreenShow,branchIsNeedProjectionEquipment)',
              condition: '{{$self.value == 2 || $self.value == 3}}'
            },
          ]
        },
        isNeedOtherDptAttend: {
          type: "string",
          default: '1',
          required: true,
          title: '是否需要其他部门二级经理参会',
          'x-component': 'RadioGroup',
          enum: [
            { label: '是', value: '1' },
            { label: '否', value: '2' },
          ]

        },
        isProduceMeetingFee: {
          type: "string",
          title: '是否产生会议费用',
          'x-component': 'RadioGroup',
          enum: [
            { label: '是', value: '1' },
            { label: '否', value: '2' },
          ],
          default: '2',
          'x-linkages': [
            {
              type: "value:visible",
              target: '*(meetingLevel,meetingType,repayDepartment,isScheduledMeeting,isInDptFeeBudget,budgetAmount)',
              condition: '{{$self.value == 1}}'
            },
          ]

        },
        meetingLevel: {
          type: 'string',
          title: '会议级别',
          "x-component": "Select",
          required: true,
          'x-component-props': {
            placeholder: '请选择',
            style: {
              // width: 150
            }
          },
          enum: [
            { label: '区一类会议', value: 'area1' },
            { label: '区二类会议', value: 'area2' },
            { label: '区三类会议', value: 'area3' },
            { label: '市一类会议', value: 'city1' },
            { label: '市二类会议', value: 'city2' },
            { label: '市三类会议', value: 'city3' }

          ],
          'x-linkages': [
            {
              type: "value:schema",
              target: '.meetingType',
              schema: {
                enum: "{{getDiffMeetType($self.value)}}",
              }
            },
            {
              type: "value:visible",
              target: '.staffNumber',
              condition: '{{["area1","city1"].includes($self.value)}}'
            },
            {
              type: "value:schema",
              target: '.isNeedOtherDptAttend',
              condition: '{{$self.value == "area1"}}',
              schema: {
                enum: [
                  { label: '是', value: '1' },
                  { label: '否', value: '2', disabled: true },
                ]
              },
              otherwise: {
                enum: [
                  { label: '是', value: '1' },
                  { label: '否', value: '2' },
                ]
              }
            },

          ]
        },
        meetingType: {
          type: 'string',
          title: '会议类型',
          "x-component": "Select",
          required: true,
          'x-component-props': {
            placeholder: '请选择',
            style: {
              // width: 160
            }
          },
        },
        repayDepartment: {
          type: 'string',
          title: '报账部门',
          "x-component": "SelectDept",
          required: true,
          'x-component-props': {
            // listAllAction: '/baas-admin/web/listAll',
            // myListAction: '/baas-admin/web/org/myList?flag=1',
            // searchAction: 'web-search/web/search?size=100',
            listAllAction: '/baas-admin/web/listAll',
            myListAction: '/baas-easylabel/business/workLineMyList',
            searchAction: '/web-search/web/search?size=100',
            type: '7',
            parentOrgId: Cookies.get('groupId'),
            isRit: true,
          },
        },

        isScheduledMeeting: {
          type: 'string',
          title: '是否为计划内会议',
          'x-component': 'RadioGroup',
          required: true,
          enum: [
            { label: '是', value: '1' },
            { label: '否', value: '2' },
          ],
        },
        isInDptFeeBudget: {
          type: 'string',
          // title: (<div style={{ lineHeight: '16px' }} dangerouslySetInnerHTML={{ __html: '是否在部门<br/>年度会议费预算内' }}></div>),
          title: '是否在部门年度会议费预算内',
          'x-component': 'RadioGroup',
          // required: true,
          enum: [
            { label: '是', value: '1' },
            { label: '否', value: '2' },
          ],
        },
        budgetAmount: {
          title: '预算金额',
          "x-component": "NumberPicker",
          description: '',
          required: true,
          'x-mega-props': {
            "addonAfter": "（万元）",
          },
          maxLength: 3,
          'x-component-props': {
            min: 0,
            max: null
          },
        },

        meetingName: {
          type: 'string',
          title: '会议名称',
          'x-component': 'Input',
          required: true,
          description: "{{getColor('注：公司领导专题办公会议次数在通知签发后自动生成','#5C626B')}}",
          maxLength: 50,
          'x-mega-props': {
            span: 3,

          },
          style: {
            width: 200,
          },
          // editable: false
        },

        rangePicker: {
          typ: 'string',
          title: '开始以及结束时间',
          'x-component': 'RangePicker',
          'x-mega-props': {
            span: 2,

          },
          "x-component-props": {
            showTime: true,
            style: {
              // width: 350,
            },
            locale,
            format:'YYYY-MM-DD HH:mm',
            disabledDate: '{{disabledDate}}',
            // disabledTime: 
            // defaultValue: [moment(), moment().add(1,'hours')]
           
          },
        },
        meetingDays: {
          type: 'string',
          title: '会议天数',
          'x-component': 'Select',
          required: true,
          enum: [
            { label: '0.5', value: '0.5' },
            { label: '1', value: '1' },
            { label: '1.5', value: '1.5' },
            { label: '2', value: '2' },
            { label: '2.5', value: '2.5' },
            { label: '3', value: '3' },
            { label: '3以上', value: 'more' },
          ],
          'x-mega-props': {
            "addonAfter": "天",
          }
        },
        meetingPlace: {
          type: 'string',
          title: '会议地点',
          'x-component': 'Input',
          required: true,
          maxLength: 50,
          description: "{{getColor('注：公司自有场所或四星级（含）以下协议酒店','#5C626B')}}",
          'x-component-props': {
            placeholder: '请输入',
          },
          'x-mega-props': {
            span: 3
          },
        },
        meetingPerson: {
          type: 'string',
          title: '现场会议参会人员',
          // required: true,
          'x-component': 'TextArea',
          'x-mega-props': {
            span: 3
          },
          'x-component-props': {
            // listAllAction: '/baas-admin/web/listAll',
            // myListAction: '/baas-admin/web/org/myList?flag=1',
            // searchAction: '/web-search/web/search?size=100',// web-search/web/searchAll?groupCode=&keyword=&option=3&size=100
            style: {
              width: 400
            }
          },
        },
        meetingPersonNumber: {
          type: 'string',
          title: '现场会议参加人数',
          'x-component': 'NumberPicker',
          required: true,
          'x-mega-props': {
            "addonAfter": "人",
          },
          "x-component-props": {
            max: 1000000,
            min: 0,
          },
        },
        staffNumber: {
          type: 'string',
          title: '工作人员数量',
          'x-component': 'NumberPicker',
          'x-mega-props': {
            "addonAfter": "人",
          },
          "x-component-props": {
            max: 1000000,
            min: 0,
          },
        },
        meetingHost: {
          type: 'string',
          title: '会议主持人',
          'x-component': 'Input',
          maxLength: 20,
          'x-mega-props': {
            span: 2
          }
        },

        mainVenueLocation: {
          typ: 'string',
          title: '主会场地点',
          'x-component': 'Input',
          required: true,
          maxLength: 50,
          description: "{{getColor('注：公司自有场所或四星级（含）以下协议酒店','#5C626B')}}",
          'x-component-props': {
            style: {
              width: 160
            }
          },
          'x-mega-props': {
            span: 3
          }
        },
        videoBranchVenueLocation: {
          typ: 'string',
          title: '视频分会场地点',
          // required: true,
          maxLength: 50,
          'x-component': 'Input',
        },

        videoBranchVenuePerson: {
          type: 'string',
          title: '视频分会场参会人员',
          'x-component': 'TextArea',
          // required: true,
          maxLength: 500,
          'x-mega-props': {
            span: 3
          },
          'x-component-props': {
            style: {
              width: 600
            }
          },
        },


        isNeedPutCards: {
          type: 'string',
          title: '是否需要摆放桌牌',
          'x-component': 'RadioGroup',
          default: '2',
          enum: [
            { label: '是', value: '1' },
            { label: '否', value: '2' },
          ],
          'x-linkages': [
            {
              type: "value:visible",
              target: '.putRequire',
              condition: '{{$self.value == 1}}'
            },
            {
              type: "value:schema",
              target: '.isNeedPutCards',
              condition: '{{$self.value == 2}}',
              schema: {
                'x-mega-props': {
                  span: 3,
                },
              },
              otherwise: {
                'x-mega-props': {
                  span: 1,
                },
              }
            },
          ]
        },
        putRequire: {
          type: 'string',
          title: '摆放要求',
          'x-component': 'Input',
          'x-mega-props': {
            span: 2,
            // wrapperWidth: 200
          },
        },
        isNeedProjectionEquipment: {
          type: 'string',
          title: '是否需要投影设备',
          'x-component': 'RadioGroup',
          enum: [
            { label: '是', value: '1' },
            { label: '否', value: '2' },
          ],
        },
        branchIsNeedProjectionEquipment: {
          type: 'string',
          // title: (<div style={{ lineHeight: '16px' }} dangerouslySetInnerHTML={{ __html: '分会场是否<br/>需要投影设备' }}></div>),
          title: '分会场是否需要投影设备',
          'x-component': 'RadioGroup',
          default: '2',
          enum: [
            { label: '是', value: '1' },
            { label: '否', value: '2' },
          ],
          'x-mega-props': {
            span: 2,
            // wrapperWidth: 200
          },
        },
        isNeedElectronicScreenShow: {
          type: 'string',
          title: '是否需要电子屏显',
          'x-component': 'RadioGroup',
          default: '2',
          enum: [
            { label: '是', value: '1' },
            { label: '否', value: '2' },
          ],
          'x-linkages': [
            {
              type: "value:visible",
              target: '.screenShowContent',
              condition: '{{$self.value == 1}}'
            },
          ]
        },
        screenShowContent: {
          type: 'string',
          title: '屏显内容',
          'x-component': 'Input',
          maxLength: 200,
          'x-mega-props': {
            span: 2,
            // wrapperWidth: 200
          },
        },
        remark: {
          type: 'string',
          title: '备注',
          'x-component': 'TextArea',
          'x-mega-props': {
            span: 3
          },
          'x-component-props': {
            style: {
              width: 600
            }
          },
        },
        upload: {
          type: 'string',
          title: '附件',
          'x-component': 'Upload',
          description: "{{getColor('注：可点击下载查看上传附件','#5C626B')}}",
          'x-component-props': {
            action: UPLOAD_URL,
            listType: 'text'
          },
          'x-mega-props': {
            span: 3
          },
        },
        fileList: {
          key: 'fileList',
          name: 'fileList',
          title: '函件内容',
          'x-component': 'WpsEditor',
          'x-mega-props': {
            span: 3,
          },
          'x-component-props': {
            orgId: '',
            reportId: '',
            type: '',
            config: '',
            formType: 'meetNotice',
            actions: '{{getActions}}',
            meetTitle: '',
            currentSchema: ''
          },
        },
        flag: {
          key: 'flag',
          name: 'flag',
          display: false,
          'x-component': 'Input'
        }
      }
    }
  }
}