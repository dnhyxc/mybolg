import React, { useEffect } from 'react'
import './index.css'

const WorkLetter = ({ children }) => {

	useEffect(() => {
		document.title = '工作协调函'
	}, [])

	return children
}

export default WorkLetter
