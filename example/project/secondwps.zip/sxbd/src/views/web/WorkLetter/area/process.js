import React, { useEffect, useState, useMemo } from 'react'
import ReactDOM from 'react-dom'
import {
  Tabs,
  Space,
  Button,
  message,
} from 'antd'
import { closeTheWindow, getQueryString } from 'ROOT/utils'
import service from 'ROOT/service'
import { Buttons, Steps } from 'ROOT/components/Process'
import useMyInfo from 'ROOT/hooks/useMyInfo'
import useSigner from 'ROOT/hooks/useSigner'
import Form, { actions } from './form'
import { formConfig, signerNodeName, letterType } from '../module/config'
import { closeBtn, dispatchBtn, saveAndExit } from '../module/buttons'
import FeedbackTable from '../component/feedbackTable'
import Dispatch from '../dialog/dispatch'

const { TabPane } = Tabs
const typeIndex = 0

export default props => {
  const { userTaskId, procFormDataKey } = useMemo(() => getQueryString(props.location.search), [props.location.search])
  const [isFeedback, setIsFeedback] = useState(false)
  const [initValue, setInitValue] = useState({})
  const [editable, setEditable] = useState(false)
  const [showSaveBtn, setShowSaveBtn] = useState(false)
  const [draftValue, setDraftValue] = useState({})
  const myInfo = useMyInfo({ isSetStorage: true })
  const { signer, originData } = useSigner({
    userTaskId,
    nodeName: signerNodeName,
  })

  useEffect(() => {
    actions.setFieldState('*(mappingValue)', state => {
      state.visible = false
    })
  }, [])

  useEffect(() => {
    if (procFormDataKey) {
      service.getFormData({
        reportId: procFormDataKey,
      }).then(res => {
        if (res.success && res.data) {
          const { isFeedback } = res.data.data
          setIsFeedback(isFeedback === '1')
          setInitValue(res.data.data)
          resetContentProps()
        }
      })
    }
  }, [])

  const resetContentProps = () => {
    actions.setFieldState('fileList', (state) => {
      state.props['x-component-props'] = {
        ...state.props['x-component-props'],
        reportId: procFormDataKey,
        type: letterType[typeIndex].type,
        config: formConfig,
      }
    })
  }

  const commonCommit = async () => {
    const data = await actions.submit()
    const res = service.upDateForm({
      config: formConfig,
      data: data.values,
      reportId: procFormDataKey,
    })
    return res
  }

  const submitForm = async () => {
    const res = await commonCommit()
    // const data = await actions.submit()
    if (res.success) {
      // return { id: +procFormDataKey, values: data.values }
      return Promise.resolve()
    }
    throw new Error('保存出错')
  }

  useEffect(() => {
    window.addEventListener('process', e => {
      switch(e.detail.type) {
        case 'saved': break;
        case 'approved': // 审批后
        case 'added': // 加签后
        case 'stoped': // 终止后
        case 'rejected': // 退回后
        case 'forworded': // 转交后
        case 'cced': // 抄送后
        default: finishSubmit()
      }
    })
    // window.addEventListener('process', () => finishSubmit())
  }, [])

  const finishSubmit = () => {
    setTimeout(() => {
      closeTheWindow(props.location.search)
    }, 2000)
  }

  // const saveForm = async (callback) => {
  //   const res = await commonCommit()
  //   if (res.success) {
  //     message.success('操作成功', () => {
  //       if (typeof callback === 'function') callback(res)
  //     })
  //   }
  // }

  const buttonGroup = () => {
    const array = []
    // if (showSaveBtn) {
    //   array.push(saveAndExit(() => {
    //     saveForm(() => {
    //       closeTheWindow(true)
    //     })
    //   }))
    // }
    if (originData.childShape.properties.name === signerNodeName) {
      array.push({
        name: '一键分发',
        async: false,
        onClick: async () => {
          const res = await actions.getFormState()
          if (!res.values.mainDelivery || res.values.mainDelivery.length <= 0) {
            message.error('请选择主送人员')
            return
          }
          await commonCommit()
          showDispatchModal()
        }
      })
    }
    // if (originData.childShape.properties.name === signerNodeName) { // signerNodeName
    //   array.push(dispatchBtn(async () => {
    //     const res = await actions.getFormState()
    //     if (!res.values.mainDelivery || res.values.mainDelivery.length <= 0) {
    //       message.error('请选择主送人员')
    //       return
    //     }
    //     await commonCommit()
    //     showDispatchModal()
    //   }))
    // }
    return array
  }

  const showDispatchModal = async () => {
    const overlay = document.createElement('div')
    document.body.appendChild(overlay)
    const close = () => {
      ReactDOM.unmountComponentAtNode(overlay)
      overlay.parentNode.removeChild(overlay)
    }
    const res = await actions.getFormState()
    ReactDOM.render(
      <Dispatch
        width={700}
        visible
        formData={res.values}
        taskId={userTaskId}
        procFormDataKey={procFormDataKey}
        onOkCallback={finishSubmit}
        onCancel={() => {
          close()
        }}
      />,
      overlay,
    )
  }

  const onMount = ({ access, editMode, draft }) => {
    if (access && Object.keys(access).length > 0 && editMode && editMode.includes('web')) {
      Object.keys(access).forEach(key => {
        if (key === 'isEditable' && access[key] === 'WRITE') {
          setShowSaveBtn(true)
          resetFormState()
          return
        }
        actions.setFieldState(key, state => {
          switch (access[key]) {
            case 'NONE':
              state.display = false
              break
            case 'READ':
              state.editable = false
              break
            case 'WRITE':
              state.editable = true
              state.display = true
              break
            default: break
          }
        })
      })
    } else {
      // actions.setFormState((state) => {
      //   state.editable = false
      // })
    }
    if (draft) {
      setDraftValue({ ...draft })
    }
  }

  const resetFormState = () => {
    setEditable(true)
    actions.setFieldState('*(_dept)', state => {
      state.props['x-component'] = 'Editable'
    })
  }

  const getFormData = async () => {
    const data = await actions.submit()
    return data.values
  }

  return (
    <div>
      <Form
        signer={signer}
        initValue={draftValue && Object.keys(draftValue).length > 0 ? draftValue : initValue}
        editable={editable}
      />
      <Tabs defaultActiveKey="1">
        <TabPane tab="审批流程" key="1">
          <Steps
            userTaskId={userTaskId}
          />
        </TabPane>
        {isFeedback
          ? <TabPane tab="反馈内容" key="2">
              <FeedbackTable
                procFormDataKey={procFormDataKey}
              />
            </TabPane>
          : null
        }
      </Tabs>
      <div>
        <Space>
          {/* {originData && originData.procFlags === 0 && !originData.userTaskStatus && buttonGroup().map(item => <Button key={item.name} type={item.type} danger={item.name === '一键分发'} onClick={item.onClick}>{item.name}</Button>)} */}
          <Buttons
            userTaskId={userTaskId}
            onMount={onMount}
            onSave={getFormData}
            onSubmitOpen={getFormData}
            onSubmit={submitForm}
            extraButtons={originData && originData.procFlags === 0 && !originData.userTaskStatus ? buttonGroup() : []}
            // onFinish={finishSubmit}
          />
        </Space>
      </div>
    </div>
  )
}
