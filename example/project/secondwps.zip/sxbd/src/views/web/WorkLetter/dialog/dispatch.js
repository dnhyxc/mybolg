import React, { useEffect, useState } from 'react'
import { Modal, Button, Descriptions, message } from 'antd'
import service from 'ROOT/service'
import { closeTheWindow } from 'ROOT/utils'
import { nodelist } from '../module/config'

export default ({
  width,
  visible,
  onOkCallback,
  onCancel,
  formData,
  taskId,
  procKey,
  procFormDataKey,
  appId,
}) => {
  const [serialNumber, setSerialNumber] = useState('')
  const [tableInfo, setTableInfo] = useState({})
  const [content, setContent] = useState({})
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    getFormData()
    getDetailInfo()
  }, [])

  const getFormData = () => {
    service.getFormData({
      reportId: procFormDataKey,
    }).then(res => {
      if (res.success && res.data) {
        setSerialNumber(res.data.data.serialNumber)
      }
    })
  }

  const getDetailInfo = async () => {
    const array = [{
      type: 1,
      orgDepts: formData.mainDelivery,
    }]
    if (formData.carbonCopy && formData.carbonCopy.length > 0) {
      array.push({
        type: 2,
        orgDepts: formData.carbonCopy,
      })
    }
    const res = await service.getDispatchInfo({
      data: array,
    })
    if (res.success) {
      setTableInfo(res.data)
      setContent(combineTableInfo(res.data))
    }
  }

  const combineTableInfo = (data) => {
    const obj = {}
    Object.keys(data).forEach(key => {
      obj[key] = []
      data[key].forEach(item => {
        obj[key].push(`${item.loginOrgName}${item.deptName === '未归属' ? '' : `\\${item.deptName}`}(${item.loginName})`)
      })
    })
    return obj
  }

  const getMemberInfo = (nodeName) => {
    switch (nodeName) {
      case nodelist[0]: 
        return tableInfo.areaOrgs.map(item => ({
          id: item.loginUid,
          name: item.loginName,
          orgId: item.loginOrgId,
        }))
      case nodelist[1]:
        return tableInfo.cityOrgs.map(item => ({
          id: item.loginUid,
          name: item.loginName,
          orgId: item.loginOrgId,
        }))
      case nodelist[2]:
        return tableInfo.proOrgs.map(item => ({
          id: item.loginUid,
          name: item.loginName,
          orgId: item.loginOrgId,
        }))
      default: break
    }
  }

  const combineAssignee = (node) => {
    const array = []
    node.data.forEach(item => {
      const member = getMemberInfo(item.actinstName || item.actName)
      console.log(member)
      if (member && member.length > 0) {
        array.push(procKey ? {
          actKey: item.actKey,
          assigneeInfo: {
            assignees: member,
          },
        } : {
          actinstId: item.id,
          assigneeInfo: {
            assignees: member,
          },
        })
      }
    })
    return array
  }

  const onOk = async () => {
    setLoading(true)
    const node = await service.getStartNode(procKey ? {
      procKey,
      varJson: JSON.stringify(formData),
    } : {
      taskId,
      varJson: JSON.stringify(formData),
    })
    console.log(combineAssignee(node))
    const res = procKey ? await service.startTask({
      manualStartInfos: combineAssignee(node),
      appId,
      procKey,
      procFormDataKey,
      starterDeptId: formData._dept.value,
      varJson: JSON.stringify(formData),
    }) : await service.completeTask({
      manualCompleteInfos: combineAssignee(node),
      taskId,
      varJson: JSON.stringify(formData),
    })
    if (res.success) {
      setLoading(false)
      onCancel()
      message.success('操作成功', () => {
        if (typeof onOkCallback === 'function') {
          onOkCallback()
          // onOkCallback(() => {
          //   closeTheWindow()
          // })
        }
      })
    }
  }

  return (
    <Modal
      width={width}
      title="一键自动编发"
      visible={visible}
      onCancel={onCancel}
      bodyStyle={{
        maxHeight: '550px',
        overflow: 'auto',
      }}
      footer={[
        <Button key="back" onClick={onCancel}>
          取消
        </Button>,
        <Button key="submit" type="primary" loading={loading} onClick={onOk}>
          确定
        </Button>,
      ]}
    >
      <div>
        <Descriptions column={1} bordered>
          <Descriptions.Item labelStyle={{ width: '165px' }} contentStyle={{ marginBottom: '20px'}} label="公文编号">{serialNumber}</Descriptions.Item>
          <Descriptions.Item labelStyle={{ width: '165px' }} contentStyle={{ marginBottom: '20px'}} label="主送">
            <div dangerouslySetInnerHTML={{ __html: content.mainSend && content.mainSend.join('<br />') }} />
          </Descriptions.Item>
          <Descriptions.Item labelStyle={{ width: '165px' }} label="抄送">
            <div dangerouslySetInnerHTML={{ __html: content.copySend && content.copySend.join('<br />') }} />
          </Descriptions.Item>
        </Descriptions>
        <div className="modal-sub-title">
          <span className="modal-title-line" />
          <p className="modal-title-text">流程分布信息</p>
        </div>
        <Descriptions column={1} bordered>
          <Descriptions.Item labelStyle={{ width: '165px' }} contentStyle={{ marginBottom: '20px'}} label="市公司部门收办">
            <div dangerouslySetInnerHTML={{ __html: content.cityOrgs && content.cityOrgs.join('<br />') }} />
          </Descriptions.Item>
          <Descriptions.Item labelStyle={{ width: '165px' }} contentStyle={{ marginBottom: '20px'}} label="专业公司收办">
            <div dangerouslySetInnerHTML={{ __html: content.proOrgs && content.proOrgs.join('<br />') }} />
          </Descriptions.Item>
          <Descriptions.Item labelStyle={{ width: '165px' }} label="区公司部门收办">
            <div dangerouslySetInnerHTML={{ __html: content.areaOrgs && content.areaOrgs.join('<br />') }} />
          </Descriptions.Item>
          {content.otherOrgs && content.otherOrgs.length > 0 ?
            <Descriptions.Item labelStyle={{ width: '165px' }} label="其他公司部门收办">
              <div dangerouslySetInnerHTML={{ __html: content.otherOrgs && content.otherOrgs.join('<br />') }} />
            </Descriptions.Item> : null
          }
        </Descriptions>
      </div>
    </Modal>
  )
}