import React, { useCallback, useEffect, useState } from 'react'
import {
  SchemaMarkupForm,
  FormEffectHooks,
  createFormActions,
  createAsyncFormActions,
} from '@formily/antd'
import {
  FormMegaLayout,
  Input,
  DatePicker,
  Select,
  Radio,
} from '@formily/antd-components'
import service from 'ROOT/service'
import SelectOrg from 'ROOT/components/Formily/Select'
import WpsEditor from 'ROOT/components/Formily/WpsEditor'
import Dept from 'ROOT/components/Formily/Dept'
import PersonalInfo from 'ROOT/components/Formily/PersonalInfo'
import Editable from 'ROOT/components/Formily/Editable'
import SerialNumber from 'ROOT/components/Formily/SerialNumber'
import Upload from '../component/Upload'
import Schema from './schema'

const { onFieldValueChange$ } = FormEffectHooks
export const actions = createAsyncFormActions()

export default props => {
  const { signer, initValue, editable } = props
  const [formTitle, setFormTitle] = useState('')

  const useManyEffects = useCallback(() => {
    const { setFieldState } = createFormActions()
    // onFieldInputChange$('_dept').subscribe(({ value }) => {
    //   setFieldState('*(mappingValue)', state => {
    //     state.value = ''
    //   })
    // })
    onFieldValueChange$('_dept').subscribe(({ value }) => {
      if (value && value.label) {
        getNumberPrefix(value.label) // todo '区公司\\网络部\\应急通信办公室\\阳光工程办公室'
        actions.setFieldState('fileList', (state) => {
          state.props['x-component-props'].orgId = value.value
        })
        const array = value.label.split('\\')
        setFormTitle(`${array[0] || ''}${array[1] || ''}工作协调函`)
        actions.setFieldState('*(formTitle)', state => {
          state.value = `${array[0] || ''}${array[1] || ''}工作协调函`
        })
      }
    })
  }, [])

  const getNumberPrefix = async (dept) => {
    const res = await service.getNumberPrefix({
      dept,
    })
    actions.setFieldState('*(mappingValue)', state => {
      state.value = res.data && res.data.length > 0 ? res.data[0].mappingValue : ''
      state.props.enum = res.data.map(item => ({
        value: item.mappingValue,
        label: item.mappingValue,
      }))
    })
  }

  useEffect(() => {
    if (Object.keys(initValue).length > 0) {
      actions.setFormState(state => {
        state.values = signer ? { ...initValue, signer } : initValue
      })
      // actions.setFieldState('*(content)', state => {
      //   state.value = initValue.fileList || []
      // })
      if (!editable) {
        setFormTitle(initValue.formTitle)
      }
      // if (!editable && !initValue.isAutoDispatch) {
      //   actions.setFieldState('isAutoDispatch', state => {
      //     state.value = '2'
      //   })
      // }
    }
  }, [initValue])

  // useState(() => {
  //   if (serialNumber) {
  //     actions.setFieldState('serialNumber', state => {
  //       state.value = serialNumber
  //     })
  //   }
  // }, [serialNumber])

  useEffect(() => {
    // 判断是否有签发人
    if (signer) {
      actions.setFieldState('*(signer)', state => {
        state.value = signer || '-'
      })
    }
  }, [signer])

  WpsEditor.isFieldComponent = true
  SelectOrg.isFieldComponent = true
  PersonalInfo.isFieldComponent = true
  Dept.isFieldComponent = true
  Upload.isFieldComponent = true
  Editable.isFieldComponent = true
  SerialNumber.isFieldComponent = true

  return (
    <div>
      <p className="form-title">{formTitle || '工作协调函'}</p>
      {/* todo 提交之后才显示编号 */}
      {/* {initValue.serialNumber || serialNumber
        ? <p className="form-number">编号：{initValue.serialNumber || serialNumber}</p>
        : null
      } */}
      <SchemaMarkupForm
        schema={Schema}
        actions={actions}
        components={{
          DatePicker,
          Input,
          FormMegaLayout,
          Select,
          TextArea: Input.TextArea,
          Upload,
          WpsEditor,
          SelectOrg,
          Radio,
          RadioGroup: Radio.Group,
          PersonalInfo,
          Dept,
          Editable,
          SerialNumber,
        }}
        editable={editable}
        previewPlaceholder="无"
        effects={useManyEffects}
        expressionScope={{
          labelAlign: editable ? 'top' : 'left',
        }}
      />
    </div>
  )
}
