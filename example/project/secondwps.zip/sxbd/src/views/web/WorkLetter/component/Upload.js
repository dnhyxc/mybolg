import React, { useState, useEffect, useRef } from 'react'
import { UploadOutlined, PaperClipOutlined, DeleteOutlined } from '@ant-design/icons'
import {
  Upload,
  Button,
  Space,
  message,
} from 'antd'
import { downloadUrl } from 'ROOT/utils'
import { css } from 'emotion'
import { Modal } from 'antd'
import Service from 'ROOT/service'
import { nativeCommon } from 'ROOT/components/util'
import Loading from 'ROOT/components/Loading'
import bowser from 'bowser'

let first = true

export default itemProps => {
  const InputImport = useRef()

  const [item, setItem] = useState({
    data: '',
    show: false,
    type: ''
  })
  const agent = bowser.parse(window.navigator.userAgent)
  const { value, mutators, props, schema, form, editable } = itemProps
  console.log('value', value);
  const xComponentProps = schema['x-component-props'] || {}
  const [fileList, setFileList] = useState(value)
  const [loading, setLoading] = useState(false)
  useEffect(() => {
    if (value) {
      setFileList(value)
    }
  }, [value])

  const selectFiles = () => {
    InputImport.current.click()
  }

  const fileChange = (e) => {
    let files = e.currentTarget.files[0]
    let { name } = files
    name = name.substring(0, name.lastIndexOf('.'))
    if (!(/^\d+\./.test(name))) {
      message.warning('上传文件不符合附件命名要求，附件名称以数字序号+“.”开头')
			return false
    }
    uploadFiles(files)
  }

  const delFile = (e) => {
    const newList = fileList.filter((item, index) => index !== e)
    setFileList(newList)
    mutators.change(newList)
  }

  const uploadFiles = (files) => {
    if (true) {
      let formData = new FormData()
      formData.append('file', files)
      setLoading(true)
      Service.uploadFile(formData).then(res => {
        const newList = (fileList || []).concat([
          {
            fileName: files.name,
            fileUrl: res.fileUrl,
            fileType: files.type,
            fileSize: files.size,
            uid: files.lastModified,
          }
        ])
        mutators.change(newList)
        setFileList(newList)
        setLoading(false)
      })
    } else {
      message.warning('文件名首字符必须数字')
    }
  }

  const getFileListData = (list) => {
    let url
    return (list || []).map(item => {
      url = item.fileUrl
      return {
        name: item.fileName,
        downloadUrl: url,
        size: Number(item.fileSize),
      }
    })
  }

  const onFileClick = async (file) => {
    const { downloadUrl, name, fileType, size } = file
    if (agent.platform.type === 'desktop') {
      const extName = name.substring(name.lastIndexOf('.') + 1)
      if (/(.*)\.(jpg|bmp|gif|ico|pcx|jpeg|tif|png|raw|tga)$/i.test(name)) {
        setItem({
          show: true,
          type: 'img',
          data: downloadUrl
        })

      } else {
        const previewUrl = await Service.getPreviewUrl({
          fileType: extName,
          fileName: encodeURIComponent(name),
          fileUrl: downloadUrl
        })
        setItem({
          show: true,
          data: previewUrl.data,
          type: 'file'
        })
      }
    } else {
      nativeCommon('openfile', {
        fileSize: size,
        url: downloadUrl,
        fileName: name,
      })
    }
  }

  const close = () => {
    setItem({
      data: '',
      show: false,
      type: ''
    })
  }

  return editable
    ? <div>
      <span
        onClick={selectFiles}
        className={css`
          border: 1px solid #ccc;
          padding: 4px 8px;
          display: inline-block;
          cursor: pointer;
        `}
      >
        上传文件
      </span>
      <input
        type="file"
        ref={InputImport}
        onChange={fileChange}
        className={css`
          position: absolute;
          top: -9999px;
          left: -9999px;
        `}
      />
      <div>
        {
          (fileList || []).map((item, index) => {
            return <div key={index}>{`附件：${item.fileName}`} <DeleteOutlined onClick={() => delFile(index)} style={{ marginLeft: '10px' }} /></div>
          })
        }
      </div>
      {
        loading && <Loading />
      }
    </div>
    :
    <div>
      <Space wrap>
        {value && value.length > 0 && value.map(item => {
          return (
            <Button key={item.uid} type="link" href={downloadUrl(item.fileUrl, item.fileName)}>
              <PaperClipOutlined style={{ color: 'rgba(0,0,0,.45)' }} />{`附件：${item.fileName}`}
            </Button>
          )
        })}
      </Space>
    </div>
}