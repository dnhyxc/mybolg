import React, { useState, useEffect } from 'react'
import moment from 'moment'
import { Table, Space, Button } from 'antd'
import { PaperClipOutlined } from '@ant-design/icons'
import service from 'ROOT/service'
import { formBizId } from 'ROOT/constants'
import { downloadUrl } from 'ROOT/utils'

const pageSize = 10

const fbTableConfig = [{
  title: '反馈人',
  width: 100,
  dataIndex: 'creatorName',
  key: 'creatorName',
}, {
  title: '反馈人部门',
  width: 200,
  dataIndex: 'creatorDeptName',
  key: 'creatorDeptName',
}, {
  title: '反馈日期',
  width: 200,
  dataIndex: 'gmtCreate',
  key: 'gmtCreate',
}, {
  title: '情况说明',
  dataIndex: 'content',
  key: 'content',
}, {
  title: '反馈文件',
  dataIndex: 'extra',
  key: 'extra',
  render: (text) => {
    if (text && text.attachments && text.attachments.length > 0) {
      return (
        <Space wrap>
          {text.attachments.map(item => {
            return (
              <Button key={item.fileUrl} type="link" href={downloadUrl(item.fileUrl, item.fileName)}>
                <PaperClipOutlined style={{ color: 'rgba(0,0,0,.45)' }} />{item.fileName}
              </Button>
            )
          })}
        </Space>
      )
    }
  },
}]

export default (props) => {
  const { procFormDataKey } = props
  const [pageIndex, setPageIndex] = useState(1)
  const [total, setTotal] = useState(0)
  const [dataSource, setDataSource] = useState([])

  const getTableList = async () => {
    const res = await service.getFeedbackList({
      procFormKey: procFormDataKey,
      formBizId,
      pageIndex,
      pageSize,
    })
    if (res.success) {
      setDataSource(res.data.list)
      setTotal(res.data.total)
    }
  }

  useEffect(() => {
    getTableList()
  }, [pageIndex])

  const handleTableChange = (pagination) => {
    setPageIndex(pagination.current)
  }

  return (
    <Table
      columns={fbTableConfig}
      rowKey="id"
      dataSource={dataSource}
      pagination={{
        current: pageIndex,
        pageSize,
        total,
      }}
      onChange={handleTableChange}
    />
  )
}