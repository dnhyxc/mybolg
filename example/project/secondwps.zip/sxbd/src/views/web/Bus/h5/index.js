import React from 'react'

export default props => {
  return (
    <div className="h5-none-wrap">暂不支持手机端操作，请至WEB端操作</div>
  )
}