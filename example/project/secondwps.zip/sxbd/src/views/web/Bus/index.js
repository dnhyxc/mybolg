import React from 'react'
import './index.scss'

const Bus = ({ children })=> {
    return children
}

export default Bus