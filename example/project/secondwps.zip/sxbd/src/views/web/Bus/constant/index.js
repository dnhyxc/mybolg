export const USERANAGE = {
    1: [
        { label: '区-本市城区', value: 10 },
        { label: '区-本市乡镇', value: 11 },
        { label: '区-市到所辖各县', value: 12 },
        { label: '区-离开本市以外', value: 13 },
    ],
    2: [
        { label: '市-本市城区', value: 20 },
        { label: '市-本市乡镇', value: 21 },
        { label: '市-市到所辖各县', value: 22 },
        { label: '市-离开本市以外', value: 23 },
    ],
    3:[
        { label: '县-本县城', value: 30 },
        { label: '县-本县乡镇', value: 31 },
        { label: '县-本县到本市或其他县', value: 32 },
        { label: '县-离开本市以外', value: 33 },
    ],
}

export const ORG_TYPE = {
    1: '区公司',
    2: '市公司',
    3: '县公司或者区域公司'
}

export const CITYSIDE = {
    1: '市内',
    2: '市外'
}

export const CARATTR = {
    1: '长期租赁',
    2: '短期租赁',
    3: '自有车辆'
}

export const RECORDS_LABEL =[
    {
        label: '车牌号',
        value: 'carNo'
    },
    {
        label: '车辆属性',
        value: 'carAttr'
    },
    {
        label: '车品牌',
        value: 'carBrand'
    },
    {
        label: '车型',
        value: 'carModel'
    },
    {
        label: '驾驶员',
        value: 'driver'
    },
    {
        label: '驾驶员号码',
        value: 'driverPhone'
    },
    {
        label: '实际出车时间',
        value: 'useStart'
    },
    {
        label: '实际收车时间',
        value: 'useEnd'
    },
]