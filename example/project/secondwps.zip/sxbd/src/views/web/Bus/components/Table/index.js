import React, { useState, useEffect } from 'react'
import { Table, Button, message } from 'antd'
import { PlusOutlined } from '@ant-design/icons'
import { css } from 'emotion'
import SelectBus from '../SelectBus'
import CreateBus from '../CreateBus'
import CreateDrive from '../CreateDriver'
import { CARATTR } from '../../constant'
import _ from 'lodash'

export default (props) => {
    const { userInfo, initData, setPropsData, initValue, editObj } = props
    console.log(editObj)
    const [dataIndex, setDataIndex] = useState(null)
    const columns = [
        {
            key: "carNo",
            dataIndex: "carNo",
            title: "车牌号"
        },
        {
            key: "carAttr",
            dataIndex: "carAttr",
            title: "车辆属性",
            render: (val)=> {
                return CARATTR[val]
            }
        },
        {
            key: "carBrand",
            dataIndex: "carBrand",
            title: "车品牌"
        },
        {
            key: "carModel",
            dataIndex: "carModel",
            title: "车型"
        },
        {
            key: "driver",
            dataIndex: "driver",
            title: "驾驶员"
        },
        {
            key: "driverPhone",
            dataIndex: "driverPhone",
            title: "驾驶员号码"
        },
        {
            key: "useStart",
            dataIndex: "useStart",
            title: "实际出车时间"
        },
        {
            key: "useEnd",
            dataIndex: "useEnd",
            title: "实际收车时间"
        },
        {
            key: "action",
            dataIndex: "action",
            title: "操作",
            render: (val, record,index) => {
                return <div>
                    {
                        editObj.send_car_start && <a onClick={()=>del(index)}>删除</a>
                    }
                    {
                        (editObj.editUseEnd || editObj.send_car_start || editObj.editUseStart) &&<a className={css`
                            margin-left: ${editObj.send_car_start?'10':0}px
                        `} onClick={()=>{
                            setBusShow(true)
                            setData(record)
                            setDataIndex(index)
                        }}>编辑</a>
                    }
                </div>
            },
        }
    ]

    const [dataSource, setDataSource] = useState(initData)

    const [busShow, setBusShow] = useState(false)
    const [createBusShow, setCreateBusShow] = useState(false)
    const [createDriverShow, setCreateDriverShow] = useState(false)

    useEffect(() => {
        setDataSource(initData)
    }, [])
    const [data, setData] = useState({})

    const setBus = (e) => {
        //创建车辆 e有值代表创建选中；无值代表只是创建
        setData({
            ...data,
            ...e
        })
    }

    const del=(num)=> {
        //删除列表数据
        const newArr = dataSource.filter((item,index)=> index !== num)
        setDataSource(newArr)
        setPropsData(newArr)
    }

    const closeDriver = () => {
        //关闭创建驾驶员弹窗
        setCreateDriverShow(false)
        setBusShow(true)
    }

    const setDriver = (e) => {
         //创建驾驶员 e有值代表创建选中；无值代表只是创建
        setData({
            ...data,
            ...e
        })
    }

    const closeCar = () => {
         //关闭创建车辆弹窗
        setCreateBusShow(false)
        setBusShow(true)
    }

    const createCar = (data) => {
        //创建车辆
        setData(data)
        setCreateBusShow(true)
        setBusShow(false)
    }
    const createDriver = (data) => {
         //创建驾驶员
        setData(data)
        setBusShow(false)
        setCreateDriverShow(true)
    }

    const finish = (e) => {
        console.log(e,'e')
        //选择车辆驾驶员确定按钮
        setBusShow(false)
        if(dataIndex!==null){
            //代表编辑
            const newArr = dataSource.map((item,index)=> {
                if(index===dataIndex){
                    return e
                }
                return item
            })
            setDataSource(newArr)
            setPropsData(newArr)
        }else {
             //代表新增
            if(dataSource.some(item=> item.carNo===e.carNo )){
                message.warning('已选择该车辆，请重新选择')
                return false
            }
            setDataSource(dataSource.concat([{ ...e }]))
            setPropsData(dataSource.concat([{ ...e }]))
        }
        setData({})
        setDataIndex(null)
    }

    return <div>
        <Table
            columns={columns}
            dataSource={dataSource}
            rowKey={(record, index) =>{
                console.log(index)
            }}
            pagination={false}
        />
        {
            editObj.send_car_start && <div className={css`
            text-align: center;
            padding: 10px 0;
        `}>
            <Button className={css`
                width: 100%;
            `} type="primary" ghost onClick={() => setBusShow(true)} icon={<PlusOutlined />}>增加</Button>
            </div>
        }
        {
            busShow && <SelectBus editObj={editObj} initValue={initValue}  finish={finish} initData={data} createCar={createCar} createDriver={createDriver} close={() => setBusShow(false)} />
        }
        {
            createBusShow && <CreateBus close={closeCar} setData={setBus} userInfo={userInfo} />
        }
        {
            createDriverShow && <CreateDrive close={closeDriver} setData={setDriver} />
        }
    </div>
}