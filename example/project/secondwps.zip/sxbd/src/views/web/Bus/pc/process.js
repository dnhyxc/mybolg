import React, { useMemo, useEffect, useState } from 'react'
import Form, { actions } from '../form'
import { withRouter } from 'react-router-dom'
import { Buttons, Steps } from 'ROOT/components/Process'
import { CITYSIDE, USERANAGE } from '../constant'
import { getQueryString, closeTheWindow, reloadWindow } from 'ROOT/utils'
import Cookies from 'js-cookie'
import Service from 'ROOT/service'
import style from '../index.scss'
import _ from 'lodash'
import Table from '../components/Table'
import moment from 'moment'
import { Space, Button, message, Tabs, Modal } from 'antd'

const { TabPane } = Tabs

let timer = null

export default withRouter(props => {
    const orgId = Cookies.get('orgId')
    const [userInfo, setUserInfo] = useState({})
    const { userTaskId, userTaskStutus, appId, procFormDataKey } = useMemo(() => getQueryString(props.location.search), []);
    const [editable, setEditable] = useState(false)
    const [initValue, setInitValue] = useState({ remark: '无' })
    const [editObj, setEditObj] = useState({
        receive_car: false,
        send_car_start: false,
        editBase: false,
        editUseEnd: false,
        editUseStart: false
    })



    const getDetail = () => {
        Service.getOrgType({ orgId }).then(info => {
            setUserInfo(info.data)
            Service.getApplyDetail({ id: procFormDataKey }).then(res => {
                let { data } = res
                setInitValue({
                    ...initValue,
                    ...data,
                    time: [data.useStart, data.useEnd],
                    isGrid: data.isGrid.toString(),
                    gridNameWrap: {
                        gridName: data.gridName
                    },
                    gridNoWrap: {
                        gridNo: data.gridNo
                    },
                    carUser: [{
                        id: data.carUserId,
                        name: data.carUserName,
                    }],
                    remark: data.remark || '无'
                })
            })
        })
    }

    const submit = async () => {
        if (editObj.editBase) {
            const data = await actions.submit()
            const { values } = data
            console.log(values)
            let newData = _.cloneDeep(values)
            if (newData.isGrid == '1') {
                newData.gridName = newData.gridNameWrap.gridName
                newData.gridNo = newData.gridNoWrap.gridNo
                delete newData.gridNameWrap
                delete newData.gridNoWrap
            }
            newData.useStart = newData.time[0]
            newData.useEnd = newData.time[1]
            newData.carUserName = newData.carUser[0].name
            newData.carUserId = newData.carUser[0].id
            delete newData.time
            delete newData.carUser
            delete newData._dept
            const res = await Service.applyEdit({ ...newData, orgId })
            return res
        } else {
            const data = await actions.submit()
            const { values } = data
            const res = await Service.applyRecordEdit({
                applyId: procFormDataKey,
                recordList: initValue.recordList
            })
            return res
        }
    }

    useEffect(() => {
        window.addEventListener('process', e => changeStatus(e), false)
        return () => {
            clearTimeout(timer)
        }
    }, [])

    const changeStatus = (e) => {
        switch(e.detail.type){
            case 'save-and-quit': closeTheWindow(props.location.search);
            break;
            default:  timer = setTimeout(()=>{
                closeTheWindow(props.location.search)
            },1000);
            break
        }
       
    }

    const setPropsData = (e) => {
        console.log(e, 'e')
        setInitValue({
            ...initValue,
            recordList: e
        })
    }

    const setFormAccess = ({ access, editMode, draft }) => {
        if (access && Object.keys(access).length > 0) {
            let obj = {}
            Object.keys(access).map(item => {
                obj[item] = access[item] === 'WRITE' ? true : false
            })
            console.log(obj)
            setEditObj({
                ...editObj,
                ...obj
            })
        }
        if (draft) {
            Service.getOrgType({ orgId }).then(info => {
                setUserInfo(info.data)
                setInitValue({
                    ...initValue,
                    ...draft,
                    remark: info.remark || '无'
                })
            })
        } else {
            getDetail()
        }
    }

    const expressionScope = {
        useRange: USERANAGE[userInfo.orgType],
        uploadTitle: '附件',
        orgType: userInfo.orgType,
        labelAlign: 'left',
        editable: editable
    }


    return <div>
        <h1 className='form-title'>{userInfo.cityOrgName}车辆使用审批单</h1>
        {
            userInfo.orgType && initValue.id && <Form
                initValue={initValue}
                userInfo={userInfo}
                expressionScope={expressionScope}
                editable={editable}
            />
        }
        {
            initValue.id && <Table
                initValue={initValue}
                userInfo={userInfo}
                initData={initValue.recordList || []}
                setPropsData={setPropsData}
                editObj={editObj}
            />
        }
        <Tabs defaultActiveKey="1">
            <TabPane tab="审批流程" key="1">
                <Steps
                    userTaskId={userTaskId}
                />
            </TabPane>
        </Tabs>
        <Buttons
            userTaskId={userTaskId}
            onMount={setFormAccess}
            onSave={async () => {
                const data = await actions.submit()
                const { values } = data
                return {
                    ...initValue,
                    ...values,
                    carUserName: values.carUser[0].name,
                    carUserId: values.carUser[0].id,
                    recordList: initValue.recordList
                }
            }}
            onSubmitOpen={async () => {
                const data = await actions.submit()
                let { values } = data
                console.log(editObj, 'editObj')
                if (editObj.send_car_start && !initValue.recordList.length) {
                    message.error('请选择车辆')
                    throw new Error('请选择车辆')
                }
                if (editObj.editUseStart) {
                    for (let i in initValue.recordList) {
                        if (!initValue.recordList[i].useStart) {
                            message.error('请填写实际出车时间')
                            throw new Error('请填写实际出车时间')
                        }
                    }
                }
                if (editObj.editUseEnd) {
                    for (let j in initValue.recordList) {
                        if (!initValue.recordList[j].useEnd) {
                            message.error('请填写实际收车时间')
                            throw new Error('请填写实际收车时间')
                        }
                    }
                }
                if (editObj.send_car_start || editObj.editUseStart || editObj.editUseEnd) {
                    const res = await submit()
                    if (res.success) {
                        return {
                            ...values,
                            carApplyUser: [{
                                id: values.carUser[0].id,
                                name: values.carUser[0].name,
                                orgId: orgId
                            }],
                            useStart: values.time[0],
                            useEnd: values.time[1],
                            carUserName: values.carUser[0].name,
                            carUserId: values.carUser[0].id,
                            recordList: initValue.recordList
                        }
                    } else {
                        throw new Error('提交报错')
                    }
                }
                else {
                    return {
                        ...values,
                        carApplyUser: [{
                            id: values.carUser[0].id,
                            name: values.carUser[0].name,
                            orgId: orgId
                        }],
                        useStart: values.time[0],
                        useEnd: values.time[1],
                        carUserName: values.carUser[0].name,
                        carUserId: values.carUser[0].id,
                        recordList: initValue.recordList
                    }
                }
            }}
            extraButtons={editObj.editBase ? [
                {
                    name: '编辑',
                    onClick: () => setEditable(true),
                }
            ] : []}
        />
    </div>
})