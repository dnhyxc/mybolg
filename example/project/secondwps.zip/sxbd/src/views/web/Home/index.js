import React from 'react'

import './style.scss'

export default function Home() {
    return (
        <div className='div'>
            11111
            <div className='ok'>ok
            </div>
        </div>
    )
}
