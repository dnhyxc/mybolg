export default {
	// 头部导航信息：adminType、loginName、root集团信息、子公司列表等
	GET_MYSELF: '/baas-easylabel/business/getOrgLinkPath', // '/baas-account/web/myself',
	SAVE_FORM: '/security-manage-platform/web/report/add',
	DELETE_FORM: '/security-manage-platform/web/report/delete',
	// SUBMIT_FORM: '',
	GET_SEND_SIGNER: '/baas-wf-portal/task/app/open', // 获取签发人
	GET_PERSONAL_INFO: '/baas-contact/web/process/user/getOne', // todo 接口待定
	GET_FORM_DATA: '/security-manage-platform/web/report/detail', // 获取回填数据
	UPDATE_FORM: '/security-manage-platform/web/report/update', // 表单更新接口
	GET_TEMPLATE:'/access/DocumentMoa/getDocumentBodyFileList', // 选择模块
	// GET_NODE_LIST: '', // 获取审批节点
	ADD_FEEDBACK: '/baas-wf-letter/web/feedback/add', // 增加反馈
	GET_FEEDBACK_LIST: '/baas-wf-letter/web/feedback/list', // 获取反馈列表
	CREATE_FEEDBACK: '/baas-wf-letter/web/feedback/createTask', // 保存定期反馈任务
	CHANGE_TOPDF:'/access/DocumentMoa/doc2pdf', // 转化为pdf
	GETLIST_DATA:'/access/DocumentMoa/getRefNoListByUser', // 获取发文文号部门数据
	AUTO_NUMBER:'/access/DocumentMoa/genRefNo', // 自动编号
	GET_HISTORY:'/access/DocumentMoa/getHisDocumentListByRefNo', // 查看历史
	IS_SHOW_FEEDBACK: '/baas-wf-letter/web/feedback/check', // 是否显示提交反馈按钮
	USER_LABEL: '/baas-wf-letter/web/userLabel/listUserLabels', // 用户标签
	GET_NUMBER_PREFIX: '/security-manage-platform/web/business/get/number', // 获取编号前缀
	GET_DISPATCH_INFO: '/baas-easylabel/business/batchGetPrincipal', // 获取分发弹框数据
	GET_NEXT_NODE: '/baas-wf-portal/actinst/next', // 获取当前节点的下个可选节点列表
	GET_START_NEXT_NODE: '/baas-wf-portal/actinst/startnext', // 获取开始节点的下个可选节点列表
	COMPLETE_TASK: '/baas-wf-portal/exe/user/task/manual/complete', // 手动提交流程
	START_TASK: '/baas-wf-portal/exe/manual/start', // 启动流程实例
	GET_FLOWID:'/access/DocumentMoa/getDocumentFlowByType', // 获取flowid
	SAVE_DRAFT_URL: '/baas-todocenter/web/todo-task/pushBatch', // 保存草稿
	REVOKE_DRAFT_URL: '/baas-todocenter/web/todo-task/revokeBatch', // 删除草稿
	GET_LEVELCODELIST:'/baas-easylabel/labelmember/batchGetUsers' ,// 获取部门列表
	SEND_DOCUMENT:'/access/DocumentMoa/sendDocument', // 一键分发
	GETUSERLEVEL_CODE:'/baas-easylabel/business/getLabels', // 获取分发code
	CREATE_BUSSINESSCODE:'/access/DocumentMoa/createDocumentByBusiness', // 创建第一次分发
	GET_BUSSINESSCODE:'/access/DocumentMoa/getDocumentIdByBusiness',// 判断是否第一次分发
	GET_DEPARTMENTLIST:'/baas-easylabel/business/batchGetLeaders', // 获取部们列表
	GET_USEFULEXPRESSION:'/user-comment/baas-user-comment/web/list', // 获取常用语
	GET_DISTRIBUTE:'/baas-easylabel/business/checkUserBelong', // 获取是否有权限

	ORG_TYPE: '/baas-car/car/apply/orgType', // 获取经办人当前公司的类型和市级公司信息
	GRID_LIST: '/baas-car/car/apply/grid/list', // 县公司网格列表
	APPLY_CREATE: '/baas-car/car/apply/create', // 用车申请创建
	APPLY_EDIT: '/baas-car/car/apply/edit',// 用车申请修改
	APPLY_DETAIL: '/baas-car/car/apply/detail',// 用车申请明细查询(包含用车清单)
	APPLY_RECORD_DETAIL: '/baas-car/car/apply/record/edit', // 用车清单更新
	CAR_INFO_ADD: '/baas-car/car/info/add', // 创建车辆信息
	DRIVER_INFO_ADD: '/baas-car/driver/info/add', // 创建司机信息
	CAR_INFO_LIST: '/baas-car/car/info/list', // 车辆信息列表
	DRIVER_INFO_LIST: '/baas-car/driver/info/list', // 司机信息列表
	GET_INFO: '/baas-car/car/info/get', // 获取公司名称
	GET_PREVIEW_URL:'/doconline/tools/get_preview_url',
	GET_ORGTYPE: '/baas-easylabel/business/getOrgGroup', // 获取集团下所有区公司和市公司的orgId
	GET_DEPTS:'/baas-easylabel/orgDepts/get',
	GET_USER_LABELS: '/baas-car/car/apply/userLabels',
	GET_WPS_PARAGRAPH: '/baas-moa-document-split/web/documentSplit/upload', // 获取wps内容分段后的数据
	SAVE_PARAGRAPHDETAIL: '/security-manage-platform/web/paragraph/save', // 保存手动增加分段后的数据
	GET_PARAGRAPHDETAIL: '/security-manage-platform/web/paragraph/detail', // 获取手动增加分段后的数据
	GET_PARAGRAPHCONTENT: '/baas-moa-document-split/web/documentSplit/previewById', // 获取手动增加分段后具体的内容
	UPLOADFILE: '/sfs/webUpload/file?fileType=1',
}

