import _ from 'lodash'
import request from './request'
import API from './api'

const CHECK_FUNC = res => res.retcode === 0 || res.success === true
export default {
   /**
   * 获取登录用户所在的集团信息，
   * @param param
   * @returns {Promise.<string>|*}
   */
   getMyself(param) {
      return request.get(API.GET_MYSELF, param).then((res) => res)
   },
   deleteForm(param) {
      return request.get(API.DELETE_FORM, param).then((res) => res)
   },
   saveForm(param) {
      return request.post(API.SAVE_FORM, param).then((res) => res)
   },
   upDateForm(param) {
      return request.post(API.UPDATE_FORM, param).then((res) => res)
   },
   // submitForm(param) {
   //    return request.post(API.SUBMIT_FORM, param).then((res) => res)
   // },
   getSigner(param) {
      return request.get(API.GET_SEND_SIGNER, param).then((res) => res)
   },
   getDocumentWatermark(param) {
      return request.post('/access/DocumentCommon/getDocumentWatermark', param).then(
         res => res,
      )
   },
   getPersonalInfo(param) {
      return request.get(API.GET_PERSONAL_INFO, param).then(res => res)
   },
   getFormData(param) {
      return request.get(API.GET_FORM_DATA, param).then(res => res)
   },
   getDocumentBodyFileList(param) {
      return request.post(API.GET_TEMPLATE, param).then(res => res)
   },
   // getNodeList(param) {
   //    return request.post(API.GET_NODE_LIST, param).then(res=>res)
   // },
   postFeedback(param) {
      return request.post(API.ADD_FEEDBACK, param).then(res => res)
   },
   getFeedbackList(param) {
      return request.get(API.GET_FEEDBACK_LIST, param).then(res => res)
   },
   createFeedback(param) {
      return request.post(API.CREATE_FEEDBACK, param).then(res => res)
   },
   getPdfUrl(param) {
      return request.post(API.CHANGE_TOPDF, param).then(res => res)
   },
   getNumberData(param) {
      return request.post(API.GETLIST_DATA, param).then(res => res)
   },
   getAutoNumber(param) {
      return request.post(API.AUTO_NUMBER, param).then(res => res)
   },
   getHistory(param) {
      return request.post(API.GET_HISTORY, param).then(res => res)
   },
   isShowFeedback(param) {
      return request.post(API.IS_SHOW_FEEDBACK, param).then(res => res)
   },
   getUserLabel(param) {
      return request.get(API.USER_LABEL, param).then(res => res)
   },
   getNumberPrefix(param) {
      return request.post(API.GET_NUMBER_PREFIX, param).then(res => res)
   },
   getDispatchInfo(param) {
      return request.post(API.GET_DISPATCH_INFO, param).then(res => res)
   },
   getStartNode(param) {
      return request.post(param.procKey ? API.GET_START_NEXT_NODE : API.GET_NEXT_NODE, param).then(res => res)
   },
   completeTask(param) {
      return request.post(API.COMPLETE_TASK, param).then(res => res)
   },
   startTask(param) {
      return request.post(API.START_TASK, param).then(res => res)
   },
   getFlowID(param) {
      return request.post(API.GET_FLOWID, param).then(res => res)
   },
   saveDraft(param) {
      return request.post(API.SAVE_DRAFT_URL, param).then(res => res)
   },
   deleteDraft(param) {
      return request.post(API.REVOKE_DRAFT_URL, param).then(res => res)
   },
   getCurrentUserOrgType(param) {
      return request.get(API.GET_ORGTYPE, param).then(res => res)
   },
   /**
  * 根据用户等级编码获取用户数据列表
  * @param {Object} param
  * @param {String} param.lnCode - 等级编码
  */
   getLevelCodeUserList(param) {
      return request.post(API.GET_LEVELCODELIST, param).then((res) => _.get(res, 'data'))
   },
   sendDocument(param) {
      return request.post(API.SEND_DOCUMENT, param).then(res => res)
   },
   /**
    * 获取密级分发人员等级编码 市/区公司 当前用户是否是普通员工
    * @param {Object} param
    * @param {Number} param.orgId 组织id
    * @param {Number} param.deptId 部门id
    * @param {Number} param.userId 用户id
    * @returns  type类型 1是区公司其他是市公司
    */
   getUserLevelCode(param) {
      return request.post(API.GETUSERLEVEL_CODE, param).then((res) => _.get(res, 'data'))
   },
   /**
    * 创建规章制度公文
    * @param {*} param
    * @returns
    */
   createDocumentByBusiness(param) {
      return request.post(API.CREATE_BUSSINESSCODE, param).then((res) => _.get(res, 'data'))
   },
   /**
      * 查询规章制度公文是否已存在
      * @param {*} param
      * @returns
      */
   getDocumentIdByBusiness(param) {
      return request.post(API.GET_BUSSINESSCODE, param).then((res) => _.get(res, 'data'))
   },
   getDepartmentLeaderList(param) {
      return request.post(API.GET_DEPARTMENTLIST, param).then((res) => _.get(res, 'data'))
   },
   getDocumentUsefulExpression(param) {
      return request.get(API.GET_USEFULEXPRESSION, { ...param, pageSize: 10, pageIndex: 1 }).then((res) => _.get(res, 'data'))
   },
   getIsDistribute(param) {
      return request.post(API.GET_DISTRIBUTE, param).then(res => res)
    },

   // 用车
   getOrgType(param) {
      return request.get(API.ORG_TYPE,param).then(res=>res)
   },
   getGridList(param) {
      return request.get(API.GRID_LIST,param).then(res=>res)
   },
   applyCreate(param) {
      return request.post(API.APPLY_CREATE, param).then(res=>res)
   },
   applyEdit(param) {
      return request.post(API.APPLY_EDIT, param).then(res=>res)
   },
   getApplyDetail(param) {
      return request.get(API.APPLY_DETAIL,param).then(res=>res)
   },
   applyRecordEdit(param) {
      return request.post(API.APPLY_RECORD_DETAIL, param).then(res=>res).catch(err=>err)
   },
   carInfoAdd(param) {
      return request.post(API.CAR_INFO_ADD, param).then(res=>res)
   },
   driverInfoAdd(param) {
      return request.post(API.DRIVER_INFO_ADD, param).then(res=>res)
   },
   getCarInfoList(param) {
      return request.get(API.CAR_INFO_LIST,param).then(res=>res)
   },
   getDriverInfoList(param) {
      return request.get(API.DRIVER_INFO_LIST,param).then(res=>res)
   },
   getInfo(param) {
      return request.get(API.GET_INFO,param).then(res=>res)
   },
   getPreviewUrl(param) {
      return request.get(API.GET_PREVIEW_URL,param).then(res=>res)
   },
   getDepts(param) {
      return request.get(API.GET_DEPTS,param).then(res=>res)
   },
   getUserLabelList(param) {
      return request.get(API.GET_USER_LABELS,param).then(res=> res)
   },
   getWpsParagraph(param) {
      return request.post(API.GET_WPS_PARAGRAPH, param).then(res=>res)
   },
   saveParagraphDetail(param) {
      return request.post(API.SAVE_PARAGRAPHDETAIL, param).then(res=>res)
   },
   getParagraphDetail(param) {
      return request.get(API.GET_PARAGRAPHDETAIL, param).then(res=>res)
   },
   getParagraphContent(param) {
      return request.get(API.GET_PARAGRAPHCONTENT, param,).then(res=>res)
   },
   uploadFile(param) {
      return request.post(API.UPLOADFILE, param).then(res => res).catch(err=>err)
    },
}
