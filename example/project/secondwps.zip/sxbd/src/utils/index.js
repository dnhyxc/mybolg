import moment from 'moment'
import Service from 'ROOT/service'
import bowser from 'bowser'

export const xhrWrapper = promise => {
  return promise
    .then(data => {
      return [null, data]
    })
    .catch(err => [err, null])
}

export const noop = () => { }

export const formatDate = (date, format = 'YYYY-MM-DD HH:mm:ss') => {
  if (!date) return date

  return moment(date).format(format)
}

export const genId = length => {
  return Number(Math.random().toString() + Date.now())
    .toString(36)
    .substr(3, length)
}

export const getQueryString = (source = window.location.search) => {
  const str = {}
  source.substr(1).split('&').forEach(key => {
    const arr = key.split('=')
    Object.assign(str, {
      [arr[0]]: arr[1],
    })
  })
  return str
}
export const suffix = (name) => {
  const result = name.substring(name.lastIndexOf("."), name.length)
  return result
}
// 根据文号数组返回文号字符串
export const getSerialNumStr = (serialArr) =>
(serialArr[0] || serialArr[1] || serialArr[2]
  ? `${serialArr[0] || ''}〔${serialArr[1] || ''}〕${serialArr[2] || ''}号`
  : '-')
export const getSerialNumStrFromStr = (serialStr) => {
  // const { value } = getFiled(data.fields, 'refNo')[0]
  // const refNo = JSON.parse(value)
  let refNo = ['', '', '']
  try {
    refNo = JSON.parse(serialStr)
  } catch (e) {
    console.error(`JSON.parse refNo ERROR ${serialStr}`)
  }
  return getSerialNumStr(refNo)
}
/**
 * 文件大小显示
 * @param {Number} size
 * @returns
 */
export const getFileSize = (size, toFixedNum = 2) => {
  if (!size) return '0 B'

  const s = 1024
  const sizes = ['B', 'KB', 'MB', 'GB', 'TB']
  let i = Math.floor(Math.log(size) / Math.log(s))

  if (i > sizes.length - 1) {
    i = sizes.length - 1
  }

  // eslint-disable-next-line no-restricted-properties
  size = (size / Math.pow(s, i)).toFixed(toFixedNum)

  if (!sizes[i] || !size) return '0 B'

  return size + sizes[i]
}


export const downloadFile = (url, fileName) => {
  const el = document.createElement('iframe')
  el.style = 'position:fixed;height:0;width:0;'

  if (/\/fcscloud/.test(url)) {
    el.src = url
  } else {
    el.src = `${url}&filename=${encodeURIComponent(fileName)}`
  }
  document.body.appendChild(el)

  setTimeout(() => {
    document.body.removeChild(el)
  }, 2000)
}


/**
 * 获取水印base64
 */
export const getWaterMask = (config) => {
  const defaultConfig = {
    text: '水印',
    fontSize: 20,
    rotate: -30,
    color: 'rgba(203, 207, 214, .5)',
  }
  const mergedConfig = {
    ...defaultConfig,
    ...config,
  }
  const { text, fontSize, rotate, color } = mergedConfig

  const $canvas = document.createElement('canvas')
  const ctx = $canvas.getContext('2d')

  ctx.font = `normal normal 100 ${fontSize}px MicrosoftYahei`

  const { width } = ctx.measureText(text)
  const height = fontSize
  const rotateAngle = (rotate * Math.PI) / 180
  let drawWidth = Math.abs(width * Math.cos(rotateAngle)) + fontSize
  let drawHeight = Math.abs(width * Math.sin(rotateAngle)) + 2 * fontSize

  drawWidth *= 1.2
  drawHeight *= 1.2

  $canvas.width = drawWidth
  $canvas.height = drawHeight
  ctx.fillStyle = color

  ctx.textBaseline = 'middle'
  ctx.textAlign = 'center'
  ctx.font = `normal normal 100 ${fontSize}px MicrosoftYahei`
  ctx.translate(drawWidth / 2, drawHeight / 2)
  ctx.rotate(rotateAngle)
  ctx.fillText(text, 0, 0)

  return $canvas.toDataURL()
}

let waterMarkPromise = null
export const reGetWaterMarkConfig = () => {
  waterMarkPromise = Service.getDocumentWatermark({
    orgId: 25280,
  })
}
export const getWaterMarkConfig = () => {
  if (!waterMarkPromise) {
    reGetWaterMarkConfig()
  }
  return waterMarkPromise.then(({ data }) => {
    const { openWatermark, type, customize } = data.watermake
    let text = ''
    if (openWatermark) {
      if (type === 1) {
        const userInfo = JSON.parse(localStorage.getItem('userInfo'))
        const { account, loginName } = userInfo
        text = loginName + String(account).slice(-4)
      } else {
        text = customize
      }
    }
    return {
      isOpen: openWatermark,
      text,
    }
  })
}

export const getBase64FromImgUrl = (url, type = 'png') => {
  return new Promise((resolve) => {
    const image = new Image()
    image.crossOrigin = 'anonymous'
    image.onload = () => {
      const canvas = document.createElement('canvas')
      const ctx = canvas.getContext('2d')
      canvas.width = image.width
      canvas.height = image.height
      ctx.drawImage(image, 0, 0)
      resolve(canvas.toDataURL(`image/${type}`, 1))
    }
    image.src = url
  })
}

export const downloadUrl = (url, name) => {
  return (/\/fcscloud/.test(url)) ? url : `${url}&filename=${encodeURIComponent(name)}`
}

export const closeTheWindow = (search) => {
  const backurl = search ? getQueryString(search).backurl : ''
  if (backurl) {
    window.top.location.href = decodeURIComponent(backurl)
  } else {
    window.opener = null
    window.open('', '_self')
    window.close()
  }
}

/**
 * 检查操作系统
 *
 * @returns Win10 | Win7 | WinVista | Win2003 | WinXP | Win2000 | Linux | Unix | Mac
 */
export function detectOS() {
  // const sUserAgent = navigator.userAgent;

  const isWin = navigator.platform == 'Win32' || navigator.platform == 'Windows'
  const isMac =
    navigator.platform == 'Mac68K' ||
    navigator.platform == 'MacPPC' ||
    navigator.platform == 'Macintosh' ||
    navigator.platform == 'MacIntel'
  if (isMac) return 'Mac'
  const isUnix = navigator.platform == 'X11' && !isWin && !isMac
  if (isUnix) return 'Unix'
  const isLinux = String(navigator.platform).indexOf('Linux') > -1
  if (isLinux) return 'Linux'
  if (isWin) {
    return 'Windows'
  }
  return 'other'
}

// 是否是 window
export const isWindow = /^win/i.test(detectOS())

export const replaceHtmlString = (text) => {
  if (text) {
    return text.replace(/<\/?[A-Za-z]+(\s+[A-Za-z]+=".*")*>/g, '')
  }
  return text
}

export const isDeskTop = bowser.parse(window.navigator.userAgent).platform.type === 'desktop'

// 刷新当前页面
export const reloadWindow = () => {
  location.reload()
}
/**
 *  获取 对应字段
 *
 * @export
 * @param {object[]} [fields=[]]
 * @param {string} [fieldName='']
 * @returns
 */
export function getField(fields = [], fieldName = '') {
  let currentField = null
  let currentFieldIndex = -1
  if (fields.length === 0 || !fieldName) {
    return [currentField, currentFieldIndex]
  }

  currentFieldIndex = fields.findIndex((item) => {
    return item.fieldName === fieldName
  })

  if (currentFieldIndex !== -1) {
    currentField = fields[currentFieldIndex]
  }

  return [currentField, currentFieldIndex]
}


export const FIELD_TYPE = {
  /**
   * 标题
   */
  TITLE: 'title',

  /**
   * 文号
   */
  REF_NO: 'refNo',

  /**
   * 外部来文文号
   */
  OUTSIDE_REF_NO: 'outsideRefNo',

  /**
   * 签批单
   */
  SIGN_FILE: 'signFile',

  /**
   * 正文
   */
  BODY_FILE: 'bodyFile',

  THEME_WORD: 'themeWord',

  /**
   * 公文类型
   */
  OFFICIAL_TYPE: 'officialType',

  /**
   * 紧急程度
   */
  URGENCY_LEVEL: 'urgencyLevel',

  /**
   * 密级
   */
  SECRET_CLASS: 'secretClass',

  SECRECY_TERM: 'secrecyTerm',

  /**
   * 发送日期
   */
  DISPATCH_DATE: 'dispatchDate',

  /**
   * 接收日期
   */
  RECEIPT_DATE: 'receiptDate',

  /**
   * 接收单位
   */
  DISPATCH_COMPANY: 'dispatchCompany',

  /**
   * 收文单位
   */
  RECEIPT_COMPANY: 'receiptCompany',

  /**
   * 主送
   */
  MAIN_SEND: 'mainSend',

  /**
   * 抄送
   */
  COPY_SEND: 'copySend',

  ISS_UER: 'issUer',
  PROOFREADER: 'proofreader',
  PRINTER: 'printer',
  IMPRESSION: 'impression',

  /**
   * 附件
   */
  ENCLOSURE: 'enclosure',

  /**
   * 收文文号
   */
  RECEIPT_REF_NO: 'receiptRefNo',

  /**
   * 行文类型
   */
  WRITING: 'writing',

  /**
   * 是否用章
   */
  USESEAL: 'useSeal',

  /**
   * 拟稿部门
   */
  FILE_DEPARTMENT: 'fileDepartment',

  /**
   * 起草人
   */
  CREAT_PERSON: 'creatPerson',

  /**
   * 创建时间/拟稿时间
   */
  CREAT_TIME: 'creatTime',

  /**
   * 参考信息
   */
  REFERENCE: 'reference',
}

export const loadScript = src => {
  const script = document.createElement('script')
  script.src = src
  script.async = false
  document.head.append(script)
}