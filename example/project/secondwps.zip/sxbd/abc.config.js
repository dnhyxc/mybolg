const path = require('path')
const pkg = require('./package.json')
const webpack = require('webpack')
const isDev = process.env.NODE_ENV === 'development'
const entry = path.resolve(__dirname, './src/index.js')
const CopyWebpackPlugin = require('copy-webpack-plugin')
const { DefinePlugin } = require('webpack')
const babelOptions = {}
const output = {
	path: path.resolve(__dirname, './dist'),
	publicPath: isDev ? '' : './',
	filename: '[name].js',
}

const appName = 'extra-forms'

const env = process.env.NODE_ENV
const config = {
  development: {
    api: 'http://moa-dev.uban360.net:21007',
  },
  production: {
    api: '', // https://baas.uban360.com/bpmn/form-client/#
  },
}

const plugins = [
	new CopyWebpackPlugin([
	  {
		from: 'lib/WpsOAAssist',
		to: 'WpsOAAssist/',
	  },
	  {
		from: 'lib/wwwroot',
		to: 'wwwroot/',
	  },
	]),
	new webpack.DefinePlugin({
		ab: JSON.stringify(config[env]),
	}),
  ]
if(!isDev){
	plugins.push(
		new DefinePlugin({
			STATIC_PREFIX: `"//" + window._APP_CONFIG.domain + "/${appName}/"`,
		  })
	)
}else{
	plugins.push( 
		new DefinePlugin({
        STATIC_PREFIX: `'http://moa-dev.uban360.net:21007'`,
      }))
		
}
const apiProxyDomain = 'http://moa-dev.uban360.net:21007'

module.exports = {
	htmlTemplateUrl: path.resolve(__dirname, './public/index.html'),
	entry: {
		index: entry,
	},
	staticPath:  path.resolve(__dirname, './public'),
	host: 'test.moa-dev.uban360.net',
	port: 9000,
	output,
	alias: {
		ROOT: path.resolve(__dirname, './src'),
	},
	cssModule: {
		enable: true,
		localIdentName: `[local]-[hash:base64:5]`,
	},
	proxy: {
		'/baas-wf-portal': apiProxyDomain,
		'/baas-account': apiProxyDomain,
		'/baas-form': apiProxyDomain,
		'/security-manage-platform': apiProxyDomain,
		'/baas-admin': apiProxyDomain,
		'/baas-contact': apiProxyDomain,
		'/baas-wf-letter': apiProxyDomain,
		'/baas-moa-document-split': apiProxyDomain,
		'/sfs/webUpload/file': {
			target: apiProxyDomain,
			secure: false,
			changeOrigin: true,
		},
		'/access': {
			target: apiProxyDomain, // 测试环境
			secure: false,
			changeOrigin: true,
			timeout: 360000,
		},
		'/baas-easylabel': apiProxyDomain,
		'/user-comment': {
			target: apiProxyDomain, // 测试环境
			secure: false,
			changeOrigin: true,
			timeout: 360000,
		},
		'/web-search': apiProxyDomain,
		'/baas-todocenter': apiProxyDomain,
		'/baas-news': {
      target: apiProxyDomain,
      changeOrigin: true,
    },
	'/baas-car': 'http://moa-dev.uban360.net:21007',
	'/doconline': 'http://moa-dev.uban360.net:21007',
	'/baas-formdata': 'http://moa-dev.uban360.net:21007',
	},
	htmlWebpackPluginOptions: {
		minify: {
			removeComments: true,
			collapseWhitespace: !isDev,
			useShortDoctype: true,
		},
		template: path.resolve(__dirname, './public/index.html'),
	},
	plugins,
	env: {
		production: {
			devtool: 'none',
		},
	},
	babelOptions,
}
